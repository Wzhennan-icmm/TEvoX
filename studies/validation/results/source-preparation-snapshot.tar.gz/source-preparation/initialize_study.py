#!/usr/bin/env python3
"""Initialize a relocatable study workspace from this source-only package.

No network access, downloads, executable installation, or analysis is performed.
Historical source observations are copied, never analysis completion markers.
"""
import argparse
import json
from pathlib import Path
import shutil

PACKAGE = Path(__file__).resolve().parent
TOKEN = '@STUDY_ROOT@'


def relocate(value, root):
    if isinstance(value, str):
        return value.replace(TOKEN, str(root))
    if isinstance(value, list):
        return [relocate(item, root) for item in value]
    if isinstance(value, dict):
        return {key: relocate(item, root) for key, item in value.items()}
    return value


def initialize(destination):
    destination = Path(destination).expanduser().resolve()
    if destination == PACKAGE or PACKAGE in destination.parents:
        raise ValueError('Choose a workspace outside the shipped study source directory')
    if destination.exists() and (not destination.is_dir() or any(destination.iterdir())):
        raise ValueError('Study workspace must be new or empty; existing files are never overwritten')
    destination.mkdir(parents=True, exist_ok=True)
    for directory in ['scripts', 'tests', 'discovery', 'metadata', 'provenance', 'docs']:
        shutil.copytree(PACKAGE / directory, destination / directory, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    for name in ['README.md', 'source_catalog.json', 'source_snapshot.json', 'requirements-report.txt']:
        shutil.copyfile(PACKAGE / name, destination / name)
    for path in destination.rglob('*'):
        if not path.is_file():
            continue
        if path.suffix == '.json':
            obj = json.loads(path.read_text())
            path.write_text(json.dumps(relocate(obj, destination), indent=2, ensure_ascii=False) + '\n')
        elif path.suffix == '.md':
            path.write_text(path.read_text().replace(TOKEN, str(destination)))
    for directory in ['tools', 'data', 'results', 'reports', 'metadata/human']:
        (destination / directory).mkdir(parents=True, exist_ok=True)
    record = {'package_source': str(PACKAGE), 'study_root': str(destination),
              'status': 'initialized_sources_only', 'downloaded_inputs': False,
              'note': 'Historical source checksums/provenance are references. No prior analysis completion marker, binary, or biological result was copied.'}
    (destination / 'metadata' / 'initialization.json').write_text(json.dumps(record, indent=2) + '\n')
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--study-root', required=True, help='New or empty workspace; paths containing spaces are supported')
    args = parser.parse_args()
    print(json.dumps(initialize(args.study_root), indent=2))


if __name__ == '__main__':
    main()
