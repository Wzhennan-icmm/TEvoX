# 玉米全基因组比对的显式低内存配置 v1

配置标识：`maize_low_memory_v1`。此配置是针对已记录的玉米 `asm20` 内存分配失败的
恢复方案。2026-10-03 已完成完整 B73/Oh43 FASTA 的实际比对，并完成主分析、
独立侧翼验证、候选导出和缺口组成审计；比对与下游验证分别保留可追溯记录。

原始运行在完整 OH43 目标索引创建后报 `[morecore] insufficient memory`，退出码为
`-6`；没有产生可用 PAF。源码中该错误表示分配器的底层 `malloc` 返回空指针。
日志不能确定具体失败分配位置；完整染色体的重复种子命中及后续链化数组是直接
相关的高内存路径。宿主机 `vm.overcommit_memory=0` 使用启发式内存承诺策略；
`CommitLimit - Committed_AS` 不能当作严格可用内存预算。没有内核 OOM 计数增加，
不能据此认定不存在内存分配失败。

## 明确记录的参数变更

保持 `-x asm20 -c --eqx --secondary=no -I6G`，在原有参数之后、两个 FASTA 路径之前追加：

```text
-w19 -f50 -U50,50 -e0 -t1 -K25m
```

- `-w19`：种子窗口由 asm20 的 10 增至 19，降低索引和查询种子密度。
- `-f50 -U50,50`：参考序列种子出现次数阈值固定为 50；原失败运行实际阈值为 500。
- `-e0`：禁用高频种子的稀疏补救采样，使高频过滤规则明确。
- `-t1`：限制比对并行度。
- `-K25m`：减少查询批大小；此参数不会拆开一条 308 Mb 染色体。

完整 B73 和 OH43 FASTA 不变，完整目标保留为一个索引，没有把目标拆成多个索引。
MAPQ 仍以完整目标为搜索范围计算，但受启发式方法和过滤后种子影响。
`--cap-kalloc` 只在一条查询完成后回收缓冲区，不能控制这类单染色体峰值，因此没有
将其当作硬内存上限。本配置也不是峰值内存保证。

## 对可信度的影响

更严格的种子过滤降低重复丰富区域的比对敏感性，可能增加未比对区间和未解决的 TE
注释片段。必须将此配置标签与结果一起报告；不能将增加的未比对 TE 记录直接解释为
真实插入、缺失或种群多态性。候选仍需独立侧翼验证及注释可比性检查。

真实 minimap2 小规模验证说明了这项代价：140 kb 的相同查询/目标包含 100 个相同的
1 kb 重复拷贝和两侧唯一序列。默认 asm20 完整对齐，峰值 RSS 0.123 GB、耗时约
12.47 秒；`-w19 -f50 -e0` 峰值 RSS 0.033 GB、耗时约 0.041 秒，但只保留了两段
两侧对齐。这是敏感性变化的反例验证，不是玉米全基因组成功证据。
另一个 20 kb 唯一序列例子通过生成的正式启动器完整对齐，CIGAR 和 MAPQ 均通过检查。

## 完整玉米 FASTA 的实际验证

minimap2 `2.30-r1287` 于 **2026-10-03 12:18:04 UTC** 写入有效的比对完成标记。
查询为 B73 `GCF_902167145.1`，完整 **687** 条序列、**2,182,786,008 bp**；
目标为 Oh43 `GCA_902167015.1`，完整 **757** 条序列、**2,176,495,488 bp**。
包括分布式 FASTA 中的全部染色体与其他序列，未筛除序列、切分染色体或拆分目标索引。
日志确认只建立一个目标索引，查询处理批次为十次单条序列、258、411、8，合计687。

程序报告 **Real 4114.997 s、CPU 4113.734 s、Peak RSS 13.617 GB**。
这些是本次环境和输入下的实际观测，不是其他机器的运行时间或内存保证。
完成标记、prepare 前序标记、输入/输出指纹、启动器与底层程序 SHA256、stderr
中的请求参数和实际参数均已核对；报告的配置核验函数返回 `applied`。
小型证据及日志内容见
[完整比对验证记录](../provenance/minimap2-maize-profile-full-alignment-validation.json)。
该记录含真实标记与 PAF 的 SHA256，不包含大数据或可移植的续跑标记。
全基因组比对成功不消除上节实测的重复区域敏感性损失；完整分析状态应另以
`finish`、独立侧翼、候选导出、缺口审计及报告的相互校验为准。

本次下游计算的完成标记、输入/工具指纹与补充结果随后也通过核验，导出
**8,628 个已知类别、具有侧翼支持的 TE 注释片段**，对应 **2,736 个对齐缺口位点**。
符合筛选条件的对齐并集仅覆盖 B73 的 **56.69335%**、Oh43 的 **55.81209%**；
其余约44%的序列处于未解决范围，不能作为真实差异，更不能据此判断TE缺失。
这些计数依赖本配置和阈值，不是已确认的插入事件；基因上下文仍为未过滤的
UCSC AUGUSTUS 从头预测，非作者高置信基因集。
[下游流程验证记录](../provenance/minimap2-maize-profile-full-workflow-validation.json)
记录原始计数、覆盖度、阈值和各阶段证据散列。该记录不替代逐位点独立来源抽查，
也不声明跨物种最终报告已完成复核。

## 固定程序与可复现命令

生成器读取当前构建的原始 minimap2 程序，并将其绝对路径、SHA256 和全部覆盖参数写入
独立可执行启动器。每次执行前检查底层程序 SHA256；不读取可变配置文件或环境参数。
启动器在 stderr 输出原始参数、实际参数、配置标识和底层程序校验和。
相邻 `.profile.json` 仅供审计，运行时不使用。

```sh
python scripts/make_minimap2_profile.py \
  --binary tools/minimap2-src/minimap2 \
  --output tools/minimap2-maize-low-memory-v1

python scripts/run_pair.py --manifest discovery/maize_pair.json \
  --output-dir results/maize --phase prepare
cp tools/minimap2-maize-low-memory-v1.profile.json results/maize/alignment_profile.json

python scripts/run_pair.py --manifest discovery/maize_pair.json \
  --output-dir results/maize --phase align \
  --minimap2 tools/minimap2-maize-low-memory-v1

python scripts/run_pair.py --manifest discovery/maize_pair.json \
  --output-dir results/maize --phase finish \
  --minimap2 tools/minimap2-maize-low-memory-v1
```

在新的安装环境中重新生成启动器，使它固定本机实际构建的 minimap2。启动器仅接受
现有流程的完整 asm20 调用或 `--version`，拒绝其他 preset、额外参数和分段目标索引。
相应 SHA256 会被现有运行指纹记录。独立侧翼验证继续使用原始 minimap2 程序，
不使用这个仅适用于 asm20 的启动器。

复制的 JSON 用于报告审计，本身只能声明配置。只有完成标记、程序及输入/输出指纹、
日志中的实际参数全部匹配，才算核实已应用该配置。上述命令用于新的独立工作目录；
已有失败或完整运行须按主 README 的指纹规则保留和处理旧输出，不能覆盖成功标记。
