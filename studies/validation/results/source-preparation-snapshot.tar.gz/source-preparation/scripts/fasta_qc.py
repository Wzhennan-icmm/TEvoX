#!/usr/bin/env python3
"""Stream FASTA integrity/QC, exact-name selection, lengths and N-gap intervals.

Lengths and BED cover ALL input sequences. BED coordinates are zero-based,
half-open. Sequence names are the first header token, without normalization.
Selected output retains original headers and bases in input order. All outputs
are staged and only published after the entire input, including gzip CRC, passes.
"""
import argparse
import datetime
import gzip
import json
import os
from pathlib import Path
import re
import sys
import tempfile

IUPAC = re.compile(r'^[ACGTRYSWKMBDHVNacgtryswkmbdhvn]+$')
N_RUNS = re.compile(r'[Nn]+')
LOWER = re.compile(r'[a-z]+')
INVALID_DNA = re.compile(r'[^ACGTRYSWKMBDHVNacgtryswkmbdhvn\n]')
CHUNK = 1024 * 1024


def read_selection(path):
    names = set()
    with open(path, encoding='utf-8') as handle:
        for line_number, line in enumerate(handle, 1):
            name = line.strip()
            if not name or name.startswith('#'):
                continue
            if len(name.split()) != 1:
                raise ValueError('Selection line %d must contain exactly one sequence ID' % line_number)
            if name in names:
                raise ValueError('Duplicate selected sequence ID: ' + name)
            names.add(name)
    if not names:
        raise ValueError('Selection list is empty')
    return names



def fasta_batches(source):
    """Yield (is_header, text, first_line) with bounded sequence batching.

    FASTA wraps usually occur every 60-80 bases. Processing a MiB of sequence
    lines together avoids tens of millions of Python/regex calls for a genome.
    A header split across reads is buffered, with the same CHUNK size limit as
    before. Newlines remain in sequence batches for precise error locations.
    """
    pending = ''
    line_number = 1
    line_start = True
    while True:
        block = source.read(CHUNK)
        eof = not block
        pending += block
        while pending:
            if line_start and pending.startswith('>'):
                newline = pending.find('\n')
                if newline < 0:
                    if len(pending) >= CHUNK:
                        raise ValueError('FASTA header exceeds 1 MiB')
                    if not eof:
                        break
                    yield True, pending[1:], line_number
                    pending = ''
                    continue
                if newline >= CHUNK:
                    raise ValueError('FASTA header exceeds 1 MiB')
                yield True, pending[1:newline], line_number
                pending = pending[newline + 1:]
                line_number += 1
                line_start = True
            else:
                header_boundary = pending.find('\n>')
                stop = header_boundary + 1 if header_boundary >= 0 else len(pending)
                fragment = pending[:stop]
                yield False, fragment, line_number
                line_number += fragment.count('\n')
                line_start = fragment.endswith('\n')
                pending = pending[stop:]
        if eof:
            return


def qc(args):
    input_path = Path(args.input).absolute()
    selected = read_selection(args.select) if args.select else None
    if bool(args.select) != bool(args.selected_fasta):
        raise ValueError('--select and --selected-fasta must be supplied together')
    paths = {'lengths': Path(args.lengths).absolute(), 'n_runs': Path(args.n_runs).absolute(),
             'summary': Path(args.summary).absolute()}
    if args.selected_fasta:
        paths['selected_fasta'] = Path(args.selected_fasta).absolute()
    if len(set(paths.values())) != len(paths) or input_path in paths.values():
        raise ValueError('Input and output paths must all be different')
    for path in paths.values():
        if path.is_symlink() or (path.exists() and not args.force):
            raise ValueError('Output already exists or is a symlink: ' + str(path))
        path.parent.mkdir(parents=True, exist_ok=True)
    staging = {}
    opened = []
    try:
        for key, path in paths.items():
            fd, name = tempfile.mkstemp(prefix=path.name + '.', suffix='.tmp', dir=path.parent)
            os.close(fd)
            staging[key] = Path(name)
        lengths = open(staging['lengths'], 'w', encoding='utf-8', newline='')
        gaps = open(staging['n_runs'], 'w', encoding='utf-8', newline='')
        opened.extend([lengths, gaps])
        lengths.write('#sequence_id\tlength\tn_count\tlowercase_count\tselected\n')
        selected_out = None
        selected_buffer = ''
        if selected is not None:
            selected_raw = open(staging['selected_fasta'], 'wb')
            opened.append(selected_raw)
            selected_out = gzip.GzipFile(fileobj=selected_raw, mode='wb', filename='', mtime=0)
            opened.append(selected_out)
        with open(input_path, 'rb') as probe:
            compressed = probe.read(2) == b'\x1f\x8b'
        opener = gzip.open if compressed else open
        totals = {'sequence_count': 0, 'total_bases': 0, 'n_bases': 0,
                  'lowercase_bases': 0, 'n_run_count': 0, 'selected_sequence_count': 0,
                  'selected_bases': 0, 'excluded_sequence_count': 0, 'excluded_bases': 0}
        seen = set()
        excluded = []
        name = None
        length = n_count = lowercase_count = n_run_count = 0
        n_start = None
        is_selected = False

        def flush_sequence():
            nonlocal selected_buffer, n_start, n_run_count
            if name is None:
                return
            if not length:
                raise ValueError('Empty FASTA sequence: ' + name)
            if n_start is not None:
                gaps.write('%s\t%d\t%d\n' % (name, n_start, length))
                n_run_count += 1
                n_start = None
            if is_selected and selected_out is not None and selected_buffer:
                selected_out.write((selected_buffer + '\n').encode('ascii'))
                selected_buffer = ''
            lengths.write('%s\t%d\t%d\t%d\t%d\n' %
                          (name, length, n_count, lowercase_count, is_selected))
            totals['sequence_count'] += 1
            totals['total_bases'] += length
            totals['n_bases'] += n_count
            totals['lowercase_bases'] += lowercase_count
            totals['n_run_count'] += n_run_count
            if is_selected:
                totals['selected_sequence_count'] += 1
                totals['selected_bases'] += length
            else:
                totals['excluded_sequence_count'] += 1
                totals['excluded_bases'] += length
                excluded.append({'sequence_id': name, 'length': length})

        # Source text mode normalizes CRLF/CR while gzip still verifies its CRC.
        with opener(input_path, 'rt', encoding='utf-8', newline=None) as source:
            for is_header, raw_content, line_number in fasta_batches(source):
                if is_header:
                    header = raw_content
                    flush_sequence()
                    if not header.strip() or header[0].isspace():
                        raise ValueError('Empty or whitespace-prefixed FASTA header at line %d' % line_number)
                    name = header.split()[0]
                    if name in seen:
                        raise ValueError('Duplicate FASTA sequence ID: ' + name)
                    seen.add(name)
                    length = n_count = lowercase_count = n_run_count = 0
                    n_start = None
                    is_selected = selected is None or name in selected
                    if is_selected and selected_out is not None:
                        selected_out.write(('>' + header + '\n').encode('utf-8'))
                else:
                    content = raw_content.replace('\n', '')
                    if not content:
                        continue
                    if name is None:
                        sequence_line = line_number + len(raw_content) - len(raw_content.lstrip('\n'))
                        raise ValueError('Sequence before first FASTA header at line %d' % sequence_line)
                    if not IUPAC.fullmatch(content):
                        invalid = INVALID_DNA.search(raw_content)
                        invalid_line = line_number + raw_content[:invalid.start()].count('\n') if invalid else line_number
                        bad = sorted(set(content) - set('ACGTRYSWKMBDHVNacgtryswkmbdhvn'))
                        raise ValueError('Invalid DNA IUPAC character(s) in %s at line %d: %r' %
                                         (name, invalid_line, bad[:12]))
                    if n_start is not None and content[0] not in 'Nn':
                        gaps.write('%s\t%d\t%d\n' % (name, n_start, length))
                        n_run_count += 1
                        n_start = None
                    for match in N_RUNS.finditer(content):
                        if n_start is None:
                            n_start = length + match.start()
                        if match.end() != len(content):
                            gaps.write('%s\t%d\t%d\n' % (name, n_start, length + match.end()))
                            n_run_count += 1
                            n_start = None
                        n_count += match.end() - match.start()
                    lowercase_count += sum(match.end() - match.start() for match in LOWER.finditer(content))
                    length += len(content)
                    if is_selected and selected_out is not None:
                        selected_buffer += content
                        full_length = len(selected_buffer) // 80 * 80
                        if full_length:
                            wrapped = '\n'.join(selected_buffer[i:i + 80] for i in range(0, full_length, 80))
                            selected_out.write((wrapped + '\n').encode('ascii'))
                            selected_buffer = selected_buffer[full_length:]
            flush_sequence()
        if not seen:
            raise ValueError('No FASTA records found')
        if selected is not None and selected - seen:
            raise ValueError('Selected sequence IDs absent from FASTA: ' + ', '.join(sorted(selected - seen)))
        summary = {
            'schema_version': 1,
            'input': str(input_path),
            'gzip_input': compressed,
            'gzip_integrity_checked': compressed,
            'dna_iupac_valid': True,
            'sequence_ids_unique': True,
            'sequence_name_policy': 'exact_first_header_token; no normalization',
            'n_runs_coordinates': '0-based half-open; all input sequences',
            'lengths_scope': 'all input sequences',
            'selection_file': str(Path(args.select).absolute()) if selected is not None else None,
            'selection_policy': 'exact names, retain input order' if selected is not None else 'all sequences',
            'excluded_sequences': excluded,
            'outputs': {key: str(path) for key, path in paths.items()},
            'completed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            **totals,
        }
        with open(staging['summary'], 'w', encoding='utf-8') as handle:
            json.dump(summary, handle, indent=2, sort_keys=True)
            handle.write('\n')
        for handle in reversed(opened):
            handle.close()
        opened.clear()
        for key, path in paths.items():
            os.replace(staging[key], path)
        return summary
    finally:
        for handle in reversed(opened):
            handle.close()
        for path in staging.values():
            path.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True)
    parser.add_argument('--lengths', required=True)
    parser.add_argument('--n-runs', required=True)
    parser.add_argument('--summary', required=True)
    parser.add_argument('--select', help='One exact sequence ID per line; blank/# lines ignored')
    parser.add_argument('--selected-fasta', help='Selected FASTA gzip output')
    parser.add_argument('--force', action='store_true', help='Replace existing QC outputs after successful validation')
    args = parser.parse_args()
    try:
        result = qc(args)
    except (OSError, EOFError, UnicodeError, ValueError) as exc:
        print('FASTA QC error: ' + str(exc), file=sys.stderr)
        return 1
    print(json.dumps({key: result[key] for key in ('sequence_count', 'total_bases', 'n_bases',
                                                 'selected_sequence_count', 'selected_bases')}, sort_keys=True))
    return 0


if __name__ == '__main__':
    sys.exit(main())
