#!/usr/bin/env python3
"""Union coverage of normalized BED7 annotation fragments, with bounded sorting.

This measures the supplied annotation's coverage, not true genome TE content.
Unknown class remains separate. Class unions overlap and must not be summed.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile


def fingerprint(path):
    path = Path(path).resolve()
    stat = path.stat()
    return dict(path=str(path), size=stat.st_size, mtime_ns=stat.st_mtime_ns,
                ctime_ns=stat.st_ctime_ns, device=stat.st_dev, inode=stat.st_ino)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def metrics():
    return dict(fragment_count=0, fragment_bases_sum=0, union_bases=0)


def add_metric(counts, width, covered):
    counts["fragment_count"] += 1
    counts["fragment_bases_sum"] += width
    counts["union_bases"] += covered


def read_lengths(path):
    lengths = {}
    with Path(path).open() as handle:
        for lineno, line in enumerate(handle, 1):
            if not line.strip() or line.startswith("#"):
                continue
            fields = line.rstrip("\r\n").split("\t")
            if len(fields) < 2 or not fields[0] or any(char.isspace() for char in fields[0]):
                raise ValueError("Invalid length row %d" % lineno)
            if fields[0] in lengths:
                raise ValueError("Duplicate length identifier " + fields[0])
            length = int(fields[1])
            if length <= 0:
                raise ValueError("Non-positive sequence length at row %d" % lineno)
            lengths[fields[0]] = length
    if not lengths:
        raise ValueError("Empty lengths table")
    return lengths


def build_database(connection, bed, lengths):
    connection.execute("PRAGMA journal_mode=OFF")
    connection.execute("PRAGMA synchronous=OFF")
    connection.execute("PRAGMA temp_store=FILE")
    connection.execute("PRAGMA cache_size=-32768")
    connection.execute("CREATE TABLE intervals (chrom TEXT, start INTEGER, end INTEGER, category TEXT)")
    digest = hashlib.sha256()
    batch = []
    with Path(bed).open("rb") as handle:
        for lineno, raw in enumerate(handle, 1):
            digest.update(raw)
            line = raw.decode("utf-8").rstrip("\r\n")
            if not line or line.startswith("#"):
                continue
            fields = line.split("\t")
            if len(fields) != 7:
                raise ValueError("Normalized BED7 required at row %d" % lineno)
            chrom, start, end, _, _, strand, category = fields
            start, end = int(start), int(end)
            if chrom not in lengths or not 0 <= start < end <= lengths[chrom]:
                raise ValueError("Unknown contig or out-of-bounds interval at row %d" % lineno)
            if strand not in ("+", "-", ".") or not category or category.strip() != category:
                raise ValueError("Invalid strand/class at row %d" % lineno)
            batch.append((chrom, start, end, category))
            if len(batch) >= 10000:
                connection.executemany("INSERT INTO intervals VALUES (?, ?, ?, ?)", batch)
                batch.clear()
        if batch:
            connection.executemany("INSERT INTO intervals VALUES (?, ?, ?, ?)", batch)
    connection.commit()
    return digest.hexdigest()


def accumulate(connection, lengths):
    """Each class is a sorted subsequence, so one disk sort supplies all unions."""
    per_contig = {chrom: dict(length=length, all=metrics(), known_class=metrics(), unknown_class=metrics(), classes={})
                  for chrom, length in lengths.items()}
    overall = dict(sequence_count=len(lengths), genome_bases=sum(lengths.values()),
                   all=metrics(), known_class=metrics(), unknown_class=metrics(), classes={})
    previous, ends = None, {}
    for chrom, start, end, category in connection.execute("SELECT chrom, start, end, category FROM intervals ORDER BY chrom, start, end"):
        if chrom != previous:
            previous, ends = chrom, {}
        current = per_contig[chrom]
        kind = "unknown_class" if category == "Unknown" else "known_class"
        for group in ("all", kind):
            key = ("group", group)
            covered = max(0, end - max(start, ends.get(key, -1)))
            ends[key] = max(ends.get(key, -1), end)
            add_metric(current[group], end - start, covered)
            add_metric(overall[group], end - start, covered)
        key = ("class", category)
        covered = max(0, end - max(start, ends.get(key, -1)))
        ends[key] = max(ends.get(key, -1), end)
        add_metric(current["classes"].setdefault(category, metrics()), end - start, covered)
        add_metric(overall["classes"].setdefault(category, metrics()), end - start, covered)
    for collection, denominator in [(overall, overall["genome_bases"])] + [(item, item["length"]) for item in per_contig.values()]:
        for item in [collection[name] for name in ("all", "known_class", "unknown_class")] + list(collection["classes"].values()):
            item["union_fraction"] = item["union_bases"] / denominator
            item["summed_minus_union_bases"] = item["fragment_bases_sum"] - item["union_bases"]
    return overall, per_contig


def coverage(bed, lengths_path, temporary_directory=None):
    bed, lengths_path = Path(bed).resolve(), Path(lengths_path).resolve()
    before = [fingerprint(bed), fingerprint(lengths_path)]
    lengths = read_lengths(lengths_path)
    lengths_hash = sha256(lengths_path)
    with tempfile.TemporaryDirectory(prefix="tevox-annotation-coverage-", dir=temporary_directory) as folder:
        connection = sqlite3.connect(str(Path(folder) / "intervals.sqlite"))
        try:
            bed_hash = build_database(connection, bed, lengths)
            overall, per_contig = accumulate(connection, lengths)
        finally:
            connection.close()
    after = [fingerprint(bed), fingerprint(lengths_path)]
    if before != after:
        raise ValueError("Coverage inputs changed while being processed")
    for record, digest in zip(after, (bed_hash, lengths_hash)):
        record["sha256"] = digest
    script = fingerprint(__file__)
    script["sha256"] = sha256(__file__)
    return dict(schema_version=1, status="completed", completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        coordinate_system="zero-based half-open; bookended intervals merged without adding bases",
        algorithm="One SQLite disk-backed sort; 32 MiB connection page cache; 10000-row input batches; no interval lists in memory",
        signature=dict(inputs=after, script=script), overall=overall, per_contig=per_contig,
        interpretation="Coverage of supplied normalized annotation fragments only, not independently measured total TE content. "
            "Unknown is separate from known classes; excluded source classes are absent. Overlapping class unions must not be added. "
            "Fragment lengths can overlap or nest; summed-minus-union bases are repeated annotation coverage, not a duplicate-event count.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bed", required=True, help="Normalized BED7 with canonical class in column 7")
    parser.add_argument("--lengths", required=True, help="Contig and length in first two TSV columns; comments and trailing QC columns allowed")
    parser.add_argument("--output", required=True, help="Supplemental JSON output; never overwrites inputs")
    parser.add_argument("--temporary-directory", help="Directory for temporary SQLite database (removed after completion)")
    args = parser.parse_args()
    output = Path(args.output)
    try:
        inputs = [Path(args.bed).resolve(), Path(args.lengths).resolve(), Path(__file__).resolve()]
        if output.resolve() in inputs or output.is_symlink() or (output.exists() and not output.is_file()):
            raise ValueError("Output collides with input or is not a regular file")
        output.parent.mkdir(parents=True, exist_ok=True)
        result = coverage(args.bed, args.lengths, args.temporary_directory)
        with tempfile.NamedTemporaryFile(mode="w", prefix=".annotation-coverage-", dir=str(output.parent), delete=False) as handle:
            temporary = Path(handle.name)
            try:
                json.dump(result, handle, indent=2, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            except BaseException:
                temporary.unlink()
                raise
        try:
            os.replace(str(temporary), str(output))
        finally:
            if temporary.exists():
                temporary.unlink()
        print(json.dumps(dict(output=str(output.resolve()), **result["overall"]), sort_keys=True))
    except (OSError, ValueError, sqlite3.Error) as exc:
        parser.exit(1, "annotation_coverage: %s\n" % exc)


if __name__ == "__main__":
    main()
