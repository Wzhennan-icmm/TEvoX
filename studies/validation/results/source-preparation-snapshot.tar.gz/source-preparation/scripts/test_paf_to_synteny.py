#!/usr/bin/env python3
import argparse
import csv
import json
from pathlib import Path
import tempfile
import unittest

import paf_to_synteny as converter


def record(strand="+", cigar="1000M100I1000M", qs=100, qe=2200, ts=500, te=2500):
    return converter.parse_paf("q\t10000\t{}\t{}\t{}\tt\t10000\t{}\t{}\t2000\t2100\t60\ttp:A:P\tcg:Z:{}\n".format(
        qs, qe, strand, ts, te, cigar))


class Coordinates(unittest.TestCase):
    def test_query_insertion_plus(self):
        parsed = record()
        operations = converter.cigar_operations(parsed["tags"]["cg"][1])
        self.assertEqual(converter.validate_operations(parsed, operations), 2000)
        self.assertEqual(list(converter.segments(parsed, operations)), [
            ("M", 1000, 100, 1100, 500, 1500, 0, 0),
            ("I", 100, 1100, 1200, 1500, 1500, 1000, 1000),
            ("M", 1000, 1200, 2200, 1500, 2500, 0, 0)])

    def test_reverse_query_insertion_and_target_deletion(self):
        parsed = record("-", "800M100I1200M50D", qs=100, qe=2200, ts=500, te=2550)
        operations = converter.cigar_operations(parsed["tags"]["cg"][1])
        converter.validate_operations(parsed, operations)
        result = list(converter.segments(parsed, operations))
        self.assertEqual(result[0][2:6], (1400, 2200, 500, 1300))
        self.assertEqual(result[1][2:6], (1300, 1400, 1300, 1300))
        self.assertEqual(result[2][2:6], (100, 1300, 1300, 2500))
        self.assertEqual(result[3][2:6], (100, 100, 2500, 2550))

    def test_adjacent_match_and_mismatch_form_one_anchor(self):
        self.assertEqual(converter.cigar_operations("500=10X490=50I1000M"),
                         [("M", 1000), ("I", 50), ("M", 1000)])

    def test_bad_operations_and_consumption_fail(self):
        for cigar in ("*", "10Mgarbage", "0M", "1S20M", "10M2H"):
            with self.assertRaises(ValueError):
                converter.cigar_operations(cigar)
        with self.assertRaises(ValueError):
            converter.validate_operations(record(), [("M", 2000)])

    def test_full_conversion_coordinates_identity_and_filters(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            line = "q\t10000\t100\t2200\t+\tt\t10000\t500\t2500\t2000\t2100\t60\ttp:A:P\tcg:Z:1000M100I1000M\n"
            (root / "input.paf").write_text(line + line.replace("\t60\t", "\t255\t") +
                                              line.replace("tp:A:P", "tp:A:S"))
            args = argparse.Namespace(paf=root / "input.paf", synteny=root / "synteny.tsv",
                gaps=root / "gaps.tsv", summary=root / "summary.json", min_mapq=30,
                min_identity=0.95, min_alignment=2000, min_gap=50, min_anchor=1000)
            converter.convert(args)
            lines = (root / "synteny.tsv").read_text().splitlines()[1:]
            self.assertEqual(lines, ["q\t101\t1100\tt\t501\t1500\t1.000000",
                                     "q\t1201\t2200\tt\t1501\t2500\t1.000000"])
            with (root / "gaps.tsv").open() as handle:
                gap = next(csv.DictReader(handle, delimiter="\t"))
            self.assertEqual(gap["evidence"], "two_alignment_flanks")
            self.assertEqual(gap["target_start"], gap["target_end"])
            counts = json.loads((root / "summary.json").read_text())["counts"]
            self.assertEqual(counts["accepted_alignments"], 1)
            self.assertEqual(counts["rejected_mapq"], 1)
            self.assertEqual(counts["rejected_non_primary_or_unclassified"], 1)

    def test_no_qualifying_alignment_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "input.paf").write_text("")
            args = argparse.Namespace(paf=root / "input.paf", synteny=root / "synteny.tsv",
                gaps=root / "gaps.tsv", summary=root / "summary.json", min_mapq=30,
                min_identity=0.95, min_alignment=10000, min_gap=50, min_anchor=1000)
            with self.assertRaisesRegex(ValueError, "No qualifying"):
                converter.convert(args)


if __name__ == "__main__":
    unittest.main(verbosity=2)
