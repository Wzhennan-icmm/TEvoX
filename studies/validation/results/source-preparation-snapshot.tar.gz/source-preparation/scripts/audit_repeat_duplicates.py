#!/usr/bin/env python3
"""Audit exact RepeatMasker records, retaining IDs, by bounded external sort.

Canonical key is all whitespace-separated source fields, including source ID and
optional overlap marker. It does not merge overlapping/adjacent annotations.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile


def audit(source_path,output_path,temp_parent):
    source=Path(source_path);out=Path(output_path);out.parent.mkdir(parents=True,exist_ok=True)
    count=0;headers=0
    with tempfile.TemporaryDirectory(prefix='repeat-duplicate-audit-',dir=temp_parent) as temp:
        env=os.environ.copy();env['LC_ALL']='C'
        process=subprocess.Popen(['sort','--parallel=1','--buffer-size=256M','--temporary-directory='+temp],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
        try:
            with gzip.open(source,'rb') as handle:
                buffer=bytearray()
                for line in handle:
                    f=line.split()
                    if not f or f[0] in {b'SW',b'score',b'There'}:headers+=1;continue
                    if not f[0].isdigit() or len(f)<14:raise ValueError('Invalid RepeatMasker row')
                    buffer.extend(b'\t'.join(f)+b'\n');count+=1
                    if len(buffer)>1024*1024:process.stdin.write(buffer);buffer.clear()
                if buffer:process.stdin.write(buffer)
            process.stdin.close();previous=None;run=0;unique=0;duplicates=0;extra=0;examples=[];mult={};digest=hashlib.sha256()
            def flush(key,n):
                nonlocal unique,duplicates,extra
                if key is None:return
                unique+=1
                if n>1:
                    duplicates+=1;extra+=n-1;mult[str(n)]=mult.get(str(n),0)+1
                    if len(examples)<10:examples.append({'multiplicity':n,'canonical_fields':key.decode().split()})
            for line in process.stdout:
                digest.update(line)
                if line==previous:run+=1
                else:flush(previous,run);previous=line;run=1
            flush(previous,run);stderr=process.stderr.read().decode();code=process.wait()
            if code:raise RuntimeError('sort failed '+stderr)
            if unique+extra!=count:raise ValueError('Audit count mismatch')
        except BaseException:
            process.kill();process.wait();raise
    result={'input':str(source),'comparison':'All whitespace-canonical full fields including ID and optional overlap marker; exact records only','source_records':count,'header_or_empty_lines':headers,'unique_records':unique,'duplicate_record_groups':duplicates,'extra_duplicate_records':extra,'multiplicity_distribution_duplicate_groups':mult,'duplicate_examples':examples,'canonical_sorted_stream_sha256':digest.hexdigest(),'status':'no_exact_duplicates' if extra==0 else 'exact_duplicates_present','source_modified':False}
    tmp=Path(str(out)+'.part');tmp.write_text(json.dumps(result,indent=2)+'\n');tmp.replace(out)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',required=True);p.add_argument('--output',required=True);p.add_argument('--temp-dir',default=str(Path(__file__).resolve().parents[1] / 'data' / 'mouse'));a=p.parse_args();r=audit(a.input,a.output,a.temp_dir);print(json.dumps({k:r[k] for k in ['input','source_records','unique_records','duplicate_record_groups','extra_duplicate_records','status']}))

if __name__=='__main__':main()
