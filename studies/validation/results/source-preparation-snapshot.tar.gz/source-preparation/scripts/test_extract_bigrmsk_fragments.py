#!/usr/bin/env python3
"""Functional tests for conservation of original mixed-orientation fragments."""
import argparse
import gzip
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extractor', HERE/'extract_bigrmsk_fragments.py')
extractor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extractor)
# Exact HG002 selected BED row 271: the two original fragments overlap by 9 bp.
REAL_ROW = b'chr10_MATERNAL\t200159\t202615\tL1PA3#LINE/L1\t29\t-\t200159\t201864\t0\t5\t0,753,-970,961,751\t-1,0,-1,744,-1\t270\t6265 3.5 0.5 0.0 chr10_MATERNAL 200160 200912 (135698089) C L1PA3 LINE/L1 (0) 6155 5399 270 *,8038 2.3 0.5 0.0 chr10_MATERNAL 200904 201864 (135697137) + L1PA3 LINE/L1 4430 5395 (751) 270 \n'

class ExtractionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root/'input.tsv'
        self.source.write_bytes(REAL_ROW)
        self.lengths = self.root/'lengths.tsv'
        self.lengths.write_text('chr10_MATERNAL\t135899001\n')
        self.audit = self.root/'audit.json'
        self.audit.write_text(json.dumps({'input': str(self.source), 'counts': {'source_fragment_records': 2}, 'source_fragments_per_sequence': {'chr10_MATERNAL': 2}}))
        self.args = argparse.Namespace(input=str(self.source), lengths=str(self.lengths), selection_record=None, output=str(self.root/'fragments.out.gz'), source_map=str(self.root/'sources.tsv.gz'), provenance=str(self.root/'provenance.json'), expected_fragments=2, expected_audit=str(self.audit), allow_inconsistent_aligned_summary=False)

    def test_real_mixed_orientation_preserves_every_field_and_overlap(self):
        result = extractor.extract(self.args)
        with gzip.open(self.args.output, 'rb') as f:
            lines = f.readlines()
        original = [part.split() for part in REAL_ROW.rstrip().split(b'\t')[13].split(b',')]
        self.assertEqual([line.split() for line in lines[3:]], original)
        self.assertEqual([line.split()[8] for line in lines[3:]], [b'C', b'+'])
        normalizer_spec = importlib.util.spec_from_file_location('frozen_normalizer', HERE/'normalize_annotations.py')
        normalizer = importlib.util.module_from_spec(normalizer_spec)
        normalizer_spec.loader.exec_module(normalizer)
        parsed = [normalizer.parse_record(line.decode(), 'repeatmasker-out', None) for line in lines[3:]]
        self.assertEqual([(r[1],r[2],r[3]) for r in parsed], [(200159,200912,'-'),(200903,201864,'+')])
        self.assertEqual(original[0][-1], b'*')
        self.assertEqual(int(original[0][6]) - int(original[1][5]) + 1, 9)
        self.assertEqual(result['counts']['mixed_strand_source_records'], 1)
        self.assertTrue(result['independent_source_map_reread_passed'])
        self.assertEqual(result['canonical_source_fragment_sha256'], result['canonical_output_fragment_sha256'])
        with gzip.open(self.args.source_map, 'rt') as f:
            rows = [line.rstrip().split('\t') for line in f][1:]
        self.assertEqual([row[:4] for row in rows], [['1','4','1','1'],['2','5','1','2']])

    def test_invalid_second_fragment_does_not_publish_partial_outputs(self):
        for bad in [REAL_ROW.replace(b'200904 201864', b'200904 201865'), REAL_ROW.replace(b'0.5 0.0 chr10_MATERNAL 200904', b'0.5 0.0 other 200904')]:
            self.source.write_bytes(bad)
            with self.assertRaises(ValueError):
                extractor.extract(self.args)
            for name in ('output','source_map','provenance'):
                self.assertFalse(Path(getattr(self.args,name)).exists())
            self.assertFalse(list(self.root.glob('*.part')))

    def test_genome_bounds_count_mismatch_and_existing_output_fail(self):
        self.lengths.write_text('chr10_MATERNAL\t201863\n')
        with self.assertRaises(ValueError): extractor.extract(self.args)
        self.lengths.write_text('chr10_MATERNAL\t135899001\n')
        self.args.expected_fragments = 3
        with self.assertRaises(ValueError): extractor.extract(self.args)
        self.assertFalse(Path(self.args.output).exists())
        Path(self.args.output).write_bytes(b'previous verified data')
        with self.assertRaises(ValueError): extractor.extract(self.args)
        self.assertEqual(Path(self.args.output).read_bytes(), b'previous verified data')

    def test_explicit_summary_override_still_requires_exact_query_length(self):
        fields = REAL_ROW.rstrip().split(b'\t')
        fields[6] = b'200160'  # Browser summary misses one valid original base.
        self.source.write_bytes(b'\t'.join(fields)+b'\n')
        with self.assertRaises(ValueError): extractor.extract(self.args)
        self.args.allow_inconsistent_aligned_summary = True
        result = extractor.extract(self.args)
        self.assertEqual(result['counts']['fragments_outside_aligned_summary'], 1)
        self.assertEqual(result['counts']['query_length_verified_fragments'], 2)
        for name in ('output','source_map','provenance'): Path(getattr(self.args,name)).unlink()
        self.source.write_bytes(REAL_ROW.replace(b'(135698089)', b'(135698088)'))
        with self.assertRaises(ValueError): extractor.extract(self.args)
        self.assertFalse(Path(self.args.output).exists())

    def test_selection_metadata_and_reverse_only_fragment(self):
        fields = REAL_ROW.rstrip().split(b'\t')
        fields[13] = fields[13].split(b',')[0]
        self.source.write_bytes(b'\t'.join(fields)+b'\n')
        selection = self.root/'selection.json'
        selection.write_text(json.dumps({'selected_sequences': {'chr10_MATERNAL': {'length': 135899001}}}))
        self.args.selection_record = str(selection)
        self.args.lengths = None
        self.args.expected_fragments = 1
        self.args.expected_audit = None
        result = extractor.extract(self.args)
        self.assertEqual(result['counts']['mixed_strand_source_records'], 0)
        self.assertEqual(result['counts']['display_strand_mismatch_fragments'], 0)
        with gzip.open(self.args.output,'rb') as f:
            self.assertEqual(f.readlines()[3].split(), fields[13].split())

if __name__ == '__main__':
    unittest.main()
