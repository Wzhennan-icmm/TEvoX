#!/usr/bin/env python3
"""Download the verified rat pair using the shared provenance-aware fetcher."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'discovery/rat_sources.json'
FETCHER = ROOT / 'scripts/fetch_inputs.py'
DATA = ROOT / 'data/rat'


def download_one(assembly, kind):
    folder = DATA / assembly['label'].lower()
    folder.mkdir(parents=True, exist_ok=True)
    if kind == 'md5checksums':
        snapshot = ROOT / 'discovery' / assembly['local_checksums']
        payload = snapshot.read_bytes()
        url = assembly['checksums_url']
        filename = 'md5checksums.txt'
        args = ['--sha256', hashlib.sha256(payload).hexdigest(), '--expected-bytes', str(len(payload))]
    else:
        file = assembly['files'][kind]
        url, filename = file['url'], file['filename']
        args = ['--md5', file['md5'], '--expected-bytes', str(file['compressed_bytes']), '--checksum-source', assembly['checksums_url']]
    output = folder / filename
    record = folder / (filename + '.provenance.json')
    cmd = [sys.executable, str(FETCHER), '--url', url, '--output', str(output), '--record', str(record), '--max-bytes', str(6 * 1024**3)] + args
    print('START', assembly['label'], kind, filename, flush=True)
    run = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if run.stdout:
        print(run.stdout.strip(), flush=True)
    if run.returncode:
        if run.stderr:
            print(run.stderr.strip(), file=sys.stderr, flush=True)
        raise RuntimeError('Download failed for ' + assembly['label'] + ' ' + kind)
    print('DONE', assembly['label'], kind, flush=True)
    return {'assembly': assembly['assembly_accession'], 'label': assembly['label'], 'kind': kind, 'record': str(record), 'path': str(output)}


def main():
    manifest = json.loads(MANIFEST.read_text())
    if manifest['total_compressed_bytes'] > 10 * 1024**3:
        raise ValueError('Rat source manifest exceeds species download budget')
    DATA.mkdir(parents=True, exist_ok=True)
    results = []
    for phase in [('md5checksums',), ('fasta',), ('gene_gff3', 'repeatmasker')]:
        tasks = [(assembly, kind) for assembly in manifest['assemblies'] for kind in phase]
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(download_one, assembly, kind) for assembly, kind in tasks]
            for future in concurrent.futures.as_completed(futures):
                results.append(future.result())
        if phase == ('fasta',):
            (DATA / 'fastas_ready.json').write_text(json.dumps([r for r in results if r['kind'] == 'fasta'], indent=2) + '\n')
            print('BOTH_FASTAS_READY_AND_MD5_VERIFIED', flush=True)
    output = {'source_manifest': str(MANIFEST), 'total_compressed_input_bytes': manifest['total_compressed_bytes'], 'files': results, 'status': 'all_eight_downloads_verified'}
    temporary = DATA / 'download_manifest.json.part'
    temporary.write_text(json.dumps(output, indent=2) + '\n')
    temporary.replace(DATA / 'download_manifest.json')
    print('ALL_RAT_INPUTS_READY', flush=True)


if __name__ == '__main__':
    main()
