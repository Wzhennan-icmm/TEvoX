#!/usr/bin/env python3
"""Remove only consecutive RepeatMasker records identical after whitespace normalization.

Headers and the first original line of each group are retained verbatim. All
columns, including score, family, coordinates, strand, record ID and optional
asterisk, participate in equality. Distinct annotations are never merged.
SQLite checks for nonconsecutive duplicate SHA256 signatures; such records are
retained and make the audit fail rather than silently treating them as unique.
"""
import argparse
import collections
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile

from run_pair import atomic_json, fingerprint, now, sha256_file


def deduplicate(args):
    source = Path(args.input).resolve(strict=True)
    output = Path(args.output).absolute()
    report = Path(args.report).absolute()
    mapping = Path(str(output) + '.source_groups.tsv.gz')
    paths = [output, report, mapping]
    if len(set(paths + [source])) != 4:
        raise ValueError('Input/output/report paths must differ')
    for path in paths:
        if path.exists() or path.is_symlink():
            raise ValueError('Refusing to overwrite existing output: ' + str(path))
        path.parent.mkdir(parents=True, exist_ok=True)
    original_fingerprint = fingerprint(source)
    source_sha256 = sha256_file(source)
    counts = collections.Counter()
    histogram = collections.Counter()
    anomalies = []
    positions = {}
    closed_contigs = set()
    previous_chrom = None
    previous = None
    multiplicity = 0
    source_first_line = 0
    output_record = 0
    temporary = []
    connection = None
    try:
        fd, dbname = tempfile.mkstemp(prefix='repeat-duplicate-audit.', suffix='.sqlite', dir=output.parent)
        os.close(fd)
        temporary.append(Path(dbname))
        connection = sqlite3.connect(dbname)
        connection.execute('PRAGMA cache_size=-32768')
        connection.execute('PRAGMA temp_store=FILE')
        connection.execute('CREATE TABLE seen (sha256 BLOB PRIMARY KEY, first_line INTEGER NOT NULL) WITHOUT ROWID')
        fd, partname = tempfile.mkstemp(prefix=output.name + '.', suffix='.part', dir=output.parent)
        os.close(fd)
        part = Path(partname)
        temporary.append(part)
        fd, mapname = tempfile.mkstemp(prefix=mapping.name + '.', suffix='.part', dir=mapping.parent)
        os.close(fd)
        mappart = Path(mapname)
        temporary.append(mappart)
        with source.open('rb') as probe:
            compressed = probe.read(2) == b'\x1f\x8b'
        opener = gzip.open if compressed else open
        with opener(source, 'rt', encoding='utf-8') as handle, part.open('wb') as out_raw, mappart.open('wb') as map_raw:
            with gzip.GzipFile(fileobj=out_raw, mode='wb', filename='', compresslevel=1, mtime=0) as dest, \
                 gzip.GzipFile(fileobj=map_raw, mode='wb', filename='', compresslevel=1, mtime=0) as groups:
                groups.write(b'output_record_ordinal\tsource_first_line\tmultiplicity\n')
                def close_group():
                    if multiplicity:
                        histogram[multiplicity] += 1
                        groups.write(('%d\t%d\t%d\n' % (output_record, source_first_line, multiplicity)).encode())
                for lineno, line in enumerate(handle, 1):
                    counts['source_physical_lines'] += 1
                    fields = line.split()
                    if not fields or fields[0] in {'SW', 'score', 'There'}:
                        counts['header_or_blank_lines'] += 1
                        dest.write(line.encode())
                        continue
                    if not fields[0].isdigit() or len(fields) < 14:
                        raise ValueError('Malformed RepeatMasker line %d' % lineno)
                    chrom, start, end = fields[4], int(fields[5]), int(fields[6])
                    if start < 1 or end < start or fields[8] not in {'+', 'C'}:
                        raise ValueError('Invalid RepeatMasker interval/strand at line %d' % lineno)
                    normalized = ' '.join(fields)
                    counts['source_record_rows'] += 1
                    if counts['source_record_rows'] % 1000000 == 0:
                        print('Audited %d source records; removed %d adjacent duplicates' % (counts['source_record_rows'], counts['removed_consecutive_duplicate_rows']), file=sys.stderr, flush=True)
                    if normalized == previous:
                        counts['removed_consecutive_duplicate_rows'] += 1
                        multiplicity += 1
                        continue
                    close_group()
                    output_record += 1
                    multiplicity = 1
                    source_first_line = lineno
                    previous = normalized
                    digest = hashlib.sha256(normalized.encode()).digest()
                    try:
                        connection.execute('INSERT INTO seen VALUES (?,?)', (digest, lineno))
                    except sqlite3.IntegrityError:
                        counts['retained_nonconsecutive_duplicate_rows'] += 1
                        first = connection.execute('SELECT first_line FROM seen WHERE sha256=?', (digest,)).fetchone()[0]
                        if len(anomalies) < 20:
                            anomalies.append({'kind': 'nonconsecutive_duplicate_signature', 'first_line': first, 'line': lineno})
                    if chrom != previous_chrom:
                        if previous_chrom is not None:
                            closed_contigs.add(previous_chrom)
                        if chrom in closed_contigs:
                            counts['contig_reentry_events'] += 1
                        previous_chrom = chrom
                    if start < positions.get(chrom, 0):
                        counts['coordinate_order_violations'] += 1
                        if len(anomalies) < 20:
                            anomalies.append({'kind': 'coordinate_order_violation', 'line': lineno, 'chrom': chrom,
                                              'previous_start': positions[chrom], 'start': start})
                    positions[chrom] = start
                    counts['retained_record_rows'] += 1
                    dest.write(line.encode())
                    if output_record % 10000 == 0:
                        connection.commit()
                        if shutil.disk_usage(output.parent).free < 1024 ** 3:
                            raise ValueError('Less than 1 GiB disk reserve during duplicate audit')
                close_group()
        connection.commit()
        connection.close()
        connection = None
        if not counts['source_record_rows']:
            raise ValueError('No RepeatMasker records found')
        if fingerprint(source) != original_fingerprint:
            raise ValueError('Source changed during duplicate removal')
        for key in ('removed_consecutive_duplicate_rows', 'retained_nonconsecutive_duplicate_rows',
                    'coordinate_order_violations', 'contig_reentry_events'):
            counts.setdefault(key, 0)
        result = {
            'schema_version': 1, 'completed_at': now(),
            'status': 'failed_nonconsecutive_duplicates' if counts['retained_nonconsecutive_duplicate_rows'] else 'passed',
            'source': str(source), 'source_fingerprint': original_fingerprint,
            'source_sha256_local': source_sha256,
            'output': str(output), 'output_sha256_local': sha256_file(part),
            'output_bytes': part.stat().st_size, 'source_groups': str(mapping),
            'counts': dict(counts),
            'multiplicity_histogram': {str(key): value for key, value in sorted(histogram.items())},
            'anomaly_examples': anomalies,
            'identity_rule': 'All original record columns equal after splitting/joining whitespace; only consecutive record rows removed',
            'nonconsecutive_audit': 'Disk SQLite SHA256 signatures across all retained original records; nonconsecutive matches retained and fail audit',
            'coordinate_order_policy': 'Informational audit only; no resorting or coordinate changes',
            'checksum_interpretation': 'Local integrity hashes; published source checksum verification is recorded separately',
            'scientific_interpretation': 'Duplicate source annotation rows removed; no TE fragments merged into insertion events',
        }
        if result['status'] != 'passed':
            atomic_json(report, result)
            raise ValueError('Nonconsecutive duplicate signatures found; report saved, corrected output not published')
        os.replace(part, output)
        os.replace(mappart, mapping)
        atomic_json(report, result)
        return result
    finally:
        if connection is not None:
            connection.close()
        for path in temporary:
            path.unlink(missing_ok=True)
            Path(str(path) + '-journal').unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--report', required=True)
    args = parser.parse_args()
    try:
        result = deduplicate(args)
    except (OSError, ValueError, EOFError, sqlite3.Error) as exc:
        parser.exit(1, 'RepeatMasker deduplication error: %s\n' % exc)
    print(json.dumps({'status': result['status'], 'output': result['output'], 'counts': result['counts']}))


if __name__ == '__main__':
    main()
