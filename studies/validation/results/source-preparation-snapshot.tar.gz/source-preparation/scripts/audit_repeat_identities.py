#!/usr/bin/env python3
"""Audit repeated RepeatMasker query/ID/start/end identities without modifying input."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def audit(label):
    folder = ROOT / 'data/mouse' / label
    provenance = json.loads((folder / 'primary_selection.provenance.json').read_text())
    source = Path(provenance['source_artifacts']['repeatmasker']['local_path'])
    records = 0
    with tempfile.TemporaryDirectory(prefix='repeat-identity-', dir=folder) as temp:
        env = dict(os.environ, LC_ALL='C')
        process = subprocess.Popen(['sort', '--parallel=1', '--buffer-size=128M', '--temporary-directory='+temp], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
        try:
            with gzip.open(source, 'rb') as handle:
                buffer = bytearray()
                for line in handle:
                    fields = line.split()
                    if not fields or fields[0] in {b'SW', b'score', b'There'}:
                        continue
                    if not fields[0].isdigit() or len(fields) < 15:
                        raise ValueError('Invalid RepeatMasker row/absent source ID')
                    identity = [fields[4], fields[14], fields[5], fields[6]]
                    digest = hashlib.sha256(b'\t'.join(fields)).hexdigest().encode()
                    buffer.extend(b'\t'.join(identity + [digest]) + b'\n')
                    records += 1
                    if len(buffer) >= 1024 * 1024:
                        process.stdin.write(buffer)
                        buffer.clear()
                if buffer:
                    process.stdin.write(buffer)
            process.stdin.close()
            previous = None
            seen_hashes = set()
            count = identities = repeated = conflicts = 0
            examples = []

            def flush():
                nonlocal identities, repeated, conflicts
                if previous is None:
                    return
                identities += 1
                if count > 1:
                    repeated += 1
                    conflicts += len(seen_hashes) > 1
                    if len(examples) < 10:
                        examples.append({'identity': [x.decode() for x in previous], 'records': count, 'distinct_full_record_sha256': len(seen_hashes)})

            for line in process.stdout:
                fields = line.rstrip(b'\n').split(b'\t')
                identity = tuple(fields[:4])
                if identity != previous:
                    flush()
                    previous = identity
                    count = 0
                    seen_hashes = set()
                count += 1
                seen_hashes.add(fields[4])
            flush()
            error = process.stderr.read().decode()
            if process.wait():
                raise RuntimeError(error)
        except BaseException:
            process.kill()
            process.wait()
            raise
    result = {'input': str(source), 'identity_fields': ['query_sequence', 'RepeatMasker_source_ID', 'query_begin_1based', 'query_end_inclusive'], 'source_records': records, 'distinct_identities': identities, 'repeated_identity_groups': repeated, 'identity_groups_with_different_full_records': conflicts, 'examples': examples, 'source_modified': False, 'status': 'unique_id_coordinate_identities' if repeated == 0 else 'repeated_id_coordinate_identities'}
    output = folder / 'repeat_identity_audit.json'
    temp_output = Path(str(output) + '.part')
    temp_output.write_text(json.dumps(result, indent=2) + '\n')
    temp_output.replace(output)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    for strain in ['c57', 'cast']:
        audit(strain)
