#!/usr/bin/env python3
"""Re-read selected FASTA and compare sequence bytes to the source-stream hashes."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('selection_record',type=Path)
a=p.parse_args()
d=json.loads(a.selection_record.read_text())
observed={};name=None;length=0;digest=None
def finish():
    if name is None:return
    if name in observed:raise ValueError('Duplicate selected FASTA sequence '+name)
    observed[name]={'length':length,'sequence_sha256':digest.hexdigest()}
with gzip.open(d['output'],'rb') as f:
    for line in f:
        if line.startswith(b'>'):
            finish(); name=line[1:].split(None,1)[0].decode(); length=0; digest=hashlib.sha256()
        else:
            bases=line.strip()
            if name is None:raise ValueError('Sequence before header')
            length+=len(bases);digest.update(bases)
    finish()
if observed!=d['selected_sequences']:raise ValueError('Selected FASTA differs from source-stream hashes or lengths')
d['independent_selected_fasta_verification']={'passed':True,'sequences':len(observed),'bases':sum(x['length'] for x in observed.values()),'method':'Independent decompression and per-sequence SHA256 of exact case-preserved bases compared to hashes recorded while streaming the original provider FASTA.'}
a.selection_record.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(d['independent_selected_fasta_verification']))
