#!/usr/bin/env python3
"""Audit exact source repeat records, retaining identifiers and all coordinates.

This audit does not merge overlapping annotations or change input files. For
bigRmsk, compare original RepeatMasker fragment rows from description field 14,
not the joined browser display rows or visualization bounds.
"""
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--input', required=True, type=Path)
p.add_argument('--format', required=True, choices=['bed10', 'bigrmsk'])
p.add_argument('--output', required=True, type=Path)
a = p.parse_args()
seen = set(); identities = {}; counts = Counter(); examples = []
per_sequence = Counter(); duplicate_per_sequence = Counter()
with gzip.open(a.input, 'rb') as handle:
    for raw in handle:
        if not raw.strip() or raw.startswith(b'#'): continue
        counts['browser_or_bed_rows'] += 1
        fields = raw.rstrip(b'\r\n').split(b'\t')
        if a.format == 'bed10':
            if len(fields) != 10: raise ValueError('Expected BED10')
            records = [fields]
        else:
            if len(fields) != 14: raise ValueError('Expected bigRmsk BED14')
            records = [item.split() for item in fields[13].split(b',') if item.strip()]
        for record in records:
            if a.format == 'bed10':
                chrom = record[0]
                identity = b'\t'.join(record[i] for i in (0,1,2,3,5,9))
            else:
                if len(record) not in (15,16): raise ValueError('Expected RepeatMasker fragment')
                chrom = record[4]
                identity = b'\t'.join(record[i] for i in (4,5,6,8,9,14))
            canonical = b'\t'.join(record)
            counts['source_fragment_records'] += 1
            per_sequence[chrom.decode()] += 1
            if canonical in seen:
                counts['exact_duplicate_fragment_records'] += 1
                duplicate_per_sequence[chrom.decode()] += 1
                if len(examples)<5: examples.append(canonical.decode())
            else:
                seen.add(canonical)
            # Same ID/location/name/strand with different source fields requires
            # review, and is not treated as an exact duplicate.
            digest = hashlib.sha256(canonical).digest()
            previous = identities.setdefault(identity, digest)
            if previous != digest:
                counts['repeated_identity_with_different_record_fields'] += 1
counts['unique_exact_fragment_records'] = len(seen)
counts.setdefault('exact_duplicate_fragment_records',0)
counts.setdefault('repeated_identity_with_different_record_fields',0)
record={'input':str(a.input),'format':a.format,'comparison':'All original source fields, including identifier and coordinates; only whitespace separators canonicalized. bigRmsk descriptions audited fragment by fragment.',
        'counts':dict(counts),'source_fragments_per_sequence':dict(per_sequence),
        'exact_duplicates_per_sequence':dict(duplicate_per_sequence),'duplicate_examples':examples,
        'action':'audit only; input preserved; no overlaps or distinct identifiers merged'}
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record['counts'],sort_keys=True))
