#!/usr/bin/env python3
"""Convert base-level assembly alignments into TEvoX coverage and gap evidence.

Genome 1 is the PAF query; genome 2 is the PAF target. Output synteny coordinates
are 1-based inclusive. Gap coordinates remain PAF/BED 0-based half-open, with
start == end denoting an empty site. An anchored gap is alignment evidence only,
not a validated TE presence/absence polymorphism or an evolutionary gain/loss.
"""
import argparse
import collections
import csv
import gzip
import json
from pathlib import Path
import re


CIGAR = re.compile(r"([1-9][0-9]*)([MIDN=X])")
GAP_FIELDS = ["alignment_id", "query", "query_start", "query_end", "target",
              "target_start", "target_end", "strand", "operation", "gap_bp",
              "left_anchor_bp", "right_anchor_bp", "mapq", "aligned_identity", "aligned_bases",
              "evidence"]


def open_text(path, mode="rt"):
    return gzip.open(path, mode) if str(path).endswith(".gz") else open(path, mode)


def cigar_operations(cigar):
    """Normalize consecutive M/= /X operations into contiguous aligned runs."""
    operations = []
    cursor = 0
    for match in CIGAR.finditer(cigar):
        if match.start() != cursor:
            raise ValueError("Unsupported or malformed cg CIGAR")
        length, operation = int(match.group(1)), match.group(2)
        operation = "M" if operation in "M=X" else operation
        if operations and operations[-1][0] == operation:
            operations[-1] = (operation, operations[-1][1] + length)
        else:
            operations.append((operation, length))
        cursor = match.end()
    if not operations or cursor != len(cigar):
        raise ValueError("Unsupported or malformed cg CIGAR")
    return operations


def parse_paf(line):
    fields = line.rstrip("\r\n").split("\t")
    if len(fields) < 12:
        raise ValueError("PAF record has fewer than 12 fields")
    qlen, qs, qe = map(int, fields[1:4])
    tlen, ts, te = map(int, fields[6:9])
    matches, block_length, mapq = map(int, fields[9:12])
    if not (0 <= qs < qe <= qlen and 0 <= ts < te <= tlen):
        raise ValueError("PAF coordinates are inconsistent with sequence lengths")
    if fields[4] not in ("+", "-") or not 0 <= mapq <= 255:
        raise ValueError("Invalid PAF strand or MAPQ")
    if matches < 0 or block_length <= 0 or matches > block_length:
        raise ValueError("Invalid PAF match/block length")
    tags = {}
    for field in fields[12:]:
        key, kind, value = field.split(":", 2)
        tags[key] = (kind, value)
    return {"query": fields[0], "qs": qs, "qe": qe, "target": fields[5],
            "ts": ts, "te": te, "strand": fields[4], "mapq": mapq,
            "matches": matches, "tags": tags}


def validate_operations(record, operations):
    aligned = sum(length for op, length in operations if op == "M")
    query = sum(length for op, length in operations if op in ("M", "I"))
    target = sum(length for op, length in operations if op in ("M", "D", "N"))
    if query != record["qe"] - record["qs"] or target != record["te"] - record["ts"]:
        raise ValueError("cg CIGAR consumption differs from PAF query/target spans")
    if aligned == 0 or record["matches"] > aligned:
        raise ValueError("PAF matches are inconsistent with cg aligned bases")
    return aligned


def segments(record, operations):
    """Yield operation, query BED span, target BED span and neighboring anchors."""
    qpos = record["qs"] if record["strand"] == "+" else record["qe"]
    tpos = record["ts"]
    for index, (operation, length) in enumerate(operations):
        qnext = qpos
        tnext = tpos
        if operation in ("M", "I"):
            qnext += length if record["strand"] == "+" else -length
        if operation in ("M", "D", "N"):
            tnext += length
        left = operations[index - 1][1] if index and operations[index - 1][0] == "M" else 0
        right = (operations[index + 1][1]
                 if index + 1 < len(operations) and operations[index + 1][0] == "M" else 0)
        yield operation, length, min(qpos, qnext), max(qpos, qnext), tpos, tnext, left, right
        qpos, tpos = qnext, tnext


def convert(args):
    stats = collections.Counter()
    with open_text(args.paf) as source, open_text(args.synteny, "wt") as synteny, \
            open_text(args.gaps, "wt") as gap_output:
        synteny.write("# Genome1=query; genome2=target; 1-based inclusive aligned bases only\n")
        writer = csv.DictWriter(gap_output, fieldnames=GAP_FIELDS, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for line_number, line in enumerate(source, 1):
            if not line.strip() or line.startswith("#"):
                continue
            stats["input_alignments"] += 1
            try:
                record = parse_paf(line)
                if record["tags"].get("tp") != ("A", "P"):
                    stats["rejected_non_primary_or_unclassified"] += 1
                    continue
                if record["mapq"] == 255 or record["mapq"] < args.min_mapq:
                    stats["rejected_mapq"] += 1
                    continue
                cg = record["tags"].get("cg")
                if cg is None or cg[0] != "Z":
                    stats["rejected_missing_cigar"] += 1
                    continue
                operations = cigar_operations(cg[1])
                aligned = validate_operations(record, operations)
                identity = record["matches"] / aligned
                if aligned < args.min_alignment:
                    stats["rejected_short_alignment"] += 1
                    continue
                if identity < args.min_identity:
                    stats["rejected_identity"] += 1
                    continue
                stats["accepted_alignments"] += 1
                stats["aligned_bases_before_union"] += aligned
                for op, length, qs, qe, ts, te, left, right in segments(record, operations):
                    if op == "M":
                        synteny.write("{}\t{}\t{}\t{}\t{}\t{}\t{:.6f}\n".format(
                            record["query"], qs + 1, qe, record["target"], ts + 1, te, identity))
                        stats["synteny_blocks"] += 1
                    elif length >= args.min_gap:
                        anchored = op in ("I", "D") and min(left, right) >= args.min_anchor
                        evidence = "two_alignment_flanks" if anchored else "insufficient_or_complex_flanks"
                        writer.writerow(dict(alignment_id="paf:{}".format(line_number),
                            query=record["query"], query_start=qs, query_end=qe,
                            target=record["target"], target_start=ts, target_end=te,
                            strand=record["strand"], operation=op, gap_bp=length,
                            left_anchor_bp=left, right_anchor_bp=right, mapq=record["mapq"],
                            aligned_identity="{:.6f}".format(identity), aligned_bases=aligned,
                            evidence=evidence))
                        stats["gap_events"] += 1
                        stats["anchored_gap_events" if anchored else "other_gap_events"] += 1
            except (ValueError, IndexError) as error:
                raise ValueError("{}:{}: {}".format(args.paf, line_number, error)) from error
    summary = {"input_paf": str(Path(args.paf).resolve()), "thresholds": {
        "min_mapq": args.min_mapq, "min_aligned_identity": args.min_identity,
        "min_aligned_bases": args.min_alignment, "min_gap_bp": args.min_gap,
        "min_contiguous_anchor_bp": args.min_anchor}, "counts": dict(stats),
        "identity_definition": "PAF exact matches / CIGAR M,=,X bases; gap bases excluded",
        "interpretation": "Candidate alignment gaps only. MAPQ is not proof of unique orthology. "
                          "Require reciprocal flank mapping, assembly gap exclusion, annotation "
                          "comparability and manual/independent confirmation before biological inference."}
    with open(args.summary, "w") as destination:
        json.dump(summary, destination, indent=2)
        destination.write("\n")
    if not stats["accepted_alignments"]:
        raise ValueError("No qualifying alignments; refusing an empty-synteny whole-genome analysis")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("paf", "synteny", "gaps", "summary"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--min-mapq", type=int, default=30)
    parser.add_argument("--min-identity", type=float, default=0.95)
    parser.add_argument("--min-alignment", type=int, default=10000)
    parser.add_argument("--min-gap", type=int, default=50)
    parser.add_argument("--min-anchor", type=int, default=1000)
    args = parser.parse_args()
    if not (0 <= args.min_mapq <= 254 and 0 <= args.min_identity <= 1 and
            min(args.min_alignment, args.min_gap, args.min_anchor) > 0):
        parser.error("Invalid threshold")
    paths = [Path(getattr(args, name)).resolve() for name in ("paf", "synteny", "gaps", "summary")]
    if len(set(paths)) != len(paths):
        parser.error("Input and output paths must be distinct")
    try:
        convert(args)
    except (ValueError, OSError) as error:
        parser.exit(1, "Error: {}\n".format(error))


if __name__ == "__main__":
    main()
