#!/usr/bin/env python3
"""Independent read-only check of finished Arabidopsis gap candidates and FASTA flanks.

No alignment is rerun. CIGAR coordinate accumulation and raw sequence identity
are checked independently of the pipeline helpers. This is not a uniqueness test.
"""
import collections,csv,gzip,json,re
from pathlib import Path
from urllib.parse import unquote
ROOT=Path(__file__).resolve().parents[1] / 'results' / 'arabidopsis'
OUT=Path(__file__).resolve().parents[1] / 'metadata' / 'arabidopsis-real-evidence-audit.json'

def attrs(text):
    return {unquote(k):unquote(v) for k,v in (token.split('=',1) for token in text.split(';') if '=' in token)}

def fasta(path):
    result={}
    with gzip.open(path,'rt') as handle:
        name=None;chunks=[]
        for line in handle:
            if line.startswith('>'):
                if name is not None:result[name]=''.join(chunks).upper()
                name=line[1:].split()[0];chunks=[]
            else:chunks.append(line.strip())
        if name is not None:result[name]=''.join(chunks).upper()
    return result

def revcomp(text):
    return text.translate(str.maketrans('ACGTN','TGCAN'))[::-1]

manifest=json.loads((ROOT/'manifest.json').read_text())
all_rows=[]
metadata=[]
raw_annotations=[]
for side,g in enumerate(manifest['genomes']):
    with (ROOT/'evidence'/('genome%d.candidate_evidence.tsv'%(side+1))).open() as handle:
        rows=[dict(row,side=side) for row in csv.DictReader(handle,delimiter='\t') if row['category']=='anchored_gap_candidate']
    all_rows.extend(rows)
    keys={r['fragment_id'] for r in rows}
    with (ROOT/g['id']/'repeats.metadata.tsv').open() as handle:
        metadata.append({r['fragment_id']:r for r in csv.DictReader(handle,delimiter='\t') if r['fragment_id'] in keys})
    wanted={int(r['source_line']) for r in metadata[-1].values()}
    with gzip.open(g['repeats'],'rt') as handle:
        raw_annotations.append({number:line.strip().split('\t') for number,line in enumerate(handle,1) if number in wanted})
needed={int(r['selected_alignment_id'].split(':')[1]) for r in all_rows}
events={}
with gzip.open(ROOT/'alignment.paf.gz','rt') as handle:
    for number,line in enumerate(handle,1):
        if number not in needed:continue
        f=line.rstrip().split('\t');tags={x[:2]:x[5:] for x in f[12:]}
        qs,qe,ts=int(f[2]),int(f[3]),int(f[7]);minus=f[4]=='-'
        operations=[]
        for n,op in re.findall(r'(\d+)([MIDNSHP=X])',tags['cg']):
            n=int(n);op='A' if op in 'M=X' else op
            if operations and operations[-1][0]==op:operations[-1]=(op,operations[-1][1]+n)
            else:operations.append((op,n))
        qcons=tcons=0
        for i,(op,n) in enumerate(operations):
            if op in ('I','D'):
                qleft=(qe-qcons-n if minus else qs+qcons) if op=='I' else (qe-qcons if minus else qs+qcons)
                qright=qleft+n if op=='I' else qleft
                tleft=ts+tcons;tright=tleft+n if op=='D' else tleft
                left=operations[i-1][1] if i and operations[i-1][0]=='A' else 0
                right=operations[i+1][1] if i+1<len(operations) and operations[i+1][0]=='A' else 0
                side=0 if op=='I' else 1
                chrom,start,end,other,site=(f[0],qleft,qright,f[5],tleft) if side==0 else (f[5],tleft,tright,f[0],qleft)
                if min(left,right)>=1000:
                    events[(side,number,chrom,start,end)]={'other':other,'site':site,'strand':f[4],'left':left,'right':right,'operation':op}
            if op in ('A','I','S'):qcons+=n
            if op in ('A','D','N'):tcons+=n
        assert qcons==qe-qs and tcons==int(f[8])-ts
sequences=[fasta(g['fasta']) for g in manifest['genomes']]
checks=[]
for row in all_rows:
    side=row['side'];key=row['fragment_id'];meta=metadata[side][key]
    source=raw_annotations[side][int(meta['source_line'])];attr=attrs(source[8])
    assert source[0]==row['chrom'] and int(source[3])==int(row['start1']) and int(source[4])==int(row['end1'])
    assert attr['ID']==meta['source_id'] and attr['Name']==meta['repeat_name'] and attr['classification']==meta['original_class']
    gapstart,gapend=int(row['gap_start0']),int(row['gap_end0'])
    event=events[(side,int(row['selected_alignment_id'].split(':')[1]),row['chrom'],gapstart,gapend)]
    assert event['other']==row['opposite_chrom'] and event['site']==int(row['opposite_empty_site0']) and event['strand']==row['alignment_strand']
    assert event['left']==int(row['left_anchor_bp']) and event['right']==int(row['right_anchor_bp'])
    start,end=int(row['start1'])-1,int(row['end1'])
    fraction=(min(end,gapend)-max(start,gapstart))/(end-start)
    assert fraction>=.8 and abs(fraction-float(row['TE_fraction_in_gap']))<1e-6
    seq=sequences[side][row['chrom']];other=sequences[1-side][event['other']];site=event['site']
    left,right=seq[gapstart-1000:gapstart],seq[gapend:gapend+1000]
    otherleft,otherright=other[site-1000:site],other[site:site+1000]
    if event['strand']=='-':left,right=revcomp(left),revcomp(right);otherleft,otherright=otherright,otherleft
    assert all(len(x)==1000 and 'N' not in x for x in (left,right,otherleft,otherright))
    identities=[sum(a==b for a,b in zip(x,y))/1000 for x,y in ((left,otherleft),(right,otherright))]
    checks.append({'genome':side+1,'fragment_id':key,'source_ID':meta['source_id'],'source_feature':source[2],
                  'source_classification':attr['classification'],'canonical_class':row['canonical_class'],'repeat_family':row['repeat_family'],
                  'chrom':row['chrom'],'start1':int(row['start1']),'end1':int(row['end1']),
                  'alignment_id':row['selected_alignment_id'],'strand':event['strand'],'gap_start0':gapstart,'gap_end0':gapend,
                  'opposite_chrom':event['other'],'opposite_empty_site0':site,'TE_fraction_in_gap':fraction,
                  'left_1kb_sequence_identity':identities[0],'right_1kb_sequence_identity':identities[1]})
representative=[]
for side in (1,2):
    for strand in ('+','-'):
        chosen=set()
        for row in checks:
            gapkey=(row['alignment_id'],row['gap_start0'],row['gap_end0'])
            if row['genome']==side and row['strand']==strand and gapkey not in chosen:
                representative.append(row);chosen.add(gapkey)
                if len(chosen)==3:break
result={'scope':'All291 anchored Arabidopsis annotation-fragment candidates independently checked against original PAF cg, normalized-input GFF3 rows and raw FASTA. No new alignment, uniqueness or reciprocal validation.',
        'checked_candidate_fragments':len(checks),'strand_counts':dict(collections.Counter(str(r['genome'])+':'+r['strand'] for r in checks)),
        'coordinate_annotation_cigar_checks':'all passed','raw_flank_sequence_identity_min':min(min(r['left_1kb_sequence_identity'],r['right_1kb_sequence_identity']) for r in checks),
        'candidate_fragments_with_either_local_flank_identity_below_0_95':sum(min(r['left_1kb_sequence_identity'],r['right_1kb_sequence_identity'])<.95 for r in checks),
        'unique_gap_loci':len({(r['genome'],r['alignment_id'],r['chrom'],r['gap_start0'],r['gap_end0']) for r in checks}),
        'representative_different_gap_examples':representative,'all_fragment_checks':checks,
        'interpretation':'Global alignment identity and long contiguous aligned flanks do not establish independently unique orthology or local95% identity. Several fragments may belong to one gap. Source DNA/Helitron classifications are retained as DNA/Helitron, not silently reclassified.'}
OUT.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('all_fragment_checks','representative_different_gap_examples')},indent=2))
print(OUT)
