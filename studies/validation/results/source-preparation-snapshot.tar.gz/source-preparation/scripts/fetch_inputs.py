#!/usr/bin/env python3
"""Download one public input with resumable, checksum-verified provenance.

No authentication material is written to metadata or logs. An existing output is
only reused when its metadata binds it to the same URL and expected checksums.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
from urllib.parse import urlsplit, urlunsplit

VERSION = 1
DEFAULT_MAX = 6 * 1024 ** 3
RESERVE = 512 * 1024 ** 2


def utc_now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def public_url(url):
    """Omit credentials, fragments, and all query values, including signed URLs."""
    parsed = urlsplit(url)
    host = parsed.hostname or ''
    if ':' in host:
        host = '[' + host + ']'
    if parsed.port:
        host += ':' + str(parsed.port)
    query = 'REDACTED' if parsed.query else ''
    return urlunsplit((parsed.scheme, host, parsed.path, query, ''))


def redact_log(message):
    return re.sub(r'(?:https?|ftps?)://[^\s<>"\']+',
                  lambda m: public_url(m.group()), message)


def write_json(path, value):
    path = Path(path)
    fd, name = tempfile.mkstemp(prefix=path.name + '.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write('\n')
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def digest_file(path):
    md5 = hashlib.md5()
    sha256 = hashlib.sha256()
    size = 0
    with open(path, 'rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            size += len(chunk)
            md5.update(chunk)
            sha256.update(chunk)
    return {'bytes': size, 'md5': md5.hexdigest(), 'sha256': sha256.hexdigest()}


def check_digests(observed, md5=None, sha256=None, expected_bytes=None):
    for algorithm, expected in [('md5', md5), ('sha256', sha256)]:
        if expected and observed[algorithm] != expected:
            raise ValueError(algorithm.upper() + ' checksum mismatch')
    if expected_bytes is not None and observed['bytes'] != expected_bytes:
        raise ValueError('Size mismatch: expected %s bytes, observed %s' %
                         (expected_bytes, observed['bytes']))


def download(args):
    source = urlsplit(args.url)
    if source.scheme not in {'https', 'http', 'ftp', 'ftps'} or not source.hostname:
        raise ValueError('Expected a public HTTP(S) or FTP(S) URL')
    if source.username or source.password:
        raise ValueError('URL credentials are not supported; use public data sources')
    for algorithm, length in [('md5', 32), ('sha256', 64)]:
        value = getattr(args, algorithm)
        if value:
            value = value.lower()
            if not re.fullmatch('[0-9a-f]{%d}' % length, value):
                raise ValueError('Invalid ' + algorithm + ' checksum')
            setattr(args, algorithm, value)
    if args.max_bytes <= 0 or (args.expected_bytes is not None and args.expected_bytes <= 0):
        raise ValueError('Byte limits must be positive')
    if args.expected_bytes is not None and args.expected_bytes > args.max_bytes:
        raise ValueError('Expected input exceeds --max-bytes')
    output, record = Path(args.output).absolute(), Path(args.record).absolute()
    if output == record:
        raise ValueError('Output and metadata record must be different files')
    output.parent.mkdir(parents=True, exist_ok=True)
    record.parent.mkdir(parents=True, exist_ok=True)
    part = Path(str(output) + '.part')
    identity_path = Path(str(part) + '.json')
    lock = Path(str(output) + '.download.lock')
    if len({output, record, part, identity_path, lock, Path(str(record) + '.curl.log')}) != 6:
        raise ValueError('Output and record collide with downloader control files')
    for path in (output, record, part, identity_path, lock, Path(str(record) + '.curl.log')):
        if path.is_symlink():
            raise ValueError('Refusing symlink: ' + str(path))
    identity = {
        'url_sha256': hashlib.sha256(args.url.encode()).hexdigest(),
        'original_url': public_url(args.url),
        'expected_md5': args.md5,
        'expected_sha256': args.sha256,
        'expected_bytes': args.expected_bytes,
    }
    lock_fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.close(lock_fd)
    try:
        if output.exists():
            if not record.is_file():
                raise ValueError('Existing output has no provenance record; refusing to overwrite')
            previous = json.loads(record.read_text())
            if previous.get('request') != identity:
                raise ValueError('Existing output URL/checksum/size request differs; use a new output path')
            observed = digest_file(output)
            check_digests(observed, args.md5, args.sha256, args.expected_bytes)
            if previous.get('observed', {}).get('sha256') != observed['sha256']:
                raise ValueError('Existing output differs from its recorded SHA256')
            previous['last_revalidated_at'] = utc_now()
            previous['reused'] = True
            write_json(record, previous)
            return previous
        if record.exists():
            raise ValueError('Metadata exists without its output; preserve it and use a new output path')
        if part.exists():
            if not identity_path.exists() or json.loads(identity_path.read_text()) != identity:
                raise ValueError('Partial file has missing or different provenance; use a new output path')
        elif identity_path.exists() and json.loads(identity_path.read_text()) != identity:
            raise ValueError('Partial-file provenance differs; use a new output path')
        write_json(identity_path, identity)
        resumed_bytes = part.stat().st_size if part.exists() else 0
        if resumed_bytes > args.max_bytes:
            raise ValueError('Partial file exceeds --max-bytes')
        free = shutil.disk_usage(output.parent).free
        if free <= RESERVE:
            raise ValueError('Insufficient free space: maintain at least 512 MiB reserve')
        if args.expected_bytes and args.expected_bytes - resumed_bytes > free - RESERVE:
            raise ValueError('Insufficient disk space for expected input and 512 MiB reserve')
        effective_limit = min(args.max_bytes, resumed_bytes + free - RESERVE)
        command = ['curl', '--fail', '--location', '--silent', '--show-error',
                   '--retry', '3', '--retry-delay', '2', '--connect-timeout', '30',
                   '--continue-at', '-', '--max-filesize', str(effective_limit),
                   '--proto', '=http,https,ftp,ftps', '--proto-redir', '=http,https,ftp,ftps',
                   '--output', str(part), '--write-out', '%{url_effective}', '--url', args.url]
        started = utc_now()
        # Restrict permissions on temporary curl output, which may contain a signed URL.
        with tempfile.TemporaryFile(mode='w+b') as errors, tempfile.TemporaryFile(mode='w+b') as info:
            process = subprocess.Popen(command, stdout=info, stderr=errors)
            guard_error = None
            while process.poll() is None:
                if part.exists() and part.stat().st_size > args.max_bytes:
                    guard_error = 'Download exceeded --max-bytes'
                if shutil.disk_usage(output.parent).free < RESERVE:
                    guard_error = 'Download stopped to maintain 512 MiB disk reserve'
                if guard_error:
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                    break
                time.sleep(0.2)
            errors.seek(0)
            error_text = redact_log(errors.read().decode('utf-8', errors='replace'))
            info.seek(0)
            effective_url = info.read().decode('utf-8', errors='replace').strip()
        log_path = Path(str(record) + '.curl.log')
        log_path.write_text(error_text, encoding='utf-8')
        if guard_error:
            raise ValueError(guard_error)
        if process.returncode:
            raise ValueError('curl failed with exit code %d; see %s' % (process.returncode, log_path))
        observed = digest_file(part)
        try:
            if observed['bytes'] > args.max_bytes or observed['bytes'] == 0:
                raise ValueError('Downloaded file is empty or exceeds --max-bytes')
            check_digests(observed, args.md5, args.sha256, args.expected_bytes)
        except ValueError:
            # Only the downloader-owned, identity-bound partial file is removed.
            part.unlink()
            identity_path.unlink()
            raise
        verification = ('source_checksum_verified' if args.checksum_source else 'provided_checksum_verified') \
            if args.md5 or args.sha256 else 'local_sha256_only'
        result = {
            'schema_version': VERSION, 'request': identity,
            'original_url': public_url(args.url),
            'effective_url': public_url(effective_url or args.url),
            'output': str(output), 'observed': observed,
            'checksum_source': public_url(args.checksum_source) if args.checksum_source else None,
            'verification': verification,
            'verified_algorithms': [key for key in ('md5', 'sha256') if getattr(args, key)],
            'started_at': started, 'completed_at': utc_now(), 'reused': False,
            'resumed_bytes': resumed_bytes, 'curl_log': str(log_path),
        }
        os.replace(part, output)
        write_json(record, result)
        identity_path.unlink()
        return result
    finally:
        lock.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--record', required=True)
    parser.add_argument('--md5')
    parser.add_argument('--sha256')
    parser.add_argument('--checksum-source', help='Public publisher checksum-list URL (never a secret)')
    parser.add_argument('--expected-bytes', type=int)
    parser.add_argument('--max-bytes', type=int, default=DEFAULT_MAX, help='Default: 6 GiB')
    args = parser.parse_args()
    try:
        result = download(args)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print('Download error: ' + str(exc), file=sys.stderr)
        return 1
    print(json.dumps({'output': result['output'], 'bytes': result['observed']['bytes'],
                      'sha256': result['observed']['sha256'], 'verification': result['verification'],
                      'reused': result['reused']}, sort_keys=True))
    return 0


if __name__ == '__main__':
    sys.exit(main())
