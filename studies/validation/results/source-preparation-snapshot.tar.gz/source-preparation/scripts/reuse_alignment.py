#!/usr/bin/env python3
"""Reuse a verified completed alignment after changing annotations, never FASTAs.

The source success marker and all its outputs must remain valid. Both manifests
must use identical ordered FASTA fingerprints, preset, thread count, minimap2
binary hash and exact alignment options. Destination prepare must have passed.
No frozen run_pair.py code or source analysis artifacts are modified.
"""
import argparse
import fcntl
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile

from run_pair import Runner, ROOT, atomic_json, fingerprint, now, read_json, sha256_file


def expected_command(runner):
    genomes = runner.manifest['genomes']
    return [str(Path(runner.args.minimap2).resolve()), '-x', runner.manifest['preset'], '-c', '--eqx',
            '--secondary=no', '-t', str(runner.manifest['threads']), '-I6G', '-K250m',
            genomes[1]['fasta'], genomes[0]['fasta']]


def make_runner(manifest, out, args):
    return Runner(argparse.Namespace(manifest=str(manifest), output_dir=str(out), phase='align',
                                    tevox=args.tevox, minimap2=args.minimap2))


def reuse(args):
    source_dir = Path(args.source_dir).resolve(strict=True)
    destination_dir = Path(args.output_dir).resolve(strict=True)
    if source_dir == destination_dir:
        raise ValueError('Source and destination analysis directories must differ')
    if not (destination_dir / 'manifest.json').is_file():
        raise ValueError('Destination must first complete run_pair.py --phase prepare')
    source = make_runner(source_dir / 'manifest.json', source_dir, args)
    destination = make_runner(destination_dir / 'manifest.json', destination_dir, args)
    destination.phase = 'align'
    temporary = []
    linked_outputs = []
    completed = False
    lockpath = destination_dir / '.run_pair.lock'
    if lockpath.is_symlink():
        raise ValueError('Destination lock is a symlink')
    with lockpath.open('a+') as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError('Destination is owned by another workflow process')
        for path in (destination_dir / 'alignment.paf.gz', destination_dir / 'align.done.json',
                     destination_dir / 'reuse_alignment.provenance.json'):
            if path.exists() or path.is_symlink():
                raise ValueError('Refusing existing destination alignment/provenance: ' + str(path))
        source_signature = source.signature('align')
        if not source.valid_marker('prepare', source.signature('prepare')):
            raise ValueError('Source prepare marker missing or stale')
        if not source.valid_marker('align', source_signature):
            raise ValueError('Source alignment marker or output fingerprints are missing/stale')
        if not destination.valid_marker('prepare', destination.signature('prepare')):
            raise ValueError('Destination prepare marker missing or stale')
        destination_signature = destination.signature('align')
        for one, two in zip(source.manifest['genomes'], destination.manifest['genomes']):
            if fingerprint(one['fasta']) != fingerprint(two['fasta']):
                raise ValueError('Ordered FASTA inputs differ; a new alignment is required')
        if source.manifest['preset'] != destination.manifest['preset'] or source.manifest['threads'] != destination.manifest['threads']:
            raise ValueError('Alignment preset/threads differ')
        if source_signature['tools'][0]['sha256'] != destination_signature['tools'][0]['sha256']:
            raise ValueError('minimap2 binary SHA256 differs')
        source_commands = []
        with (source_dir / 'run_commands.jsonl').open() as handle:
            for line in handle:
                item = json.loads(line)
                if item.get('event') == 'command_started' and item.get('orientation') == 'query=genome1,target=genome2':
                    source_commands.append(item['command'])
        expected_source = expected_command(source)
        expected_destination = expected_command(destination)
        if not source_commands or source_commands[-1] != expected_source or expected_source != expected_destination:
            raise ValueError('Recorded source minimap2 options/orientation do not match expected destination command')
        source_marker_sha = sha256_file(source_dir / 'align.done.json')
        destination.disk_guard()
        source_alignment = source_dir / 'alignment.paf.gz'
        source_alignment_fingerprint = fingerprint(source_alignment)
        alignment_sha = sha256_file(source_alignment)
        destination_alignment = destination_dir / 'alignment.paf.gz'
        source_outputs = [source_alignment, source_dir / 'logs' / 'minimap2.stderr.log',
                          source_dir / 'logs' / 'minimap2.version.stdout.log']
        destination_outputs = [destination_alignment, destination_dir / 'logs' / 'minimap2.stderr.log',
                               destination_dir / 'logs' / 'minimap2.version.stdout.log']
        (destination_dir / 'logs').mkdir(exist_ok=True)
        method = None
        try:
            for index, (old, new) in enumerate(zip(source_outputs, destination_outputs)):
                if new.exists() or new.is_symlink():
                    raise ValueError('Refusing existing destination log: ' + str(new))
                fd, name = tempfile.mkstemp(prefix=new.name + '.', suffix='.part', dir=new.parent)
                os.close(fd)
                tmp = Path(name)
                temporary.append(tmp)
                if index == 0:
                    if shutil.disk_usage(new.parent).free < old.stat().st_size + 1024 ** 3:
                        raise ValueError('Insufficient disk space to copy alignment and preserve 1 GiB reserve')
                    shutil.copy2(old, tmp)
                    method = 'copy2'
                    if sha256_file(tmp) != alignment_sha:
                        raise ValueError('Transferred alignment SHA256 differs')
                else:
                    shutil.copy2(old, tmp)
                os.replace(tmp, new)
                linked_outputs.append(new)
            if source.signature('align') != source_signature or sha256_file(source_dir / 'align.done.json') != source_marker_sha:
                raise ValueError('Source inputs/marker changed during import')
            if destination.signature('align') != destination_signature:
                raise ValueError('Destination preparation or inputs changed during import')
            current_source_alignment = fingerprint(source_alignment)
            if current_source_alignment != source_alignment_fingerprint or sha256_file(source_alignment) != alignment_sha:
                raise ValueError('Source alignment content changed during import')
            if not source.valid_marker('align', source_signature):
                raise ValueError('Source marker/output fingerprints changed during import')
            provenance = {
                'status': 'completed', 'completed_at': now(), 'source_directory': str(source_dir),
                'destination_directory': str(destination_dir), 'source_align_marker_sha256': source_marker_sha,
                'source_alignment_fingerprint_before': source_alignment_fingerprint,
                'source_alignment_fingerprint_after': current_source_alignment,
                'alignment_sha256': alignment_sha, 'transfer_method': method,
                'verified_command': expected_destination,
                'ordered_fasta_fingerprints': [fingerprint(g['fasta']) for g in destination.manifest['genomes']],
                'reason': 'Only annotations/metadata changed; identical whole-genome alignment reused after destination prepare passed',
            }
            provenance_path = destination_dir / 'reuse_alignment.provenance.json'
            atomic_json(provenance_path, provenance)
            linked_outputs.append(provenance_path)
            atomic_json(destination_dir / 'align.done.json', {'status': 'completed', 'completed_at': now(),
                        'signature': destination_signature, 'outputs': [fingerprint(path) for path in destination_outputs],
                        'alignment_import': str(provenance_path)})
            destination.event(event='alignment_imported', source_directory=str(source_dir),
                              provenance=str(provenance_path), alignment_sha256=alignment_sha)
            destination.event(event='phase_finished', reused_alignment=True)
            completed = True
            return provenance
        finally:
            for path in temporary:
                path.unlink(missing_ok=True)
            if not completed:
                for path in linked_outputs:
                    path.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', required=True)
    parser.add_argument('--output-dir', required=True, help='Existing fresh destination with prepare.done.json')
    parser.add_argument('--minimap2', default=str(ROOT / 'tools' / 'minimap2-src' / 'minimap2'))
    parser.add_argument('--tevox', default=str(ROOT / 'tools' / 'tevox'))
    args = parser.parse_args()
    try:
        result = reuse(args)
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        parser.exit(1, 'Alignment reuse error: %s\n' % exc)
    print(json.dumps({'status': result['status'], 'method': result['transfer_method'],
                      'alignment_sha256': result['alignment_sha256']}))


if __name__ == '__main__':
    main()
