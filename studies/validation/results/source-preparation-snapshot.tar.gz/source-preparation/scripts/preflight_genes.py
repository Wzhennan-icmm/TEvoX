#!/usr/bin/env python3
"""Stream-validate exact GFF3 gene features against FASTA-derived sequence lengths.

No sequences are silently excluded or renamed and no transcript-to-gene fallback
is made. Other GFF feature types are counted but are not substituted for genes.
Exit 2 means malformed rows, invalid gene features, or no valid genes. Supports
plain/gzipped GFF3 and the normalizer's TSV/FAI/JSON sequence-length formats.
"""
import argparse
import collections
import csv
import json
from pathlib import Path
import sys
from normalize_annotations import attributes, open_text, protect_inputs, read_lengths, validate_interval


def preflight(args):
    summary_path = Path(args.summary)
    rejected_path = str(summary_path) + ".rejected.tsv"
    protect_inputs([args.input, args.lengths], [summary_path, rejected_path])
    lengths = read_lengths(args.lengths)
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    counts = collections.Counter()
    feature_counts, reasons = collections.Counter(), collections.Counter()
    sequences_with_genes = set()
    unknown_sequence_examples = []
    with open_text(args.input) as source, open(rejected_path, "w") as rejected:
        writer = csv.writer(rejected, delimiter="\t", lineterminator="\n")
        writer.writerow(["source_line", "reason", "source_record"])
        for lineno, line in enumerate(source, 1):
            counts["physical_lines_read"] += 1
            if line.startswith("##FASTA"):
                counts["embedded_fasta_sections_not_processed"] += 1
                break
            if not line.strip():
                counts["blank_lines"] += 1
                continue
            if line.startswith("#"):
                counts["comment_or_directive_lines"] += 1
                continue
            counts["feature_rows"] += 1
            fields = line.rstrip("\r\n").split("\t")
            if len(fields) != 9:
                reason = "gff_requires_nine_columns"
                counts["malformed_feature_rows"] += 1
                reasons[reason] += 1
                writer.writerow([lineno, reason, line.rstrip("\r\n")])
                continue
            feature_counts[fields[2]] += 1
            if fields[2] != "gene":
                counts["other_feature_rows"] += 1
                continue
            counts["gene_rows"] += 1
            try:
                start, end = int(fields[3]) - 1, int(fields[4])
                strand = "." if fields[6] == "?" else fields[6]
                validate_interval(fields[0], start, end, strand, lengths)
                attr = attributes(fields[8])
                if not attr.get("ID") or attr["ID"] == ".":
                    raise ValueError("gene_missing_id")
                if any(char in attr["ID"] for char in "\t\r\n"):
                    raise ValueError("gene_id_contains_control_character")
                counts["valid_gene_rows"] += 1
                sequences_with_genes.add(fields[0])
                if not attr.get("Name") or attr["Name"] == ".":
                    counts["genes_without_name"] += 1
            except ValueError as exc:
                reason = str(exc)
                if reason.startswith("invalid literal"):
                    reason = "malformed_integer"
                counts["invalid_gene_rows"] += 1
                reasons[reason] += 1
                if reason == "sequence_not_in_fasta" and fields[0] not in unknown_sequence_examples and len(unknown_sequence_examples) < 20:
                    unknown_sequence_examples.append(fields[0])
                writer.writerow([lineno, reason, line.rstrip("\r\n")])
    for key in ["physical_lines_read", "feature_rows", "gene_rows", "valid_gene_rows", "invalid_gene_rows", "other_feature_rows", "malformed_feature_rows"]:
        counts.setdefault(key, 0)
    valid = counts["valid_gene_rows"] > 0 and counts["invalid_gene_rows"] == 0 and counts["malformed_feature_rows"] == 0
    warnings = []
    if not counts["valid_gene_rows"]:
        warnings.append("No valid exact gene features; no transcript-to-gene fallback was invented.")
    if counts["genes_without_name"]:
        warnings.append("Some valid genes lack Name; stable gene IDs remain available.")
    summary = {
        "status": "passed" if valid else "failed",
        "input": str(args.input), "lengths": str(args.lengths), "gene_count": counts["valid_gene_rows"],
        "counts": dict(counts), "feature_counts": dict(feature_counts), "rejected_reasons": dict(reasons),
        "sequences_with_valid_genes": sorted(sequences_with_genes),
        "unknown_sequence_examples_first_20": unknown_sequence_examples,
        "coordinate_system": "one-based-inclusive", "validated_feature": "gene",
        "other_feature_policy": "Counted only; no substitution, coordinate validation, or inferred gene features.",
        "rejected_records": rejected_path, "warnings": warnings,
    }
    with open(summary_path, "w") as handle:
        json.dump(summary, handle, indent=2, sort_keys=True)
        handle.write("\n")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="GFF3 or GFF3.gz")
    parser.add_argument("--lengths", required=True, help="FASTA-derived TSV/FAI or JSON lengths; exact sequence IDs")
    parser.add_argument("--summary", required=True, help="Output JSON; rejected records go to <summary>.rejected.tsv")
    args = parser.parse_args()
    try:
        summary = preflight(args)
    except (OSError, ValueError) as exc:
        parser.exit(2, "Error: %s\n" % exc)
    print(json.dumps(summary, sort_keys=True))
    return 0 if summary["status"] == "passed" else 2


if __name__ == "__main__":
    sys.exit(main())
