#!/usr/bin/env python3
"""Generate an immutable, SHA256-pinned minimap2 launcher for an explicit profile.

The maize profile preserves complete query and target FASTAs and a single target
index. It strongly filters repetitive seeds and uses fewer minimizers; sensitivity
in repeat-rich regions is reduced. Its results must remain explicitly labeled.
The generated .profile.json documents settings; runtime never reads that sidecar.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

PROFILE_ID = 'maize_low_memory_v1'
OVERRIDES = ['-w19', '-f50', '-U50,50', '-e0', '-t1', '-K25m']
LIMITATIONS = [
    'Strong repeat-seed filtering reduces sensitivity in repeat-dense sequence; unaligned TE annotations are unresolved candidates, not proven biological absence.',
    'Window size 19 replaces asm20 window size 10; asm20 mismatch/gap scores are retained.',
    'Reference minimizers occurring more than 50 times are excluded; -e0 disables high-frequency seed rescue.',
    'Single target index (-I6G) preserves whole-target competition for MAPQ; MAPQ remains heuristic and conditional on filtered seeds.',
    'Whole FASTA records are retained without splitting; -K25m limits batches, not the memory needed for one chromosome.',
    'This profile lowers expected memory usage; it is not a hard per-process memory cap or a guarantee against allocation failure.',
]
LAUNCHER = r'''#!/usr/bin/env python3
"""Generated explicit minimap2 profile. Regenerate from make_minimap2_profile.py.

No runtime sidecar/environment overrides are consumed. Keep this launcher with
its run records; it pins the underlying executable bytes and complete profile.
"""
import hashlib
import json
import os
from pathlib import Path
import sys

CONFIG = __CONFIG__


def fail(message):
    print('Pinned minimap2 profile error: ' + message, file=sys.stderr)
    return 2


def main():
    args = sys.argv[1:]
    binary = Path(CONFIG['underlying_binary'])
    if not binary.is_file() or not os.access(binary, os.X_OK):
        return fail('underlying executable missing or not executable')
    digest = hashlib.sha256()
    with binary.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    if digest.hexdigest() != CONFIG['underlying_sha256']:
        return fail('underlying executable SHA256 changed; create a new reviewed launcher')
    if args == ['--version']:
        effective = [str(binary), '--version']
    else:
        # Frozen run_pair.py's exact assembly command. Do not silently accept
        # other presets, multipart indexing, filters or extra input FASTAs.
        if (len(args) != 11 or args[:6] != ['-x', 'asm20', '-c', '--eqx', '--secondary=no', '-t']
                or not args[6].isdigit() or not 1 <= int(args[6]) <= 64
                or args[7:9] != ['-I6G', '-K250m']):
            return fail('expected frozen run_pair asm20 command with -I6G -K250m, or --version')
        if any(name.startswith('-') or not Path(name).is_file() for name in args[-2:]):
            return fail('expected two existing complete FASTA paths')
        effective = [str(binary)] + args[:-2] + CONFIG['overrides'] + args[-2:]
    print('TEVOX_MINIMAP2_PROFILE ' + json.dumps({
        'profile_id': CONFIG['profile_id'],
        'underlying_sha256': CONFIG['underlying_sha256'],
        'requested_argv': args, 'effective_argv': effective,
        'scientific_scope': 'complete query and target FASTAs, single target index',
        'sensitivity': 'reduced in repetitive regions; candidate counts are profile-dependent',
    }, sort_keys=True), file=sys.stderr, flush=True)
    os.execv(str(binary), effective)
    return 127


if __name__ == '__main__':
    sys.exit(main())
'''


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        for data in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(data)
    return digest.hexdigest()


def generate(binary, output):
    binary = Path(binary).resolve(strict=True)
    output = Path(output).absolute()
    sidecar = Path(str(output) + '.profile.json')
    if not binary.is_file() or not os.access(binary, os.X_OK):
        raise ValueError('Underlying binary must be an executable regular file')
    if output == binary or sidecar == binary:
        raise ValueError('Launcher/provenance must not replace the underlying binary')
    if output.is_symlink() or sidecar.is_symlink():
        raise ValueError('Refusing symlink destination')
    descriptor = {'schema_version': 1, 'profile_id': PROFILE_ID, 'underlying_binary': str(binary),
                  'underlying_sha256': sha256_file(binary), 'overrides': OVERRIDES,
                  'override_position': 'after original run_pair options, immediately before the two FASTA paths',
                  'original_preset': 'asm20', 'whole_genome_inputs_preserved': True,
                  'target_index': 'single complete target, -I6G unchanged', 'limitations': LIMITATIONS,
                  'generator_sha256': sha256_file(Path(__file__))}
    content = LAUNCHER.replace('__CONFIG__', repr(descriptor))
    encoded = content.encode('utf-8')
    provenance = {**descriptor, 'launcher': str(output),
                  'launcher_sha256': hashlib.sha256(encoded).hexdigest()}
    if output.exists() and output.read_bytes() != encoded:
        raise ValueError('Existing launcher differs; choose a new output path to preserve prior provenance')
    if sidecar.exists() and json.loads(sidecar.read_text()) != provenance:
        raise ValueError('Existing sidecar differs; choose a new output path')
    output.parent.mkdir(parents=True, exist_ok=True)
    if not output.exists():
        with output.open('xb') as handle:
            handle.write(encoded)
        output.chmod(0o700)
    if not sidecar.exists():
        with sidecar.open('x') as handle:
            json.dump(provenance, handle, indent=2, sort_keys=True)
            handle.write('\n')
    return provenance


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', required=True, help='Underlying official minimap2 executable to pin by SHA256')
    parser.add_argument('--output', required=True, help='New executable launcher path')
    args = parser.parse_args()
    try:
        result = generate(args.binary, args.output)
    except (OSError, ValueError) as exc:
        parser.exit(2, 'Profile generation error: %s\n' % exc)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
