#!/usr/bin/env python3
import argparse
import gzip
import json
from pathlib import Path
import tempfile
import unittest

import deduplicate_repeatmasker
import reuse_alignment
import run_pair
import test_run_pair


class RepeatDedupTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    @staticmethod
    def row(start=10, identifier='1', family='LINE/L1'):
        return '100 1.0 0.0 0.0 chr1 %d %d (100) + L1 %s 1 11 (0) %s\n' % (start, start + 10, family, identifier)

    def run_dedup(self, text):
        source = self.root / 'raw.out.gz'
        with gzip.open(source, 'wt') as handle:
            handle.write(text)
        return deduplicate_repeatmasker.deduplicate(argparse.Namespace(input=str(source), output=str(self.root / 'dedup.out.gz'), report=str(self.root / 'dedup.json')))

    def test_only_exact_whitespace_normalized_duplicates_removed(self):
        one = self.row()
        distinct_id = self.row(identifier='2')
        distinct_family = self.row(start=30, identifier='3', family='SINE/B1')
        report = self.run_dedup('   SW score\n\n' + one + '  ' + one.replace(' ', '\t') + distinct_id + distinct_family)
        self.assertEqual(report['counts']['source_record_rows'], 4)
        self.assertEqual(report['counts']['retained_record_rows'], 3)
        self.assertEqual(report['counts']['removed_consecutive_duplicate_rows'], 1)
        self.assertEqual(report['multiplicity_histogram'], {'1': 2, '2': 1})
        self.assertEqual(gzip.open(report['output'], 'rt').read(), '   SW score\n\n' + one + distinct_id + distinct_family)
        self.assertTrue((self.root / 'raw.out.gz').exists())

    def test_nonconsecutive_duplicate_blocks_publication(self):
        with self.assertRaisesRegex(ValueError, 'Nonconsecutive duplicate'):
            self.run_dedup(self.row() + self.row(40, '2') + self.row())
        self.assertFalse((self.root / 'dedup.out.gz').exists())
        report = json.loads((self.root / 'dedup.json').read_text())
        self.assertEqual(report['counts']['retained_nonconsecutive_duplicate_rows'], 1)
        self.assertEqual(report['status'], 'failed_nonconsecutive_duplicates')

    def test_coordinate_order_audit_does_not_merge_records(self):
        report = self.run_dedup(self.row(40) + self.row(10, '2'))
        self.assertEqual(report['counts']['coordinate_order_violations'], 1)
        self.assertEqual(report['counts']['retained_record_rows'], 2)


class AlignmentReuseTests(unittest.TestCase):
    setUp = test_run_pair.PairIntegrationTests.setUp
    tearDown = test_run_pair.PairIntegrationTests.tearDown
    write_aligner = test_run_pair.PairIntegrationTests.write_aligner
    runner = test_run_pair.PairIntegrationTests.runner

    def corrected(self):
        self.runner('prepare').run()
        self.runner('align').run()
        manifest = json.loads(self.manifest.read_text())
        new_repeat = self.root / 'a_corrected.bed'
        new_repeat.write_text((self.root / 'a.bed').read_text() + 'chr1\t10030\t10040\tRepeatTwo\t0\t+\tLINE\n')
        manifest['genomes'][0]['repeats'] = str(new_repeat)
        manifest['pair_id'] = 'test_corrected'
        corrected_manifest = self.root / 'corrected.json'
        corrected_manifest.write_text(json.dumps(manifest))
        corrected_dir = self.root / 'corrected_outputs'
        corrected_runner = run_pair.Runner(argparse.Namespace(manifest=str(corrected_manifest), output_dir=str(corrected_dir), phase='prepare', minimap2=str(self.aligner), tevox=str(run_pair.ROOT / 'tools' / 'tevox')))
        corrected_runner.run()
        return corrected_runner, argparse.Namespace(source_dir=str(self.out), output_dir=str(corrected_dir), minimap2=str(self.aligner), tevox=str(run_pair.ROOT / 'tools' / 'tevox'))

    def test_reuse_after_annotation_change_preserves_source_marker(self):
        corrected, args = self.corrected()
        before = run_pair.fingerprint(self.out / 'alignment.paf.gz')
        report = reuse_alignment.reuse(args)
        self.assertEqual(report['transfer_method'], 'copy2')
        self.assertEqual(run_pair.fingerprint(self.out / 'alignment.paf.gz'), before)
        self.assertTrue(self.runner('align').valid_marker('align', self.runner('align').signature('align')))
        self.assertTrue(corrected.valid_marker('align', corrected.signature('align')))
        corrected.args.phase = 'finish'
        corrected.run()
        self.assertTrue((corrected.out / 'finish.done.json').exists())

    def test_reuse_rejects_modified_source_alignment(self):
        corrected, args = self.corrected()
        with (self.out / 'alignment.paf.gz').open('ab') as handle:
            handle.write(b'corruption')
        with self.assertRaisesRegex(ValueError, 'fingerprints'):
            reuse_alignment.reuse(args)
        self.assertFalse((corrected.out / 'align.done.json').exists())


if __name__ == '__main__':
    unittest.main()
