#!/usr/bin/env python3
"""Extract original RepeatMasker fragments from bigRmsk BED14 descriptions.

Browser display strand and block layout do not constrain fragment orientation:
joined elements can contain inverted and overlapping fragments. Every original
field and fragment is preserved; no fragments are merged or deduplicated.
"""
import argparse
from collections import Counter
from contextlib import ExitStack
import gzip
import hashlib
import json
import os
from pathlib import Path
import tempfile

HEADER = b'SW  perc_div  perc_del  perc_ins  query  begin  end  left  strand  repeat  class_family  repeat_begin  repeat_end  repeat_left  ID\nscore  div.  del.  ins.  sequence  begin  end  (left)  strand  repeat  class/family  begin  end  (left)  ID\n\n'
MAP_HEADER = b'output_record\toutput_physical_line\tselected_bed_physical_line\tfragment_index\tbrowser_record_id\tchrom\tstart_1based\tend_1based\tfragment_strand\tdisplay_strand\trepeatmasker_id\trepeat_name\tclass_family\tcanonical_fragment_sha256\taligned_start0\taligned_end0\toutside_aligned_summary\tquery_length_verified\n'

def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def open_input(path):
    return gzip.open(path, 'rb') if str(path).endswith('.gz') else open(path, 'rb')

def load_lengths(path, selection=False):
    if selection:
        record = json.loads(Path(path).read_text())
        lengths = {key: int(value['length']) for key, value in record['selected_sequences'].items()}
    else:
        lengths = {}
        for line in Path(path).read_text().splitlines():
            if not line.strip() or line.startswith('#'):
                continue
            fields = line.split()
            if len(fields) != 2 or fields[0] in lengths:
                raise ValueError('Invalid or duplicated chromosome length row')
            lengths[fields[0]] = int(fields[1])
    if not lengths or any(value <= 0 for value in lengths.values()):
        raise ValueError('Chromosome lengths must be positive')
    return lengths

def parse_source_row(line, lengths, allow_inconsistent_aligned_summary=False):
    fields = line.rstrip(b'\r\n').split(b'\t')
    if len(fields) != 14:
        raise ValueError('bigRmsk requires exactly 14 tab-separated fields')
    chrom = fields[0].decode('ascii')
    if chrom not in lengths:
        raise ValueError('Unknown chromosome ' + chrom)
    aligned_start, aligned_end = int(fields[6]), int(fields[7])
    if not 0 <= aligned_start < aligned_end <= lengths[chrom]:
        raise ValueError('Aligned interval outside chromosome bounds')
    if fields[5] not in (b'+', b'-'):
        raise ValueError('Invalid browser display strand')
    descriptions = [item.split() for item in fields[13].split(b',') if item.strip()]
    if not descriptions:
        raise ValueError('No original RepeatMasker descriptions')
    for row in descriptions:
        if len(row) not in (15, 16) or (len(row) == 16 and row[15] != b'*'):
            raise ValueError('Expected 15 RepeatMasker fields and optional overlap marker')
        if not row[0].isdigit() or row[8] not in (b'C', b'+', b'-'):
            raise ValueError('Invalid RepeatMasker score or original strand')
        if row[4] != fields[0]:
            raise ValueError('Fragment chromosome differs from browser record')
        begin, end = int(row[5]), int(row[6])
        if not 1 <= begin <= end <= lengths[chrom]:
            raise ValueError('Fragment outside chromosome bounds')
        if not row[7].startswith(b'(') or not row[7].endswith(b')') or not row[7][1:-1].isdigit():
            raise ValueError('Invalid original query remaining-length field')
        if end + int(row[7][1:-1]) != lengths[chrom]:
            raise ValueError('Original query end plus remaining length differs from FASTA chromosome length')
        if (begin - 1 < aligned_start or end > aligned_end) and not allow_inconsistent_aligned_summary:
            raise ValueError('Fragment outside aligned interval')
    return fields, descriptions

def gzip_output(stack, path):
    raw = stack.enter_context(open(path, 'wb'))
    return stack.enter_context(gzip.GzipFile(filename='', mode='wb', fileobj=raw, compresslevel=3, mtime=0))

def extract(args):
    length_path = args.selection_record or args.lengths
    lengths = load_lengths(length_path, bool(args.selection_record))
    inputs = {Path(args.input).resolve(), Path(length_path).resolve()}
    outputs = [Path(args.output), Path(args.source_map), Path(args.provenance)]
    if len({p.resolve() for p in outputs}) != len(outputs) or any(p.resolve() in inputs for p in outputs):
        raise ValueError('Output paths must be distinct from inputs and one another')
    if any(p.exists() or p.is_symlink() for p in outputs):
        raise ValueError('Refusing to replace existing output; choose fresh output paths')
    partials = []
    published = []
    completed = False
    try:
        for path in outputs:
            path.parent.mkdir(parents=True, exist_ok=True)
            fd, name = tempfile.mkstemp(prefix=path.name + '.', suffix='.part', dir=path.parent)
            os.close(fd)
            partials.append(Path(name))
        counts = Counter()
        per_sequence = Counter()
        examples = []
        summary_examples = []
        source_fragment_hash = hashlib.sha256()
        with ExitStack() as stack:
            output = gzip_output(stack, partials[0])
            mapping = gzip_output(stack, partials[1])
            source = stack.enter_context(open_input(args.input))
            output.write(HEADER)
            mapping.write(MAP_HEADER)
            for source_line, line in enumerate(source, 1):
                if not line.strip() or line.startswith(b'#'):
                    counts['source_comment_or_blank_lines'] += 1
                    continue
                try:
                    fields, fragments = parse_source_row(line, lengths, args.allow_inconsistent_aligned_summary)
                except (ValueError, UnicodeError) as error:
                    raise ValueError('Source line %d: %s' % (source_line, error)) from error
                counts['source_browser_records'] += 1
                counts['query_length_verified_fragments'] += len(fragments)
                outside_summary = [(i, fragment) for i, fragment in enumerate(fragments, 1) if int(fragment[5]) - 1 < int(fields[6]) or int(fragment[6]) > int(fields[7])]
                if outside_summary:
                    counts['aligned_summary_mismatch_source_records'] += 1
                    counts['fragments_outside_aligned_summary'] += len(outside_summary)
                    if len(summary_examples) < 20:
                        summary_examples.append({'selected_bed_physical_line': source_line, 'browser_record_id': fields[12].decode(), 'chrom': fields[0].decode(), 'browser_aligned_start0': int(fields[6]), 'browser_aligned_end0': int(fields[7]), 'original_fragment_envelope_start0': min(int(f[5])-1 for f in fragments), 'original_fragment_envelope_end0': max(int(f[6]) for f in fragments), 'fragments': [{'part': i, 'original_record': b' '.join(f).decode(), 'left_excess': max(0, int(fields[6]) - (int(f[5])-1)), 'right_excess': max(0, int(f[6]) - int(fields[7]))} for i, f in outside_summary]})
                if len(fragments) > 1:
                    counts['multi_fragment_source_records'] += 1
                strands = {b'-' if fragment[8] == b'C' else fragment[8] for fragment in fragments}
                mixed = len(strands) > 1
                if mixed:
                    counts['mixed_strand_source_records'] += 1
                    if len(examples) < 10:
                        examples.append({'selected_bed_physical_line': source_line, 'browser_record_id': fields[12].decode(), 'chrom': fields[0].decode(), 'aligned_start0': int(fields[6]), 'aligned_end0': int(fields[7]), 'display_strand': fields[5].decode(), 'original_fragment_strands': [f[8].decode() for f in fragments]})
                if len({fragment[14] for fragment in fragments}) > 1:
                    counts['mixed_repeatmasker_id_source_records'] += 1
                if any((b'-' if fragment[8] == b'C' else fragment[8]) != fields[5] for fragment in fragments):
                    counts['display_strand_mismatch_source_records'] += 1
                for part, fragment in enumerate(fragments, 1):
                    canonical = b'\t'.join(fragment) + b'\n'
                    source_fragment_hash.update(canonical)
                    output.write(canonical)
                    counts['output_fragment_records'] += 1
                    per_sequence[fragment[4].decode()] += 1
                    if (b'-' if fragment[8] == b'C' else fragment[8]) != fields[5]:
                        counts['display_strand_mismatch_fragments'] += 1
                    values = [str(counts['output_fragment_records']).encode(), str(counts['output_fragment_records'] + 3).encode(), str(source_line).encode(), str(part).encode(), fields[12], fragment[4], fragment[5], fragment[6], fragment[8], fields[5], fragment[14], fragment[9], fragment[10], hashlib.sha256(canonical).hexdigest().encode(), fields[6], fields[7], b'1' if int(fragment[5])-1 < int(fields[6]) or int(fragment[6]) > int(fields[7]) else b'0', b'1']
                    mapping.write(b'\t'.join(values) + b'\n')
        if args.expected_fragments is not None and counts['output_fragment_records'] != args.expected_fragments:
            raise ValueError('Fragment count differs from expected audited total')
        if not counts['output_fragment_records']:
            raise ValueError('No fragments extracted')
        # Independently read the actual compressed output, not a second writer
        # counter, to prove conservation of every original field and its order.
        output_fragment_hash = hashlib.sha256()
        observed_count = 0
        observed_per_sequence = Counter()
        with gzip.open(partials[0], 'rb') as source, gzip.open(partials[1], 'rb') as mapping:
            if mapping.readline() != MAP_HEADER:
                raise ValueError('Invalid source-map header')
            previous_source_line, previous_part = 0, 0
            for lineno, line in enumerate(source, 1):
                if lineno <= 3:
                    continue
                fields = line.split()
                canonical = b'\t'.join(fields) + b'\n'
                output_fragment_hash.update(canonical)
                observed_per_sequence[fields[4].decode()] += 1
                observed_count += 1
                mapped = mapping.readline().rstrip(b'\n').split(b'\t')
                if len(mapped) != 18 or int(mapped[0]) != observed_count or int(mapped[1]) != lineno:
                    raise ValueError('Source map record/line mismatch')
                source_line, part = int(mapped[2]), int(mapped[3])
                if source_line < previous_source_line or (source_line == previous_source_line and part != previous_part + 1) or (source_line > previous_source_line and part != 1):
                    raise ValueError('Source map row/part ordering mismatch')
                if mapped[5:9] != [fields[4], fields[5], fields[6], fields[8]] or mapped[10:13] != [fields[14], fields[9], fields[10]] or mapped[13] != hashlib.sha256(canonical).hexdigest().encode():
                    raise ValueError('Source map fragment identity mismatch')
                outside = int(fields[5])-1 < int(mapped[14]) or int(fields[6]) > int(mapped[15])
                if mapped[16] != (b'1' if outside else b'0') or mapped[17] != b'1' or int(fields[6]) + int(fields[7][1:-1]) != lengths[fields[4].decode()]:
                    raise ValueError('Source map interval or query-length verification mismatch')
                previous_source_line, previous_part = source_line, part
            if mapping.readline():
                raise ValueError('Source map contains extra records')
        if observed_count != counts['output_fragment_records'] or observed_per_sequence != per_sequence or output_fragment_hash.digest() != source_fragment_hash.digest():
            raise ValueError('Output fragment conservation verification failed')
        if args.expected_audit:
            audit = json.loads(Path(args.expected_audit).read_text())
            if Path(audit['input']).resolve() != Path(args.input).resolve():
                raise ValueError('Expected audit describes a different input file')
            if audit['counts']['source_fragment_records'] != observed_count or audit['source_fragments_per_sequence'] != dict(per_sequence):
                raise ValueError('Counts differ from the independently audited original descriptions')
        for key in ['mixed_strand_source_records', 'display_strand_mismatch_source_records', 'display_strand_mismatch_fragments', 'mixed_repeatmasker_id_source_records', 'aligned_summary_mismatch_source_records', 'fragments_outside_aligned_summary']:
            counts.setdefault(key, 0)
        record = {'schema_version': 1, 'status': 'passed', 'input': str(Path(args.input).resolve()), 'input_sha256': sha256_file(args.input), 'length_source': str(Path(length_path).resolve()), 'length_source_sha256': sha256_file(length_path), 'output': str(outputs[0].resolve()), 'output_sha256': sha256_file(partials[0]), 'source_map': str(outputs[1].resolve()), 'source_map_sha256': sha256_file(partials[1]), 'counts': dict(counts), 'fragments_per_sequence': dict(per_sequence), 'canonical_source_fragment_sha256': source_fragment_hash.hexdigest(), 'canonical_output_fragment_sha256': output_fragment_hash.hexdigest(), 'independent_output_reread_passed': True, 'independent_source_map_reread_passed': True, 'expected_audit': str(Path(args.expected_audit).resolve()) if args.expected_audit else None, 'expected_audit_sha256': sha256_file(args.expected_audit) if args.expected_audit else None, 'mixed_orientation_examples': examples, 'aligned_summary_mismatch_examples': summary_examples, 'allow_inconsistent_aligned_summary': args.allow_inconsistent_aligned_summary, 'script': str(Path(__file__).resolve()), 'script_sha256': sha256_file(__file__), 'coordinate_policy': 'Original RepeatMasker one-based inclusive coordinates preserved; validated against selected chromosome length, with query end + original remaining bases required to equal the exact FASTA length. BED aligned-summary mismatches are rejected by default; an explicit flag permits them with counts, examples, and per-fragment sidecar flags. No original coordinates changed.', 'strand_policy': 'Every original fragment C/+/- field is preserved. Browser display strand may differ, including within a mixed-orientation joined element.', 'identity_policy': 'All original fragment fields and their order preserved, including optional overlap marker; only whitespace separators canonicalized. No fragment merge, deduplication or filtering.', 'source_map_policy': 'Each output data record maps to a unique selected-BED physical line and one-based description fragment index; browser record ID is recorded separately.'}
        partials[2].write_text(json.dumps(record, indent=2) + '\n')
        for temporary, destination in zip(partials, outputs):
            os.replace(temporary, destination)
            published.append(destination)
        completed = True
        return record
    finally:
        if not completed:
            for destination in published:
                if destination.exists():
                    destination.unlink()
        for temporary in partials:
            if temporary.exists():
                temporary.unlink()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True)
    length_group = parser.add_mutually_exclusive_group(required=True)
    length_group.add_argument('--lengths', help='Two-column chromosome/length TSV')
    length_group.add_argument('--selection-record', help='Prepared human selection JSON containing selected_sequences')
    parser.add_argument('--output', required=True, help='New gzip RepeatMasker output path')
    parser.add_argument('--source-map', required=True, help='New gzip TSV source row/part map')
    parser.add_argument('--provenance', required=True)
    parser.add_argument('--expected-fragments', type=int)
    parser.add_argument('--allow-inconsistent-aligned-summary', action='store_true', help='Preserve original in-genome fragments whose end+remaining exactly matches FASTA length, recording browser summary mismatches without changing coordinates')
    parser.add_argument('--expected-audit', help='Prior audit JSON; compare total and per-chromosome fragment counts')
    args = parser.parse_args()
    try:
        record = extract(args)
    except (ValueError, OSError, KeyError, json.JSONDecodeError) as error:
        parser.exit(1, 'Extraction failed: %s\n' % error)
    print(json.dumps({'status': record['status'], 'output': record['output'], 'counts': record['counts'], 'canonical_fragment_sha256': record['canonical_output_fragment_sha256']}, sort_keys=True))

if __name__ == '__main__':
    main()
