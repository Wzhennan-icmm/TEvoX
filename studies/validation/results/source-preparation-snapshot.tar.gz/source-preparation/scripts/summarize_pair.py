#!/usr/bin/env python3
"""Summarize TEvoX assembly-specific annotation fragments and alignment evidence.

Genome 1 is the PAF query and genome 2 its target. This script does not establish
TE presence/absence polymorphisms, insertion/deletion direction, or causality.
"""
import argparse
from bisect import bisect_left, bisect_right
import collections
import csv
import json
from pathlib import Path
from typing import NamedTuple

from normalize_annotations import open_text, read_lengths, validate_interval
from annotate_candidates import read_candidates


class IntervalUnion:
    """Merged BED intervals with O(log n) covered-base queries."""
    def __init__(self, intervals):
        self.ranges = {}
        self.index = {}
        for chromosome, records in intervals.items():
            merged = []
            for start, end in sorted(records):
                if merged and start <= merged[-1][1]:
                    merged[-1] = (merged[-1][0], max(end, merged[-1][1]))
                else:
                    merged.append((start, end))
            starts, ends, prefix = [], [], [0]
            for start, end in merged:
                starts.append(start)
                ends.append(end)
                prefix.append(prefix[-1] + end - start)
            self.ranges[chromosome] = merged
            self.index[chromosome] = starts, ends, prefix

    def covered(self, chromosome, start, end):
        if start >= end or chromosome not in self.index:
            return 0
        starts, ends, prefix = self.index[chromosome]
        left = bisect_right(ends, start)
        right = bisect_left(starts, end)
        if left >= right:
            return 0
        return (prefix[right] - prefix[left] - max(0, start - starts[left])
                - max(0, ends[right - 1] - end))

    def total(self, chromosome):
        return self.index[chromosome][2][-1] if chromosome in self.index else 0


def load_n_runs(path, lengths):
    records = collections.defaultdict(list)
    with open_text(path) as handle:
        for number, line in enumerate(handle, 1):
            if not line.strip() or line.startswith("#"):
                continue
            fields = line.rstrip("\r\n").split("\t")
            if len(fields) < 3:
                raise ValueError("Malformed N-run BED at {}:{}".format(path, number))
            start, end = int(fields[1]), int(fields[2])
            validate_interval(fields[0], start, end, ".", lengths)
            records[fields[0]].append((start, end))
    return IntervalUnion(records)


def load_synteny(path, lengths):
    records = [collections.defaultdict(list), collections.defaultdict(list)]
    count = 0
    with open_text(path) as handle:
        for number, line in enumerate(handle, 1):
            if not line.strip() or line.startswith("#"):
                continue
            fields = line.rstrip("\r\n").split("\t")
            if len(fields) < 6:
                raise ValueError("Malformed synteny at {}:{}".format(path, number))
            for side in (0, 1):
                offset = side * 3
                chromosome, start, end = fields[offset], int(fields[offset + 1]) - 1, int(fields[offset + 2])
                validate_interval(chromosome, start, end, ".", lengths[side])
                records[side][chromosome].append((start, end))
            count += 1
    if not count:
        raise ValueError("Empty synteny cannot support whole-genome candidate interpretation")
    indices = []
    for side in (0, 1):
        indices.append(IntervalUnion(records[side]))
        records[side].clear()
    return indices, count


class Gap(NamedTuple):
    alignment_id: str
    chromosome: str
    start: int
    end: int
    opposite_chromosome: str
    opposite_site: int
    strand: str
    left_anchor: int
    right_anchor: int
    mapq: int
    identity: float
    aligned_bases: int


class GapIndex:
    """Balanced interval tree: prune by subtree endpoint and sorted start."""
    def __init__(self, records):
        self.by_chromosome = {}
        for chromosome, gaps in records.items():
            gaps.sort(key=lambda gap: (gap.start, gap.end, gap.alignment_id))
            subtree_end = [0] * len(gaps)

            def build(low, high):
                if low >= high:
                    return -1
                middle = (low + high) // 2
                value = max(gaps[middle].end, build(low, middle), build(middle + 1, high))
                subtree_end[middle] = value
                return value

            build(0, len(gaps))
            self.by_chromosome[chromosome] = gaps, subtree_end

    def overlaps(self, chromosome, start, end):
        if chromosome not in self.by_chromosome:
            return
        gaps, subtree_end = self.by_chromosome[chromosome]
        stack = [(0, len(gaps))]
        while stack:
            low, high = stack.pop()
            if low >= high:
                continue
            middle = (low + high) // 2
            if subtree_end[middle] <= start or gaps[low].start >= end:
                continue
            gap = gaps[middle]
            if gap.start < end and gap.end > start:
                yield gap
            stack.append((low, middle))
            if gap.start < end:
                stack.append((middle + 1, high))


def load_gaps(path, lengths, args):
    records = [collections.defaultdict(list), collections.defaultdict(list)]
    counts = collections.Counter()
    required = {"alignment_id", "query", "query_start", "query_end", "target", "target_start",
                "target_end", "strand", "operation", "left_anchor_bp", "right_anchor_bp",
                "mapq", "aligned_identity", "aligned_bases", "evidence"}
    with open_text(path) as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if not reader.fieldnames or not required <= set(reader.fieldnames):
            raise ValueError("Gap TSV must come from current paf_to_synteny.py (including aligned_bases)")
        for row in reader:
            counts["input_gap_events"] += 1
            operation = row["operation"]
            if operation not in ("I", "D"):
                counts["excluded_non_indel_gap"] += 1
                continue
            left, right, mapq = int(row["left_anchor_bp"]), int(row["right_anchor_bp"]), int(row["mapq"])
            identity, aligned = float(row["aligned_identity"]), int(row["aligned_bases"])
            if (row["evidence"] != "two_alignment_flanks" or min(left, right) < args.min_anchor_bp
                    or mapq == 255 or not args.min_mapq <= mapq <= 254
                    or not args.min_identity <= identity <= 1 or aligned < args.min_alignment_bp):
                counts["excluded_inadequate_alignment_or_flanks"] += 1
                continue
            side = 0 if operation == "I" else 1
            prefix, opposite = ("query", "target") if side == 0 else ("target", "query")
            chromosome, start, end = row[prefix], int(row[prefix + "_start"]), int(row[prefix + "_end"])
            other_chromosome, site = row[opposite], int(row[opposite + "_start"])
            validate_interval(chromosome, start, end, row["strand"], lengths[side])
            if (row["strand"] not in ("+", "-") or other_chromosome not in lengths[1 - side]
                    or site != int(row[opposite + "_end"])
                    or not 0 <= site <= lengths[1 - side][other_chromosome]):
                raise ValueError("Invalid orthologous empty-site coordinates in gap TSV")
            records[side][chromosome].append(Gap(row["alignment_id"], chromosome, start, end,
                other_chromosome, site, row["strand"], left, right, mapq, identity, aligned))
            counts["eligible_gap_events_genome{}".format(side + 1)] += 1
    return [GapIndex(records[0]), GapIndex(records[1])], counts


def coverage_summary(index, n_runs, lengths):
    contigs = {}
    overall = collections.Counter()
    for chromosome, length in lengths.items():
        aligned = index.total(chromosome)
        ns = n_runs.total(chromosome)
        aligned_ns = sum(n_runs.covered(chromosome, start, end)
                         for start, end in index.ranges.get(chromosome, []))
        row = dict(sequence_bp=length, N_bp=ns, non_N_bp=length - ns,
                   aligned_union_bp=aligned, aligned_non_N_bp=aligned - aligned_ns)
        overall.update(row)
        row["aligned_fraction"] = aligned / length
        row["aligned_non_N_fraction"] = (aligned - aligned_ns) / (length - ns) if length > ns else None
        contigs[chromosome] = row
    totals = dict(overall)
    totals["aligned_fraction"] = totals["aligned_union_bp"] / totals["sequence_bp"]
    totals["aligned_non_N_fraction"] = (totals["aligned_non_N_bp"] / totals["non_N_bp"]
                                         if totals["non_N_bp"] else None)
    return dict(overall=totals, per_contig=contigs)


EVIDENCE_FIELDS = ["fragment_id", "tevox_id", "chrom", "start1", "end1", "strand", "repeat_name",
    "canonical_class", "repeat_family", "classification_note", "category", "candidate_N_overlap_bp", "near_contig_edge",
    "quality_flags", "eligible_gap_count", "selected_alignment_id", "gap_start0", "gap_end0",
    "TE_fraction_in_gap", "opposite_chrom", "opposite_empty_site0", "alignment_strand", "mapq",
    "aligned_identity", "aligned_bases", "left_anchor_bp", "right_anchor_bp", "flank_N_overlap_bp"]
FLANK_FIELDS = ["genome", "fragment_id", "alignment_id", "source_chrom", "source_gap_start0",
    "source_gap_end0", "source_left_start0", "source_left_end0", "source_right_start0", "source_right_end0",
    "opposite_chrom", "opposite_empty_site0", "opposite_left_start0", "opposite_left_end0",
    "opposite_right_start0", "opposite_right_end0", "alignment_strand", "category"]


def summarize_side(side, args, lengths, coverage, ns, gap_index, flank_writer):
    candidates = getattr(args, "candidates" + str(side + 1))
    metadata_path = getattr(args, "metadata" + str(side + 1))
    candidate_keys = set()
    for row, _, _ in read_candidates(candidates, lengths[side]):
        if row[7] in candidate_keys:
            raise ValueError("Duplicate candidate fragment ID: " + row[7])
        candidate_keys.add(row[7])
    metadata = {}
    denominator_classes, denominator_families = collections.Counter(), collections.Counter()
    seen = set()
    with open_text(metadata_path) as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        required = {"fragment_id", "chrom", "start0", "end0", "repeat_name", "canonical_class", "family"}
        if not reader.fieldnames or not required <= set(reader.fieldnames):
            raise ValueError("Invalid normalization metadata TSV")
        for row in reader:
            key = row["fragment_id"]
            if key in seen:
                raise ValueError("Duplicate fragment ID in normalization metadata: " + key)
            seen.add(key)
            validate_interval(row["chrom"], int(row["start0"]), int(row["end0"]), ".", lengths[side])
            denominator_classes[row["canonical_class"]] += 1
            denominator_families[row["canonical_class"] + "/" + row["family"]] += 1
            if key in candidate_keys:
                metadata[key] = row
    if candidate_keys - metadata.keys():
        raise ValueError("Candidate fragment ID missing from normalization metadata")
    denominator = len(seen)
    del seen, candidate_keys
    counts, classes, families = collections.Counter(), collections.Counter(), collections.Counter()
    category_classes = collections.defaultdict(collections.Counter)
    output = Path(args.output_dir) / "genome{}.candidate_evidence.tsv".format(side + 1)
    with output.open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=EVIDENCE_FIELDS, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for row, start, end in read_candidates(candidates, lengths[side]):
            key, chromosome = row[7], row[1]
            meta = metadata[key]
            if (meta["chrom"], int(meta["start0"]), int(meta["end0"]), meta["canonical_class"]) != (chromosome, start, end, row[5]):
                raise ValueError("Candidate coordinates/class differ from metadata for " + key)
            if coverage[side].covered(chromosome, start, end):
                raise ValueError("Candidate overlaps supplied synteny; files are inconsistent for " + key)
            n_overlap = ns[side].covered(chromosome, start, end)
            edge = min(start, lengths[side][chromosome] - end) <= args.edge_bp
            eligible = []
            for gap in gap_index[side].overlaps(chromosome, start, end):
                fraction = (min(end, gap.end) - max(start, gap.start)) / (end - start)
                if fraction >= args.min_te_gap_fraction:
                    eligible.append((fraction, gap))
            eligible.sort(key=lambda item: (-item[0], -min(item[1].left_anchor, item[1].right_anchor),
                -item[1].identity, -item[1].mapq, item[1].end - item[1].start, item[1].alignment_id))
            flags = []
            if n_overlap:
                flags.append("candidate_overlaps_N")
            if edge:
                flags.append("source_contig_edge")
            selected = eligible[0] if eligible else None
            flank_row = None
            flank_ns = 0
            evidence = dict(fragment_id=key, tevox_id=row[0], chrom=chromosome, start1=row[2], end1=row[3],
                strand=row[4], repeat_name=meta["repeat_name"], canonical_class=meta["canonical_class"],
                repeat_family=meta["family"], classification_note=meta.get("classification_note", "."),
                candidate_N_overlap_bp=n_overlap, near_contig_edge=int(edge),
                eligible_gap_count=len(eligible))
            if selected:
                fraction, gap = selected
                anchor = args.min_anchor_bp
                source_flanks = [(gap.start - anchor, gap.start), (gap.end, gap.end + anchor)]
                other_flanks = [(gap.opposite_site - anchor, gap.opposite_site),
                                (gap.opposite_site, gap.opposite_site + anchor)]
                if (source_flanks[0][0] < 0 or source_flanks[1][1] > lengths[side][chromosome]
                        or other_flanks[0][0] < 0 or other_flanks[1][1] > lengths[1 - side][gap.opposite_chromosome]):
                    flags.append("flank_or_empty_site_contig_edge")
                flank_ns = sum(ns[side].covered(chromosome, a, b) for a, b in source_flanks)
                flank_ns += sum(ns[1 - side].covered(gap.opposite_chromosome, a, b) for a, b in other_flanks)
                if flank_ns:
                    flags.append("flank_or_empty_site_overlaps_N")
                evidence.update(selected_alignment_id=gap.alignment_id, gap_start0=gap.start, gap_end0=gap.end,
                    TE_fraction_in_gap="{:.6f}".format(fraction), opposite_chrom=gap.opposite_chromosome,
                    opposite_empty_site0=gap.opposite_site, alignment_strand=gap.strand, mapq=gap.mapq,
                    aligned_identity="{:.6f}".format(gap.identity), aligned_bases=gap.aligned_bases,
                    left_anchor_bp=gap.left_anchor, right_anchor_bp=gap.right_anchor)
                flank_row = [side + 1, key, gap.alignment_id, chromosome, gap.start, gap.end,
                    source_flanks[0][0], source_flanks[0][1], source_flanks[1][0], source_flanks[1][1],
                    gap.opposite_chromosome, gap.opposite_site, other_flanks[0][0], other_flanks[0][1],
                    other_flanks[1][0], other_flanks[1][1], gap.strand]
            category = ("low_quality_N_or_contig_edge" if flags else
                        "anchored_gap_candidate" if selected else "unresolved_outside_alignment")
            evidence.update(category=category, quality_flags=";".join(flags) or ".", flank_N_overlap_bp=flank_ns)
            writer.writerow({field: evidence.get(field, ".") for field in EVIDENCE_FIELDS})
            if flank_row is not None:
                flank_writer.writerow(flank_row + [category])
            counts[category] += 1
            classes[meta["canonical_class"]] += 1
            families[meta["canonical_class"] + "/" + meta["family"]] += 1
            category_classes[category][meta["canonical_class"]] += 1
    total = sum(counts.values())
    return {"normalized_annotation_fragments": denominator, "candidate_fragments": total,
        "candidate_fraction_of_annotation_fragments": total / denominator if denominator else None,
        "categories": dict(counts), "annotation_fragments_per_class": dict(denominator_classes),
        "candidate_fragments_per_class": dict(classes), "annotation_fragments_per_class_family": dict(denominator_families),
        "candidate_fragments_per_class_family": dict(families),
        "candidate_categories_per_class": {name: dict(counter) for name, counter in category_classes.items()},
        "coverage": coverage_summary(coverage[side], ns[side], lengths[side]), "evidence_tsv": str(output)}


def summarize(args):
    inputs = [getattr(args, name) for name in ("synteny", "gaps", "candidates1", "candidates2",
        "lengths1", "lengths2", "n_runs1", "n_runs2", "metadata1", "metadata2")]
    output_dir = Path(args.output_dir)
    outputs = [output_dir / name for name in ("genome1.candidate_evidence.tsv", "genome2.candidate_evidence.tsv",
                                              "candidate_flank_loci.tsv", "summary.json")]
    if {Path(path).resolve() for path in inputs} & {path.resolve() for path in outputs}:
        raise ValueError("Output paths must not overwrite any input")
    if any(path.is_symlink() or (path.exists() and not path.is_file()) for path in outputs):
        raise ValueError("Output destination must be a regular file or absent")
    lengths = [read_lengths(args.lengths1), read_lengths(args.lengths2)]
    ns = [load_n_runs(args.n_runs1, lengths[0]), load_n_runs(args.n_runs2, lengths[1])]
    coverage, block_count = load_synteny(args.synteny, lengths)
    gaps, gap_counts = load_gaps(args.gaps, lengths, args)
    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / "candidate_flank_loci.tsv").open("w") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(FLANK_FIELDS)
        sides = [summarize_side(side, args, lengths, coverage, ns, gaps, writer) for side in (0, 1)]
    result = {"genome1": sides[0], "genome2": sides[1], "synteny_block_rows": block_count,
        "gap_event_qc": dict(gap_counts), "thresholds": {key: value for key, value in vars(args).items()
            if key.startswith("min_") or key == "edge_bp"},
        "inputs": {name: str(Path(getattr(args, name)).resolve()) for name in
            ("synteny", "gaps", "candidates1", "candidates2", "lengths1", "lengths2", "n_runs1", "n_runs2", "metadata1", "metadata2")},
        "interpretation": "Counts are annotation fragments, not reconstructed insertion events. Anchored gaps remain candidates: "
            "independent unique reciprocal flank mapping has not been performed. Unaligned sequence, assembly gaps, "
            "contig boundaries, assembly quality, and incompatible repeat annotations can create differences. "
            "Do not infer true presence/absence, evolutionary direction, expression effects, or causality.",
        "category_meanings": {"anchored_gap_candidate": "TE fragment mostly within a qualifying alignment I/D gap; flanks not independently validated",
            "unresolved_outside_alignment": "Outside qualified aligned bases without a qualifying anchored I/D gap",
            "low_quality_N_or_contig_edge": "TE or selected gap flanks/empty site intersect N sequence or contig boundary criteria"},
        "coordinates": "Candidate start1/end1 are 1-based inclusive; gap/flank coordinates are 0-based half-open; empty sites have zero length."}
    with (output_dir / "summary.json").open("w") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("synteny", "gaps", "candidates1", "candidates2", "lengths1", "lengths2",
                 "n-runs1", "n-runs2", "metadata1", "metadata2", "output-dir"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--min-anchor-bp", type=int, default=1000)
    parser.add_argument("--min-alignment-bp", type=int, default=10000)
    parser.add_argument("--min-mapq", type=int, default=30)
    parser.add_argument("--min-identity", type=float, default=0.95)
    parser.add_argument("--min-te-gap-fraction", type=float, default=0.8)
    parser.add_argument("--edge-bp", type=int, default=1000)
    args = parser.parse_args()
    if (min(args.min_anchor_bp, args.min_alignment_bp) <= 0 or args.edge_bp < 0
            or not 0 <= args.min_mapq <= 254 or not 0 <= args.min_identity <= 1
            or not 0 < args.min_te_gap_fraction <= 1):
        parser.error("Invalid thresholds")
    try:
        result = summarize(args)
    except (ValueError, OSError, KeyError) as error:
        parser.exit(1, "Error: {}\n".format(error))
    print(json.dumps({"genome1_candidates": result["genome1"]["candidate_fragments"],
                      "genome2_candidates": result["genome2"]["candidate_fragments"],
                      "summary": str(Path(args.output_dir) / "summary.json")}))


if __name__ == "__main__":
    main()
