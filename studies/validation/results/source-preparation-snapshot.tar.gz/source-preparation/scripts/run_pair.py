#!/usr/bin/env python3
"""Reproducible whole-genome TEvoX pair workflow, with checked phase resumption.

Manifest: {"pair_id":"pair", "preset":"asm5", "threads":4, "genomes":[
 {"id":"a", "fasta":"a.fa.gz", "genes":"a.gff.gz", "repeats":"a.out.gz",
  "repeat_format":"repeatmasker-out", "normalize_args":[]}, {...}]}
Relative input paths resolve against the manifest directory. No sequence subsets
or sequence-name rewrites are performed. Input fingerprints include path, size,
mtime_ns, ctime_ns, device and inode; scripts and executable tools use SHA256.
"""
import argparse
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time

SCRIPTS = Path(__file__).resolve().parent
ROOT = SCRIPTS.parent
RESERVE = 1024 ** 3
SAFE_ID = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.-]*$')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def fingerprint(path, hash_content=False):
    path = Path(path).resolve(strict=True)
    stat = path.stat()
    if not path.is_file():
        raise ValueError('Expected a regular file: ' + str(path))
    result = {'path': str(path), 'size': stat.st_size, 'mtime_ns': stat.st_mtime_ns,
              'ctime_ns': stat.st_ctime_ns, 'device': stat.st_dev, 'inode': stat.st_ino}
    if hash_content:
        result['sha256'] = sha256_file(path)
    return result


def atomic_json(path, value):
    path = Path(path)
    fd, name = tempfile.mkstemp(prefix=path.name + '.', suffix='.part', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as handle:
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write('\n')
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def read_json(path):
    return json.loads(Path(path).read_text())


def load_manifest(path):
    source = Path(path).resolve(strict=True)
    manifest = read_json(source)
    if not SAFE_ID.fullmatch(str(manifest.get('pair_id', ''))):
        raise ValueError('pair_id must use letters, digits, dot, underscore or hyphen')
    if manifest.get('preset', 'asm5') not in {'asm5', 'asm10', 'asm20'}:
        raise ValueError('preset must be asm5, asm10 or asm20')
    manifest.setdefault('preset', 'asm5')
    manifest.setdefault('threads', 4)
    if type(manifest['threads']) is not int or not 1 <= manifest['threads'] <= 64:
        raise ValueError('threads must be an integer from 1 to 64')
    genomes = manifest.get('genomes')
    if not isinstance(genomes, list) or len(genomes) != 2:
        raise ValueError('Exactly two genomes are required')
    if len({g.get('id') for g in genomes}) != 2:
        raise ValueError('Genome IDs must differ')
    reserved = {'logs', 'evidence', 'alignment.paf.gz', 'manifest.json', 'run_commands.jsonl'}
    for genome in genomes:
        if not SAFE_ID.fullmatch(str(genome.get('id', ''))) or genome['id'] in reserved:
            raise ValueError('Invalid or reserved genome ID')
        for key in ('fasta', 'genes', 'repeats'):
            value = Path(genome[key])
            genome[key] = str((value if value.is_absolute() else source.parent / value).resolve(strict=True))
            if not Path(genome[key]).is_file():
                raise ValueError('Input is not a regular file: ' + genome[key])
        if genome['repeat_format'] not in {'repeatmasker-out', 'ucsc-rmsk', 'ucsc-bigrmsk-bed', 'repeat-gff3', 'te-bed'}:
            raise ValueError('Unsupported repeat_format')
        arguments = genome.setdefault('normalize_args', [])
        if not isinstance(arguments, list) or not all(isinstance(value, str) for value in arguments):
            raise ValueError('normalize_args must be a string list')
        allowed = {'--class-map', '--gff-feature', '--name-attribute', '--class-attribute', '--family-attribute',
                   '--bed-coordinates', '--bed-name-column', '--bed-class-column', '--bed-strand-column',
                   '--bed-family-column', '--bed-id-column'}
        if len(arguments) % 2 or any(arguments[i] not in allowed for i in range(0, len(arguments), 2)):
            raise ValueError('normalize_args must contain supported option/value pairs; input/output overrides forbidden')
        for index in range(0, len(arguments), 2):
            if arguments[index] == '--class-map':
                value = Path(arguments[index + 1])
                arguments[index + 1] = str((value if value.is_absolute() else source.parent / value).resolve(strict=True))
    if genomes[0]['fasta'] == genomes[1]['fasta']:
        raise ValueError('Both genomes refer to the same FASTA')
    return manifest


class Runner:
    def __init__(self, args):
        self.args = args
        self.manifest = load_manifest(args.manifest)
        self.out = Path(args.output_dir).absolute()
        self.out.mkdir(parents=True, exist_ok=True)
        if self.out.is_symlink():
            raise ValueError('Output directory must not be a symlink')
        self.log = self.out / 'run_commands.jsonl'
        self.phase = None
        self.lock = self.out / '.run_pair.lock'
        self.locked = False

    def event(self, **event):
        with self.log.open('a') as handle:
            handle.write(json.dumps({'time': now(), 'phase': self.phase, **event}, sort_keys=True) + '\n')

    def disk_guard(self):
        if shutil.disk_usage(self.out).free < RESERVE:
            raise ValueError('Maintain at least 1 GiB free disk space during pair analysis')

    def signature(self, phase):
        result = {'manifest': self.manifest, 'inputs': [], 'scripts': [], 'tools': [], 'phase': phase,
                  'input_fingerprint_policy': 'stat path,size,mtime_ns,ctime_ns,device,inode; scripts/tools SHA256'}
        for genome in self.manifest['genomes']:
            for key in ('fasta', 'genes', 'repeats'):
                result['inputs'].append(fingerprint(genome[key]))
            arguments = genome['normalize_args']
            if '--class-map' in arguments:
                result['inputs'].append(fingerprint(arguments[arguments.index('--class-map') + 1]))
        script_names = {'prepare': ['fasta_qc.py', 'normalize_annotations.py', 'preflight_genes.py'],
                        'align': [], 'finish': ['paf_to_synteny.py', 'summarize_pair.py',
                                               'annotate_candidates.py', 'normalize_annotations.py']}[phase]
        for name in ['run_pair.py'] + script_names:
            result['scripts'].append(fingerprint(SCRIPTS / name, True))
        if phase == 'align':
            result['tools'].append(fingerprint(self.args.minimap2, True))
            result['prepare_marker_sha256'] = sha256_file(self.out / 'prepare.done.json')
        if phase == 'finish':
            result['tools'].append(fingerprint(self.args.tevox, True))
            result['prepare_marker_sha256'] = sha256_file(self.out / 'prepare.done.json')
            result['align_marker_sha256'] = sha256_file(self.out / 'align.done.json')
        return result

    def valid_marker(self, phase, signature):
        marker = self.out / (phase + '.done.json')
        if not marker.exists():
            return False
        try:
            value = read_json(marker)
            if value['signature'] != signature or value.get('status') != 'completed':
                return False
            return all(fingerprint(item['path']) == item for item in value['outputs'])
        except (OSError, ValueError, KeyError):
            return False

    def command(self, command, label):
        self.disk_guard()
        stdout = self.out / 'logs' / (label + '.stdout.log')
        stderr = self.out / 'logs' / (label + '.stderr.log')
        command = [str(item) for item in command]
        self.event(event='command_started', command=command, stdout=str(stdout), stderr=str(stderr))
        start = time.monotonic()
        with stdout.open('w') as out, stderr.open('w') as err:
            result = subprocess.run(command, stdout=out, stderr=err, check=False)
        self.event(event='command_finished', command=command, exit_code=result.returncode,
                   elapsed_seconds=round(time.monotonic() - start, 3))
        if result.returncode:
            raise ValueError('%s failed (exit %d); see %s' % (label, result.returncode, stderr))

    def prepare(self):
        outputs = []
        for genome in self.manifest['genomes']:
            directory = self.out / genome['id']
            directory.mkdir(exist_ok=True)
            lengths, gaps, summary = [directory / name for name in ('lengths.tsv', 'n_runs.bed', 'fasta_qc.json')]
            self.command([sys.executable, SCRIPTS / 'fasta_qc.py', '--input', genome['fasta'], '--lengths', lengths,
                          '--n-runs', gaps, '--summary', summary, '--force'], genome['id'] + '.fasta_qc')
            prefix = directory / 'repeats'
            self.command([sys.executable, SCRIPTS / 'normalize_annotations.py', '--input', genome['repeats'],
                          '--format', genome['repeat_format'], '--lengths', lengths, '--output-prefix', prefix,
                          '--id-prefix', genome['id']] + genome['normalize_args'], genome['id'] + '.repeat_qc')
            if read_json(str(prefix) + '.qc.json')['counts'].get('retained_fragments', 0) <= 0:
                raise ValueError('No valid repeat annotation fragments for ' + genome['id'])
            gene_summary = directory / 'gene_preflight.json'
            self.command([sys.executable, SCRIPTS / 'preflight_genes.py', '--input', genome['genes'],
                          '--lengths', lengths, '--summary', gene_summary], genome['id'] + '.gene_preflight')
            if read_json(gene_summary).get('gene_count', 0) <= 0:
                raise ValueError('No valid genes for ' + genome['id'])
            outputs.extend([lengths, gaps, summary, gene_summary, Path(str(gene_summary) + '.rejected.tsv')])
            outputs.extend(Path(str(prefix) + suffix) for suffix in ('.bed', '.metadata.tsv', '.qc.json', '.rejected.tsv'))
        return outputs

    def align(self):
        genomes = self.manifest['genomes']
        command = [str(Path(self.args.minimap2).resolve()), '-x', self.manifest['preset'], '-c', '--eqx',
                   '--secondary=no', '-t', str(self.manifest['threads']), '-I6G', '-K250m',
                   genomes[1]['fasta'], genomes[0]['fasta']]
        output = self.out / 'alignment.paf.gz'
        part = Path(str(output) + '.part')
        error_log = self.out / 'logs' / 'minimap2.stderr.log'
        if part.is_symlink() or output.is_symlink():
            raise ValueError('Alignment outputs must not be symlinks')
        self.disk_guard()
        self.command([self.args.minimap2, '--version'], 'minimap2.version')
        self.event(event='command_started', command=command, stdout=str(output), stderr=str(error_log),
                   gzip_compression_level=1, orientation='query=genome1,target=genome2')
        start = time.monotonic()
        process = None
        byte_count = 0
        try:
            with error_log.open('wb') as errors, part.open('wb') as raw:
                process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=errors)
                with gzip.GzipFile(fileobj=raw, mode='wb', filename='', compresslevel=1, mtime=0) as compressed:
                    while True:
                        block = process.stdout.read(1024 * 1024)
                        if not block:
                            break
                        self.disk_guard()
                        byte_count += len(block)
                        compressed.write(block)
                process.stdout.close()
                returncode = process.wait()
            self.event(event='command_finished', command=command, exit_code=returncode,
                       uncompressed_paf_bytes=byte_count, elapsed_seconds=round(time.monotonic() - start, 3))
            if returncode:
                raise ValueError('minimap2 failed (exit %d); see %s' % (returncode, error_log))
            if byte_count == 0:
                raise ValueError('minimap2 emitted no alignments; cannot analyze whole-genome TE differences')
            os.replace(part, output)
            return [output, error_log, self.out / 'logs' / 'minimap2.version.stdout.log']
        finally:
            if process is not None:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                if process.stdout is not None:
                    process.stdout.close()
            part.unlink(missing_ok=True)

    def finish(self):
        directory1, directory2 = [self.out / genome['id'] for genome in self.manifest['genomes']]
        synteny, gaps, qc = [self.out / name for name in ('synteny.tsv', 'gaps.tsv', 'alignment_qc.json')]
        self.command([sys.executable, SCRIPTS / 'paf_to_synteny.py', '--paf', self.out / 'alignment.paf.gz',
                      '--synteny', synteny, '--gaps', gaps, '--summary', qc], 'paf_to_synteny')
        self.command([self.args.tevox, '--help'], 'tevox.version')
        self.command([self.args.tevox, synteny, directory1 / 'repeats.bed', directory2 / 'repeats.bed',
                      '-o', self.out / 'tevox'], 'tevox')
        candidates = [self.out / ('tevox_genome%d_unique.txt' % number) for number in (1, 2)]
        evidence = self.out / 'evidence'
        command = [sys.executable, SCRIPTS / 'summarize_pair.py', '--synteny', synteny, '--gaps', gaps,
                   '--candidates1', candidates[0], '--candidates2', candidates[1],
                   '--lengths1', directory1 / 'lengths.tsv', '--lengths2', directory2 / 'lengths.tsv',
                   '--n-runs1', directory1 / 'n_runs.bed', '--n-runs2', directory2 / 'n_runs.bed',
                   '--metadata1', directory1 / 'repeats.metadata.tsv', '--metadata2', directory2 / 'repeats.metadata.tsv',
                   '--output-dir', evidence]
        self.command(command, 'summarize_pair')
        outputs = [synteny, gaps, qc] + candidates
        outputs.extend(evidence / name for name in ('summary.json', 'genome1.candidate_evidence.tsv',
                                                   'genome2.candidate_evidence.tsv', 'candidate_flank_loci.tsv'))
        for number, genome in enumerate(self.manifest['genomes']):
            directory = self.out / genome['id']
            annotation = directory / 'candidate_genes.tsv'
            self.command([sys.executable, SCRIPTS / 'annotate_candidates.py', '--candidates', candidates[number],
                          '--genes', genome['genes'], '--metadata', directory / 'repeats.metadata.tsv',
                          '--lengths', directory / 'lengths.tsv', '--output', annotation], genome['id'] + '.candidate_genes')
            outputs.extend([annotation, Path(str(annotation) + '.qc.json'), Path(str(annotation) + '.genes_rejected.tsv')])
        return outputs

    def run(self):
        # flock releases on process termination and leaves no stale ownership lock.
        import fcntl
        lock_handle = self.lock.open('a+')
        try:
            try:
                fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise ValueError('Another run_pair process owns this output directory')
            for path in self.out.rglob('*'):
                if path.is_symlink():
                    raise ValueError('Refusing symlink inside output directory: ' + str(path))
            inputs = {Path(genome[key]).resolve() for genome in self.manifest['genomes'] for key in ('fasta', 'genes', 'repeats')}
            for path in inputs:
                if self.out.resolve() in path.parents:
                    raise ValueError('Input files must be outside the workflow output directory')
            manifest_path = self.out / 'manifest.json'
            if manifest_path.exists():
                if read_json(manifest_path) != self.manifest:
                    raise ValueError('Output directory belongs to a different manifest; use a new directory')
            else:
                # Existing QC from this study can be adopted only when its source matches.
                for genome in self.manifest['genomes']:
                    directory = self.out / genome['id']
                    if directory.exists() and any(directory.iterdir()):
                        qc_path = directory / 'fasta_qc.json'
                        if not qc_path.is_file() or read_json(qc_path).get('input') != genome['fasta']:
                            raise ValueError('Existing genome output has no matching FASTA QC provenance: ' + str(directory))
                        if any(path.name not in {'lengths.tsv', 'n_runs.bed', 'fasta_qc.json'} for path in directory.iterdir()):
                            raise ValueError('Existing outputs not owned by this runner; use a new directory')
                if any((self.out / filename).exists() for filename in ('alignment.paf.gz', 'synteny.tsv', 'tevox_genome1_unique.txt', 'tevox_genome2_unique.txt')):
                    raise ValueError('Existing analysis has no run manifest; use a new output directory')
                atomic_json(manifest_path, self.manifest)
            (self.out / 'logs').mkdir(exist_ok=True)
            phases = ('prepare', 'align', 'finish') if self.args.phase == 'all' else (self.args.phase,)
            for phase in phases:
                self.phase = phase
                if phase in {'align', 'finish'} and not self.valid_marker('prepare', self.signature('prepare')):
                    raise ValueError('prepare marker missing/stale; run --phase prepare first')
                if phase == 'finish' and not self.valid_marker('align', self.signature('align')):
                    raise ValueError('align marker missing/stale; run --phase align first')
                signature = self.signature(phase)
                if self.valid_marker(phase, signature):
                    self.event(event='phase_reused', phase=phase)
                    print(phase + ': validated existing outputs', flush=True)
                    continue
                (self.out / (phase + '.done.json')).unlink(missing_ok=True)
                self.event(event='phase_started', phase=phase)
                try:
                    outputs = getattr(self, phase)()
                    if self.signature(phase) != signature:
                        raise ValueError('Inputs/scripts/tools changed during ' + phase + '; no success marker saved')
                except Exception as error:
                    self.event(event='phase_failed', phase=phase, error=str(error))
                    raise
                atomic_json(self.out / (phase + '.done.json'), {'status': 'completed', 'completed_at': now(),
                            'signature': signature, 'outputs': [fingerprint(path) for path in outputs]})
                self.event(event='phase_finished', phase=phase)
                print(phase + ': completed', flush=True)
        finally:
            lock_handle.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--phase', choices=['prepare', 'align', 'finish', 'all'], default='all')
    parser.add_argument('--tevox', default=str(ROOT / 'tools' / 'tevox'))
    parser.add_argument('--minimap2', default=str(ROOT / 'tools' / 'minimap2-src' / 'minimap2'))
    args = parser.parse_args()
    try:
        Runner(args).run()
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as error:
        print('Pair workflow error: ' + str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
