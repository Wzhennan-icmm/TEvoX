#!/usr/bin/env python3
"""Attach completed exact-record and identity audits to verified mouse tuples."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    temporary = Path(str(path) + '.part')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def main():
    source_path = ROOT / 'discovery/mouse_sources.json'
    source = json.loads(source_path.read_text())
    rows = []
    tools = {name: {'path': str(ROOT / 'scripts' / name), 'sha256': digest(ROOT / 'scripts' / name)} for name in ['select_mouse_primary.py', 'fasta_select_fast.py', 'fasta_qc.py', 'preflight_genes.py', 'audit_repeat_duplicates.py', 'audit_repeat_identities.py']}
    for assembly in source['assemblies']:
        folder = ROOT / 'data/mouse' / assembly['id']
        provenance_path = folder / 'primary_selection.provenance.json'
        provenance = json.loads(provenance_path.read_text())
        audits = {}
        for key, filename, expected in [('full_record', 'repeat_duplicate_audit.json', 'no_exact_duplicates'), ('id_coordinates', 'repeat_identity_audit.json', 'unique_id_coordinate_identities')]:
            path = folder / filename
            audit = json.loads(path.read_text())
            assert audit['status'] == expected, audit
            assert audit['source_records'] == provenance['repeats']['counts']['source_rows']
            audits[key] = {'path': str(path), 'sha256': digest(path), 'result': audit}
        provenance['repeat_record_audits'] = audits
        provenance['selection_tools'] = tools
        provenance['repeat_audit_conclusion'] = 'No duplicate full source records or repeated source ID+query coordinate identities. Selected files are unchanged full-record subsets, so neither requires deduplication. No overlapping annotations or distinct IDs were merged.'
        write_json(provenance_path, provenance)
        fq = provenance['fasta_qc']
        gc = provenance['genes']['counts']
        rc = provenance['repeats']['counts']
        counts = {'selected_sequences': fq['selected_sequence_count'], 'selected_bases': fq['selected_bases'], 'excluded_sequences': fq['excluded_sequence_count'], 'excluded_bases': fq['excluded_bases'], 'selected_gene_feature_rows': provenance['genes']['selected_feature_types']['gene'], 'selected_gff_feature_rows': gc['selected_feature_rows'], 'excluded_gff_feature_rows': gc['excluded_feature_rows'], 'selected_repeat_rows': rc['selected_rows'], 'excluded_repeat_rows': rc['excluded_rows'], 'raw_repeat_rows': rc['source_rows'], 'exact_duplicate_repeat_groups': 0, 'repeated_id_coordinate_groups': 0}
        assembly['analysis_selection'].update({'counts': counts, 'provenance_sha256': digest(provenance_path), 'repeat_audits': {k: {'path': v['path'], 'sha256': v['sha256']} for k, v in audits.items()}})
        rows.append('| '+assembly['strain']+' | '+str(counts['selected_sequences'])+' | '+f"{counts['selected_bases']:,}"+' | '+f"{counts['selected_gene_feature_rows']:,}"+' | '+f"{counts['selected_repeat_rows']:,}"+' | '+f"{counts['excluded_sequences']:,}"+' | '+f"{counts['excluded_repeat_rows']:,}"+' |')
    source['status'] = 'downloaded_verified_primary_nuclear_tuples_and_repeat_audits_ready'
    write_json(source_path, source)
    md = ROOT / 'discovery/mouse_sources.md'
    text = md.read_text().replace(' (written after verified selection)', '')
    section = '\n## Completed selection and record audits\n\n| Strain | Whole nuclear chromosomes | Selected bases | Literal gene features | Selected repeat rows | Excluded sequences | Excluded repeat rows |\n|---|---:|---:|---:|---:|---:|---:|\n'+'\n'.join(rows)+'\n\nBoth GFF preflights passed with zero invalid gene rows and zero unknown sequence IDs. All primary sequence lengths match the exact NCBI assembly reports and Ensembl sequence-region directives. All GFF feature types are preserved; literal `gene` counts above exclude separately typed `ncRNA_gene` and `pseudogene` features. Stable Ensembl gene IDs remain available, though selected `gene` rows lack `Name`.\n\nBounded external-sort audits of all raw RepeatMasker records found zero whitespace-canonical full-record duplicates and zero repeated query/source-ID/start/end identities in either strain. Full-record comparison includes every field, the source ID and optional overlap marker. Primary files preserve source records without deduplication or overlap merging; they are strict subsets of the audited raw files. Per-strain `repeat_duplicate_audit.json`, `repeat_identity_audit.json` and selection provenance store counts, evidence and SHA256 hashes.\n'
    if '\n## Completed selection and record audits\n' in text:
        text = text.split('\n## Completed selection and record audits\n')[0]
    md.write_text(text.rstrip()+'\n'+section)
    print('MOUSE_TUPLES_AUDITED_READY', ROOT / 'metadata/mouse_pair.json')
    print('\n'.join(rows))


if __name__ == '__main__':
    main()
