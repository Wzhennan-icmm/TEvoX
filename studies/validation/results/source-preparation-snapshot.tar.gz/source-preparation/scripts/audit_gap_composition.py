#!/usr/bin/env python3
"""Audit retained TE annotation inside supported structural gaps; no event claims."""
import argparse
from array import array
from bisect import bisect_left, bisect_right
import collections
import csv
import datetime
import gzip
import json
import os
from pathlib import Path
import sqlite3
import tempfile

import annotation_coverage as coverage


SUPPORTED = "reciprocal_unique_flank_supported_candidate"
FIELDS = ["pair_id", "genome", "genome_id", "material", "assembly", "locus_id", "alignment_id", "source_chrom",
    "source_gap_start0", "source_gap_end0", "gap_length_bp", "opposite_chrom", "opposite_empty_site0", "alignment_strand",
    "supported_fragment_count", "supported_repeat_classes_json", "retained_annotation_union_bp", "retained_annotation_gap_fraction",
    "supported_candidate_union_bp", "supported_candidate_gap_fraction", "retained_class_union_bp_json", "retained_class_gap_fraction_json"]


def record(path):
    result = coverage.fingerprint(path)
    result["sha256"] = coverage.sha256(path)
    return result


def validate_records(records):
    for item in records:
        if record(item["path"]) != item:
            raise ValueError("Provenance fingerprint/hash differs: " + item["path"])


class UnionIndex:
    """Packed disjoint intervals with prefix lengths; accepts start-sorted input."""
    def __init__(self):
        self.starts, self.ends, self.prefix = array("Q"), array("Q"), array("Q")
        self.previous_start = -1

    def add(self, start, end):
        if not 0 <= start < end or start < self.previous_start:
            raise ValueError("Union input must be valid and sorted")
        self.previous_start = start
        if self.ends and start <= self.ends[-1]:
            extra = max(0, end - self.ends[-1])
            self.ends[-1] += extra
            self.prefix[-1] += extra
        else:
            self.starts.append(start)
            self.ends.append(end)
            self.prefix.append((self.prefix[-1] if self.prefix else 0) + end - start)

    def covered(self, start, end):
        if end <= start:
            return 0
        first, stop = bisect_right(self.ends, start), bisect_left(self.starts, end)
        if first >= stop:
            return 0
        total = self.prefix[stop - 1] - (self.prefix[first - 1] if first else 0)
        return total - max(0, start - self.starts[first]) - max(0, self.ends[stop - 1] - end)


def annotation_indices(bed, lengths, folder):
    connection = sqlite3.connect(str(Path(folder) / "intervals.sqlite"))
    indices = {}
    try:
        coverage.build_database(connection, bed, lengths)
        for chrom, start, end, category in connection.execute("SELECT chrom,start,end,category FROM intervals ORDER BY chrom,start,end"):
            chrom_indices = indices.setdefault(chrom, {})
            chrom_indices.setdefault(None, UnionIndex()).add(start, end)
            chrom_indices.setdefault(category, UnionIndex()).add(start, end)
    finally:
        connection.close()
    return indices


def gene_scope(path):
    counts = collections.Counter()
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt") as handle:
        for lineno, line in enumerate(handle, 1):
            if line.startswith("##FASTA"):
                break
            if not line.strip() or line.startswith("#"):
                continue
            fields = line.rstrip("\r\n").split("\t")
            if len(fields) != 9:
                raise ValueError("Invalid GFF source row %d" % lineno)
            counts[fields[2]] += 1
    return dict(included_feature_type="gene", included_exact_gene_rows=counts.get("gene", 0),
        source_feature_counts=dict(counts), omitted_feature_counts={name: count for name, count in counts.items() if name != "gene"},
        omitted_other_gene_like_features={name: count for name, count in counts.items() if name != "gene" and (name.endswith("_gene") or name == "pseudogene")},
        interpretation="Existing gene-neighborhood analysis uses exact GFF3 feature=gene only; other gene-like features are outside its scope. Gene-body proximity does not imply function, expression, or causation.")


def read_tsv(path):
    with Path(path).open() as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def coordinate_audit(loci):
    source, opposite, paired = (collections.defaultdict(list) for _ in range(3))
    second_boundaries = collections.defaultdict(list)
    for row in loci:
        side = row["genome"]
        interval = (row["source_chrom"], int(row["source_gap_start0"]), int(row["source_gap_end0"]))
        point = (row["opposite_chrom"], int(row["opposite_empty_site0"]), int(row["opposite_empty_site0"]))
        source[(side,) + interval].append(row)
        opposite[("2" if side == "1" else "1",) + point].append(row)
        paired[(interval, point) if side == "1" else (point, interval)].append(row)
        if side == "2":
            for boundary in interval[1:]:
                second_boundaries[(interval[0], boundary, point[0], point[1])].append(row["locus_id"])
    boundary_matches = set()
    for row in loci:
        if row["genome"] != "1":
            continue
        for boundary in (int(row["source_gap_start0"]), int(row["source_gap_end0"])):
            key = (row["opposite_chrom"], int(row["opposite_empty_site0"]), row["source_chrom"], boundary)
            for second in second_boundaries.get(key, []):
                boundary_matches.add((row["locus_id"], second))
    return dict(source_interval_exact_duplicate_groups=sum(len(group) > 1 for group in source.values()),
        source_interval_duplicates_with_different_alignment_ids=sum(len({row["alignment_id"] for row in group}) > 1 for group in source.values()),
        opposite_empty_point_exact_duplicate_groups=sum(len(group) > 1 for group in opposite.values()),
        normalized_paired_interval_exact_duplicate_groups=sum(len(group) > 1 for group in paired.values()),
        cross_side_mutual_exact_gap_boundary_matches=[list(pair) for pair in sorted(boundary_matches)],
        interpretation="Exact numerical coordinate audit only, ignoring alignment IDs for coordinate grouping. "
            "A paired representation uses the source interval and opposite zero-length site, ordered by genome. "
            "Cross-side boundary matches require each opposite point to equal a boundary of the other source interval. "
            "No biological event clustering, equivalence inference, or merging is performed.")


def analyze(directory, temporary_directory=None):
    directory = Path(directory).resolve()
    manifest_path = directory / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    priority_path = directory / "priority_summary.json"
    priority = json.loads(priority_path.read_text())
    if priority.get("pair_id") != manifest["pair_id"] or len(manifest["genomes"]) != 2:
        raise ValueError("Priority export/manifest pair identity differs")
    outputs, inputs = priority.get("outputs", []), priority.get("signature", {}).get("inputs", [])
    expected_outputs = {str(directory / name) for name in ("priority_candidates.tsv", "priority_loci.tsv")}
    expected_inputs = {str(directory / name) for name in ("finish.done.json", "flank_validation/done.json", "manifest.json")}
    if not expected_outputs <= {item["path"] for item in outputs} or not expected_inputs <= {item["path"] for item in inputs}:
        raise ValueError("Priority export provenance omits required inputs or outputs")
    validate_records(inputs + outputs)
    if json.loads((directory / "finish.done.json").read_text()).get("status") != "completed":
        raise ValueError("Pair analysis is not completed")
    if json.loads((directory / "flank_validation/done.json").read_text()).get("status") != "completed":
        raise ValueError("Flank validation is not completed")
    loci = read_tsv(directory / "priority_loci.tsv")
    fragments = read_tsv(directory / "priority_candidates.tsv")
    locus_ids = {row["locus_id"] for row in loci}
    if len(locus_ids) != len(loci):
        raise ValueError("Duplicate priority locus IDs")
    for locus in loci:
        if locus["genome"] not in ("1", "2") or locus["genome_id"] != manifest["genomes"][int(locus["genome"]) - 1]["id"]:
            raise ValueError("Priority locus genome identity differs")
    grouped = collections.defaultdict(list)
    seen = set()
    for row in fragments:
        key = (row["genome"], row["fragment_id"])
        if key in seen or row["locus_id"] not in locus_ids or row["evidence_level"] != SUPPORTED:
            raise ValueError("Invalid/duplicate supported candidate reference")
        seen.add(key)
        grouped[row["locus_id"]].append(row)
    paths = [manifest_path, priority_path, directory / "priority_candidates.tsv", directory / "priority_loci.tsv"]
    for genome in manifest["genomes"]:
        paths.extend([directory / genome["id"] / "repeats.bed", directory / genome["id"] / "lengths.tsv", Path(genome["genes"])])
    signatures = [record(path) for path in paths]
    scripts = [record(__file__), record(coverage.__file__)]
    rows, scope = [], {}
    for side, genome in enumerate(manifest["genomes"], 1):
        folder = directory / genome["id"]
        lengths = coverage.read_lengths(folder / "lengths.tsv")
        scope[genome["id"]] = gene_scope(genome["genes"])
        relevant = [row for row in loci if row["genome"] == str(side)]
        with tempfile.TemporaryDirectory(prefix="tevox-gap-composition-", dir=temporary_directory) as temporary:
            indices = annotation_indices(folder / "repeats.bed", lengths, temporary) if relevant else {}
            for locus in relevant:
                lo, hi = int(locus["source_gap_start0"]), int(locus["source_gap_end0"])
                chrom = locus["source_chrom"]
                if locus["evidence_level"] != SUPPORTED or chrom not in lengths or not 0 <= lo < hi <= lengths[chrom]:
                    raise ValueError("Unsupported locus or invalid gap bounds")
                source = grouped[locus["locus_id"]]
                if len(source) != int(locus["fragment_count"]) or sorted(row["fragment_id"] for row in source) != sorted(json.loads(locus["fragment_ids_json"])):
                    raise ValueError("Locus/fragment references disagree")
                candidate_index = UnionIndex()
                for match in sorted(source, key=lambda row: (int(row["start1"]), int(row["end1"]), row["fragment_id"])):
                    start, end = int(match["start1"]) - 1, int(match["end1"])
                    if match["genome"] != str(side) or match["chrom"] != chrom or not 0 <= start < end <= lengths[chrom] or start >= hi or end <= lo:
                        raise ValueError("Candidate has inconsistent chromosome, side, or bounds")
                    candidate_index.add(start, end)
                by_class = {name: index.covered(lo, hi) for name, index in indices.get(chrom, {}).items() if name is not None}
                by_class = {name: value for name, value in by_class.items() if value}
                all_bases = indices.get(chrom, {}).get(None, UnionIndex()).covered(lo, hi)
                candidate_bases = candidate_index.covered(lo, hi)
                if candidate_bases > all_bases:
                    raise ValueError("Supported fragments exceed retained annotation union")
                row = {field: locus[field] for field in FIELDS if field in locus}
                row.update(gap_length_bp=hi-lo, supported_fragment_count=len(source),
                    supported_repeat_classes_json=json.dumps(sorted({item["canonical_class"] for item in source})),
                    retained_annotation_union_bp=all_bases, retained_annotation_gap_fraction=all_bases/(hi-lo),
                    supported_candidate_union_bp=candidate_bases, supported_candidate_gap_fraction=candidate_bases/(hi-lo),
                    retained_class_union_bp_json=json.dumps(by_class, sort_keys=True),
                    retained_class_gap_fraction_json=json.dumps({name: count/(hi-lo) for name, count in by_class.items()}, sort_keys=True))
                rows.append(row)
            del indices
    validate_records(signatures + scripts + inputs + outputs)
    summary = dict(status="completed", schema_version=1, pair_id=manifest["pair_id"], completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        signature=dict(inputs=signatures, scripts=scripts), gene_feature_scope=scope, exact_coordinate_audit=coordinate_audit(loci),
        counts=dict(supported_alignment_gap_loci=len(rows), supported_candidate_fragments=len(fragments),
            gaps_with_retained_TE_union_below_10_percent=sum(row["retained_annotation_gap_fraction"] < .1 for row in rows),
            gaps_with_retained_TE_union_below_50_percent=sum(row["retained_annotation_gap_fraction"] < .5 for row in rows),
            gaps_with_retained_TE_union_below_80_percent=sum(row["retained_annotation_gap_fraction"] < .8 for row in rows)),
        interpretation="The initial 80% rule is fraction of each TE fragment inside a gap, not fraction of gap occupied by TE. "
            "This supplement clips ALL retained normalized TE intervals and separately supported candidate fragments to each gap. "
            "Class unions can overlap and cannot be summed. Excluded source classes remain absent. "
            "Supported gaps may represent complex structural differences containing TE fragments; they are not established TE-only insertion/deletion events. "
            "Flank uniqueness is conditional on the reported mappings and existing thresholds.")
    return rows, summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", required=True, help="Completed pair directory with verified priority exports")
    parser.add_argument("--temporary-directory")
    args = parser.parse_args()
    directory = Path(args.results).resolve()
    output = directory / "gap_composition.tsv"
    summary_path = directory / "gap_composition_summary.json"
    try:
        for path in (output, summary_path):
            if path.is_symlink() or (path.exists() and not path.is_file()):
                raise ValueError("Output is not a regular file: " + str(path))
        rows, summary = analyze(directory, args.temporary_directory)
        with tempfile.TemporaryDirectory(prefix=".gap-composition-", dir=str(directory)) as staging:
            table = Path(staging) / output.name
            with table.open("w") as handle:
                writer = csv.DictWriter(handle, fieldnames=FIELDS, delimiter="\t", lineterminator="\n")
                writer.writeheader()
                writer.writerows(rows)
            os.replace(str(table), str(output))
            summary["outputs"] = [record(output)]
            marker = Path(staging) / summary_path.name
            marker.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
            os.replace(str(marker), str(summary_path))
        print(json.dumps(summary["counts"], sort_keys=True))
    except (OSError, ValueError, KeyError, sqlite3.Error) as exc:
        parser.exit(1, "audit_gap_composition: %s\n" % exc)


if __name__ == "__main__":
    main()
