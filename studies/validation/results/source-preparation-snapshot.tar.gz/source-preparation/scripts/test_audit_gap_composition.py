#!/usr/bin/env python3
import csv
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest

import audit_gap_composition as audit


class GapCompositionAudit(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="tevox-gap-composition-unit-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.manifest = {"pair_id": "synthetic_fixture", "genomes": []}
        for name in ("a", "b"):
            folder = self.root / name
            folder.mkdir()
            (folder / "lengths.tsv").write_text("#sequence_id\tlength\nchr1\t100\nchr2\t50\n")
            (folder / "repeats.bed").write_text("chr1\t30\t40\tF3\t0\t+\tDNA\nchr1\t0\t10\tF1\t0\t+\tDNA\nchr1\t5\t15\tF2\t0\t-\tLTR\nchr1\t15\t20\tF4\t0\t+\tUnknown\nchr2\t0\t50\tF5\t0\t+\tDNA\n")
            genes = folder / "genes.gff3"
            genes.write_text("##gff-version 3\nchr1\tfixture\tgene\t1\t20\t.\t+\t.\tID=g1\nchr1\tfixture\tncRNA_gene\t30\t40\t.\t+\t.\tID=n1\nchr1\tfixture\tpseudogene\t50\t60\t.\t+\t.\tID=p1\nchr1\tfixture\texon\t1\t5\t.\t+\t.\tID=e1\n")
            self.manifest["genomes"].append({"id": name, "genes": str(genes)})
        (self.root / "manifest.json").write_text(json.dumps(self.manifest))
        (self.root / "finish.done.json").write_text(json.dumps({"status": "completed"}))
        (self.root / "flank_validation").mkdir()
        (self.root / "flank_validation/done.json").write_text(json.dumps({"status": "completed"}))
        self.locus = {"pair_id": "synthetic_fixture", "genome": "1", "genome_id": "a", "material": "Fixture A", "assembly": "fixture",
            "locus_id": "L1", "alignment_id": "paf:1", "source_chrom": "chr1", "source_gap_start0": "0", "source_gap_end0": "35",
            "opposite_chrom": "chr1", "opposite_empty_site0": "80", "alignment_strand": "+", "fragment_count": "2",
            "fragment_ids_json": '["F1", "F2"]', "evidence_level": audit.SUPPORTED}
        self.candidates = [{"genome": "1", "genome_id": "a", "locus_id": "L1", "fragment_id": name,
            "chrom": "chr1", "start1": str(start), "end1": str(end), "canonical_class": category, "evidence_level": audit.SUPPORTED}
            for name, start, end, category in [("F1", 1, 10, "DNA"), ("F2", 6, 15, "LTR")]]
        self.publish_fixture()

    def publish_fixture(self):
        for name, rows in [("priority_loci.tsv", [self.locus]), ("priority_candidates.tsv", self.candidates)]:
            with (self.root / name).open("w") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t")
                writer.writeheader()
                writer.writerows(rows)
        (self.root / "priority_summary.json").write_text(json.dumps({"pair_id": "synthetic_fixture", "outputs": [audit.record(self.root / name)
            for name in ("priority_loci.tsv", "priority_candidates.tsv")], "signature": {"inputs": [audit.record(self.root / name)
            for name in ("manifest.json", "finish.done.json", "flank_validation/done.json")]}}))

    def test_union_overlap_nested_adjacent_and_boundaries(self):
        index = audit.UnionIndex()
        for interval in [(0, 10), (1, 2), (5, 15), (15, 20), (25, 30)]:
            index.add(*interval)
        for start, end, expected in [(0, 30, 25), (8, 27, 14), (20, 25, 0), (10, 15, 5), (30, 40, 0), (7, 7, 0)]:
            self.assertEqual(index.covered(start, end), expected)

    def test_random_union_queries_against_per_base_oracle(self):
        rng = random.Random(444)
        rows = sorted((start, rng.randint(start + 1, 100)) for start in [rng.randrange(100) for _ in range(80)])
        index, oracle = audit.UnionIndex(), set()
        for start, end in rows:
            index.add(start, end)
            oracle.update(range(start, end))
        for _ in range(1000):
            start, end = sorted([rng.randrange(120), rng.randrange(120)])
            self.assertEqual(index.covered(start, end), len(oracle.intersection(range(start, end))))

    def test_gap_composition_separates_fragment_denominator_and_gene_scope(self):
        rows, summary = audit.analyze(self.root)
        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(row["gap_length_bp"], 35)
        self.assertEqual(row["retained_annotation_union_bp"], 25)
        self.assertEqual(row["supported_candidate_union_bp"], 15)
        self.assertAlmostEqual(row["supported_candidate_gap_fraction"], 15 / 35)
        self.assertEqual(json.loads(row["retained_class_union_bp_json"]), {"DNA": 15, "LTR": 10, "Unknown": 5})
        self.assertEqual(summary["gene_feature_scope"]["a"]["included_exact_gene_rows"], 1)
        self.assertEqual(summary["gene_feature_scope"]["a"]["omitted_other_gene_like_features"], {"ncRNA_gene": 1, "pseudogene": 1})
        self.assertIn("not fraction of gap", summary["interpretation"])

    def test_wrong_chromosome_and_out_of_bounds_gaps_rejected(self):
        self.candidates[0]["chrom"] = "chr2"
        self.publish_fixture()
        with self.assertRaisesRegex(ValueError, "inconsistent chromosome"):
            audit.analyze(self.root)
        self.candidates[0]["chrom"] = "chr1"
        self.locus["source_gap_end0"] = "101"
        self.publish_fixture()
        with self.assertRaisesRegex(ValueError, "gap bounds"):
            audit.analyze(self.root)

    def test_priority_provenance_changes_rejected(self):
        path = self.root / "priority_candidates.tsv"
        path.write_text(path.read_text() + "\n")
        with self.assertRaisesRegex(ValueError, "fingerprint/hash differs"):
            audit.analyze(self.root)

    def test_exact_coordinate_duplicates_ignore_alignment_id_without_merging(self):
        first = dict(self.locus, source_gap_end0="10", opposite_chrom="other", opposite_empty_site0="20")
        duplicate = dict(first, locus_id="L2", alignment_id="paf:2")
        second = dict(first, genome="2", locus_id="L3", source_chrom="other", source_gap_start0="20", source_gap_end0="25",
                      opposite_chrom="chr1", opposite_empty_site0="10")
        result = audit.coordinate_audit([first, duplicate, second])
        self.assertEqual(result["source_interval_exact_duplicate_groups"], 1)
        self.assertEqual(result["source_interval_duplicates_with_different_alignment_ids"], 1)
        self.assertEqual(result["opposite_empty_point_exact_duplicate_groups"], 1)
        self.assertEqual(result["normalized_paired_interval_exact_duplicate_groups"], 1)
        self.assertEqual(result["cross_side_mutual_exact_gap_boundary_matches"], [["L1", "L3"], ["L2", "L3"]])

    def test_cli_publishes_supplement_without_modifying_source_results(self):
        before = audit.record(self.root / "priority_candidates.tsv")
        command = [sys.executable, audit.__file__, "--results", str(self.root)]
        result = subprocess.run(command, text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(before, audit.record(self.root / "priority_candidates.tsv"))
        summary = json.loads((self.root / "gap_composition_summary.json").read_text())
        audit.validate_records(summary["outputs"])
        self.assertEqual(summary["counts"]["supported_alignment_gap_loci"], 1)
        previous = (self.root / "gap_composition.tsv").read_bytes()
        (self.root / "priority_candidates.tsv").write_text("changed fixture")
        self.assertNotEqual(subprocess.run(command, capture_output=True).returncode, 0)
        self.assertEqual(previous, (self.root / "gap_composition.tsv").read_bytes())


if __name__ == "__main__":
    unittest.main(verbosity=2)
