#!/usr/bin/env python3
"""Independently remap four 1-kb flanks of existing anchored TE annotation candidates.

Supports candidate evidence only: not confirmed polymorphisms, event counts,
evolutionary insertion direction, expression changes, or causation. Does not
modify original TEvoX evidence. Two whole-genome target mappings run sequentially.
"""
import argparse
import collections
import csv
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

from fasta_qc import fasta_batches
from normalize_annotations import open_text, read_lengths, validate_interval
from run_pair import atomic_json, fingerprint, load_manifest, now, read_json

THRESHOLDS = dict(flank_bp=1000, min_mapq=30, min_query_coverage=0.95,
                  min_identity=0.95, alternate_query_coverage=0.8, coordinate_tolerance_bp=50,
                  max_secondary=20, secondary_score_ratio=0.5)
SUPPORTED = 'reciprocal_unique_flank_supported_candidate'


def stable_id(prefix, values):
    return prefix + hashlib.sha256(json.dumps(values, separators=(',', ':')).encode()).hexdigest()[:20]


def load_loci(results):
    eligible, counts = {}, collections.Counter()
    for side in (1, 2):
        with open(results / 'evidence' / ('genome%d.candidate_evidence.tsv' % side)) as handle:
            for row in csv.DictReader(handle, delimiter='\t'):
                if row['category'] != 'anchored_gap_candidate':
                    continue
                counts['anchored_fragment_rows'] += 1
                if row['canonical_class'] == 'Unknown':
                    counts['excluded_unknown_class_fragments'] += 1
                    continue
                eligible[(str(side), row['fragment_id'])] = row
    loci, matched = {}, set()
    with open(results / 'evidence/candidate_flank_loci.tsv') as handle:
        for row in csv.DictReader(handle, delimiter='\t'):
            if row['category'] != 'anchored_gap_candidate':
                continue
            key = (row['genome'], row['fragment_id'])
            if key not in eligible:
                continue
            evidence = eligible[key]
            for flank_key, evidence_key in [('alignment_id', 'selected_alignment_id'), ('source_chrom', 'chrom'),
                    ('source_gap_start0', 'gap_start0'), ('source_gap_end0', 'gap_end0'),
                    ('opposite_chrom', 'opposite_chrom'), ('opposite_empty_site0', 'opposite_empty_site0'),
                    ('alignment_strand', 'alignment_strand')]:
                if row[flank_key] != evidence[evidence_key]:
                    raise ValueError('Flank/evidence disagreement for ' + row['fragment_id'])
            if key in matched:
                raise ValueError('Duplicate candidate flank row: ' + str(key))
            matched.add(key)
            values = [row[field] for field in ('genome', 'alignment_id', 'source_chrom', 'source_gap_start0',
                      'source_gap_end0', 'opposite_chrom', 'opposite_empty_site0', 'alignment_strand')]
            identifier = stable_id('L', values)
            if identifier not in loci:
                loci[identifier] = dict(locus_id=identifier, genome=int(row['genome']), alignment_id=row['alignment_id'],
                    source_chrom=row['source_chrom'], source_gap_start0=int(row['source_gap_start0']),
                    source_gap_end0=int(row['source_gap_end0']), opposite_chrom=row['opposite_chrom'],
                    opposite_empty_site0=int(row['opposite_empty_site0']), alignment_strand=row['alignment_strand'],
                    fragment_ids=[], repeat_classes=[])
            loci[identifier]['fragment_ids'].append(row['fragment_id'])
            loci[identifier]['repeat_classes'].append(evidence['canonical_class'])
    if eligible.keys() - matched:
        raise ValueError('Eligible evidence fragments missing flank coordinates')
    counts['eligible_known_class_fragments'] = len(eligible)
    counts['deduplicated_alignment_gap_loci'] = len(loci)
    return list(loci.values()), counts


def flank_specs(locus, lengths):
    side, size = locus['genome'] - 1, THRESHOLDS['flank_bp']
    start, end, site = locus['source_gap_start0'], locus['source_gap_end0'], locus['opposite_empty_site0']
    if locus['alignment_strand'] not in {'+', '-'} or start >= end:
        raise ValueError('Invalid gap orientation or interval')
    intervals = {'source_left': (side, locus['source_chrom'], start-size, start),
                 'source_right': (side, locus['source_chrom'], end, end+size),
                 'opposite_left': (1-side, locus['opposite_chrom'], site-size, site),
                 'opposite_right': (1-side, locus['opposite_chrom'], site, site+size)}
    for genome, chrom, left, right in intervals.values():
        validate_interval(chrom, left, right, '.', lengths[genome])
    pairs = [('source_left', 'opposite_left'), ('source_right', 'opposite_right')]
    if locus['alignment_strand'] == '-':
        pairs = [('source_left', 'opposite_right'), ('source_right', 'opposite_left')]
    specs = []
    for one, two in pairs:
        for role, other in [(one, two), (two, one)]:
            genome, chrom, left, right = intervals[role]
            target_genome, target_chrom, target_start, target_end = intervals[other]
            specs.append(dict(role=role, query_id=stable_id('Q', [genome, chrom, left, right]),
                genome=genome, chrom=chrom, start=left, end=right, target_genome=target_genome,
                target_chrom=target_chrom, target_start=target_start, target_end=target_end,
                strand=locus['alignment_strand']))
    return specs


def extract_flanks(fasta, requests, destination, lengths):
    """Streaming FASTA extraction: memory bounded by active 1-kb intervals."""
    if not requests:
        with gzip.open(destination, 'wb'):
            pass
        return {}
    by_chrom = collections.defaultdict(list)
    for request in requests.values():
        by_chrom[request['chrom']].append(request)
    for items in by_chrom.values():
        items.sort(key=lambda x: (x['start'], x['end'], x['query_id']))
    statuses, seen = {}, set()
    chrom, position, pending, active, index = None, 0, [], [], 0
    # Probe only two bytes; never read a complete compressed genome into memory.
    with open(fasta, 'rb') as probe:
        compressed = probe.read(2) == b'\x1f\x8b'
    opener = gzip.open if compressed else open
    with opener(fasta, 'rt', encoding='utf-8', newline=None) as source, gzip.open(destination, 'wt', compresslevel=1) as output:
        for header, content, _ in fasta_batches(source):
            if header:
                if chrom is not None and (position != lengths.get(chrom) or active or index != len(pending)):
                    raise ValueError('FASTA sequence/lengths mismatch during extraction: ' + chrom)
                chrom = content.split()[0]
                if chrom in seen or chrom not in lengths:
                    raise ValueError('Duplicate or unexpected FASTA sequence: ' + chrom)
                seen.add(chrom)
                position, index, active = 0, 0, []
                pending = by_chrom.get(chrom, [])
                continue
            sequence = content.replace('\n', '')
            if not sequence:
                continue
            if chrom is None:
                raise ValueError('Sequence before FASTA header')
            stop = position + len(sequence)
            while index < len(pending) and pending[index]['start'] < stop:
                active.append((pending[index], []))
                index += 1
            remaining = []
            for request, pieces in active:
                left, right = max(position, request['start']), min(stop, request['end'])
                if left < right:
                    pieces.append(sequence[left-position:right-position])
                if request['end'] <= stop:
                    bases = ''.join(pieces).upper()
                    if len(bases) != THRESHOLDS['flank_bp']:
                        raise ValueError('Incomplete extracted flank')
                    status = 'ready' if set(bases) <= set('ACGT') else ('N_containing_flank' if 'N' in bases else 'ambiguous_IUPAC_flank')
                    statuses[request['query_id']] = status
                    if status == 'ready':
                        output.write('>' + request['query_id'] + '\n' + bases + '\n')
                else:
                    remaining.append((request, pieces))
            active, position = remaining, stop
        if chrom is not None and (position != lengths.get(chrom) or active or index != len(pending)):
            raise ValueError('FASTA sequence/lengths mismatch during extraction: ' + chrom)
    if seen != set(lengths) or set(statuses) != set(requests):
        raise ValueError('FASTA IDs or extracted flank IDs missing')
    return statuses


def parse_paf(path, requests, target_lengths):
    hits, reported = collections.defaultdict(list), collections.Counter()
    with gzip.open(path, 'rt') as handle:
        for line in handle:
            f = line.rstrip('\n').split('\t')
            if len(f) < 12 or f[0] not in requests:
                raise ValueError('Malformed or unexpected PAF query')
            qlen, qs, qe, tlen, ts, te, matches, block, mapq = [int(f[i]) for i in (1, 2, 3, 6, 7, 8, 9, 10, 11)]
            if qlen != THRESHOLDS['flank_bp'] or not 0 <= qs < qe <= qlen or not 0 < block or not 0 <= matches <= block:
                raise ValueError('Invalid PAF query coordinates or identity')
            validate_interval(f[5], ts, te, f[4], target_lengths)
            if tlen != target_lengths[f[5]] or f[4] not in {'+', '-'} or not 0 <= mapq <= 255:
                raise ValueError('Invalid PAF target/strand/MAPQ')
            tags = {item[:2]: item[5:] for item in f[12:] if len(item) >= 5}
            if 'cg' not in tags or tags.get('tp') not in {'P', 'S', 'I', 'i'}:
                raise ValueError('PAF must include minimap2 CIGAR and primary/secondary tags')
            hit = dict(chrom=f[5], start=ts, end=te, strand=f[4], mapq=mapq,
                       coverage=(qe-qs)/qlen, identity=matches/block, primary=tags['tp']=='P',
                       projected_start=ts-(qs if f[4]=='+' else qlen-qe),
                       projected_end=te+(qlen-qe if f[4]=='+' else qs))
            reported[f[0]] += 1
            if len(hits[f[0]]) < 64:
                hits[f[0]].append(hit)
    return hits, reported


def assess_flank(spec, hits, reported, extraction_status):
    if extraction_status != 'ready':
        return dict(status='not_validated', reason=extraction_status)
    t = THRESHOLDS
    primary = [h for h in hits if h['primary'] and t['min_mapq'] <= h['mapq'] < 255
               and h['coverage'] >= t['min_query_coverage'] and h['identity'] >= t['min_identity']]
    if not primary:
        qualifying = [h for h in hits if h['coverage'] >= t['alternate_query_coverage'] and h['identity'] >= t['min_identity']]
        if qualifying and any(h['chrom'] != qualifying[0]['chrom'] or h['strand'] != qualifying[0]['strand'] or abs(h['projected_start']-qualifying[0]['projected_start']) > t['coordinate_tolerance_bp'] or abs(h['projected_end']-qualifying[0]['projected_end']) > t['coordinate_tolerance_bp'] for h in qualifying[1:]):
            return dict(status='ambiguous', reason='distinct_high_identity_loci_without_unique_primary')
        return dict(status='failed', reason='no_primary_hit_passing_MAPQ_coverage_identity')
    expected = [h for h in primary if h['chrom']==spec['target_chrom'] and h['strand']==spec['strand']
                and abs(h['start']-spec['target_start']) <= t['coordinate_tolerance_bp']
                and abs(h['end']-spec['target_end']) <= t['coordinate_tolerance_bp']]
    if not expected:
        return dict(status='failed', reason='unexpected_target_coordinates_or_orientation')
    best = max(expected, key=lambda h: (h['mapq'], h['coverage'], h['identity']))
    alternatives = [h for h in hits if h['coverage'] >= t['alternate_query_coverage'] and h['identity'] >= t['min_identity']
        and (h['chrom'] != best['chrom'] or h['strand'] != best['strand']
             or abs(h['projected_start']-best['projected_start']) > t['coordinate_tolerance_bp']
             or abs(h['projected_end']-best['projected_end']) > t['coordinate_tolerance_bp'])]
    reason = 'distinct_high_identity_alternate_locus' if alternatives else ('secondary_report_limit_reached' if reported >= t['max_secondary']+1 else '')
    return dict(status='ambiguous' if reason else 'supported', reason=reason or 'unique_expected_primary_among_reported_hits',
                primary_hit=best, alternate_locus_hits=len(alternatives), reported_hits=reported)


def mapping_command(binary, target, query, threads):
    return [str(binary), '-x', 'sr', '-c', '--secondary=yes', '--frag=no', '-N', '20', '-p', '0.5',
            '-t', str(threads), '-I6G', str(target), str(query)]


def map_flanks(command, output, log):
    part = Path(str(output) + '.part')
    with open(log, 'wb') as stderr, gzip.open(part, 'wb', compresslevel=1) as compressed:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=stderr)
        try:
            shutil.copyfileobj(process.stdout, compressed, length=1024*1024)
            process.stdout.close()
            if process.wait() != 0:
                raise ValueError('minimap2 failed; inspect ' + str(log))
        except BaseException:
            process.stdout.close()
            if process.poll() is None:
                process.terminate()
            process.wait()
            raise
    part.replace(output)


def validate(args):
    manifest = load_manifest(args.manifest)
    results = Path(args.results).resolve(strict=True)
    if read_json(results/'manifest.json') != manifest:
        raise ValueError('Results manifest differs from requested pair')
    finish = read_json(results/'finish.done.json')
    if finish.get('status') != 'completed' or any(fingerprint(x['path']) != x for x in finish['outputs']):
        raise ValueError('Pair finish marker is incomplete or outputs changed')
    prepare = read_json(results/'prepare.done.json')
    if prepare.get('status') != 'completed' or any(fingerprint(x['path']) != x for x in prepare['outputs']):
        raise ValueError('Pair prepare outputs changed; FASTA lengths must match original preparation')
    if any(fingerprint(x['path']) != x for x in finish['signature']['inputs']):
        raise ValueError('Original analysis inputs changed after pair finish')
    binary = Path(args.minimap2).resolve(strict=True)
    inputs = [Path(args.manifest), results/'manifest.json', results/'finish.done.json', results/'prepare.done.json',
              results/'evidence/candidate_flank_loci.tsv']
    inputs += [results/'evidence'/('genome%d.candidate_evidence.tsv'%n) for n in (1,2)]
    inputs += [Path(g['fasta']) for g in manifest['genomes']]
    inputs += [results/g['id']/'lengths.tsv' for g in manifest['genomes']]
    scripts = [Path(__file__), Path(__file__).with_name('fasta_qc.py'), Path(__file__).with_name('normalize_annotations.py'), Path(__file__).with_name('run_pair.py')]
    signature = dict(inputs=[fingerprint(p, True) for p in inputs], scripts=[fingerprint(p, True) for p in scripts],
                     tool=fingerprint(binary, True), thresholds=THRESHOLDS, threads=args.threads)
    out = results/'flank_validation'
    if out.is_symlink():
        raise ValueError('Validation output directory must not be a symlink')
    done = out/'done.json'
    if done.exists():
        previous = read_json(done)
        if previous.get('signature') == signature and all(fingerprint(x['path'], True)==x for x in previous['outputs']):
            return read_json(out/'summary.json')
        raise ValueError('Existing validation results have stale input/output fingerprints or hashes')
    if out.exists() and any(out.iterdir()):
        raise ValueError('Existing incomplete flank_validation directory; preserve/archive it before a fresh run')
    out.mkdir(exist_ok=True)
    atomic_json(out/'signature.json', signature)
    lengths = [read_lengths(results/g['id']/'lengths.tsv') for g in manifest['genomes']]
    loci, counts = load_loci(results)
    requests = [{}, {}]
    for locus in loci:
        try:
            locus['flanks'] = flank_specs(locus, lengths)
            for spec in locus['flanks']:
                requests[spec['genome']][spec['query_id']] = spec
        except ValueError as exc:
            locus.update(flanks=[], status='not_validated', reason=str(exc))
    extraction, hits, reports, commands = [], [], [], []
    for side in (0,1):
        queries = out/('genome%d.flanks.fa.gz'%(side+1))
        extraction.append(extract_flanks(manifest['genomes'][side]['fasta'], requests[side], queries, lengths[side]))
    # Sequential target indexes keep memory bounded to one complete genome index.
    for side in (0,1):
        paf, log = out/('genome%d.to_other.paf.gz'%(side+1)), out/('genome%d.minimap2.log'%(side+1))
        command = mapping_command(binary, manifest['genomes'][1-side]['fasta'], out/('genome%d.flanks.fa.gz'%(side+1)), args.threads)
        runnable = any(status=='ready' for status in extraction[side].values())
        commands.append(dict(command=command, started_at=now(), executed=runnable))
        atomic_json(out/'commands.json', commands)
        if runnable:
            map_flanks(command, paf, log)
        else:
            with gzip.open(paf,'wb'): pass
            log.write_text('No eligible ACGT-only flank queries; mapping not executed.\n')
        commands[-1]['completed_at'] = now()
        atomic_json(out/'commands.json', commands)
        one, two = parse_paf(paf, requests[side], lengths[1-side])
        hits.append(one); reports.append(two)
    with open(out/'loci.tsv','w') as locus_file, open(out/'flanks.tsv','w') as flank_file:
        lw, fw = csv.writer(locus_file,delimiter='\t',lineterminator='\n'), csv.writer(flank_file,delimiter='\t',lineterminator='\n')
        lw.writerow(['locus_id','genome','alignment_id','source_chrom','source_gap_start0','source_gap_end0','opposite_chrom','opposite_empty_site0','alignment_strand','fragment_ids_json','repeat_classes_json','status','reasons_json'])
        fw.writerow(['locus_id','role','query_id','genome','chrom','start0','end0','target_genome','target_chrom','expected_start0','expected_end0','strand','assessment_json'])
        for locus in loci:
            assessments=[]
            for spec in locus['flanks']:
                side, query = spec['genome'], spec['query_id']
                assessment = assess_flank(spec,hits[side].get(query,[]),reports[side][query],extraction[side][query])
                assessments.append(assessment)
                fw.writerow([locus['locus_id'],spec['role'],query,side+1,spec['chrom'],spec['start'],spec['end'],spec['target_genome']+1,spec['target_chrom'],spec['target_start'],spec['target_end'],spec['strand'],json.dumps(assessment,sort_keys=True)])
            statuses={a['status'] for a in assessments}
            status = ('not_validated' if not assessments or 'not_validated' in statuses else 'ambiguous' if 'ambiguous' in statuses else 'failed' if 'failed' in statuses else SUPPORTED)
            reasons = sorted({a['reason'] for a in assessments if a['status']!='supported'}) or ([locus['reason']] if not assessments else [])
            counts[status+'_loci']+=1
            counts[status+'_fragments']+=len(locus['fragment_ids'])
            lw.writerow([locus[k] for k in ['locus_id','genome','alignment_id','source_chrom','source_gap_start0','source_gap_end0','opposite_chrom','opposite_empty_site0','alignment_strand']]+[json.dumps(locus['fragment_ids']),json.dumps(sorted(set(locus['repeat_classes']))),status,json.dumps(reasons)])
    summary=dict(pair_id=manifest['pair_id'],completed_at=now(),counts=dict(counts),thresholds=THRESHOLDS,
        minimap2_version=subprocess.check_output([str(binary),'--version'],text=True).strip(),
        interpretation='Reciprocal unique-flank support among minimap2-reported mappings strengthens annotation-gap candidates only. Not confirmed TE polymorphisms, insertion/deletion directions, reconstructed TE events, or causal effects.',
        limitations=['Heuristic mapping with at most 20 secondary hits; uniqueness is conditional on reported alignments and thresholds.', 'At the secondary-hit reporting limit candidates are ambiguous.', 'Distinctness uses full-query projected target endpoints within 50 bp; raw expected primary endpoints must also be within 50 bp.', 'Existing assembly and repeat-annotation differences remain potential confounders.'])
    atomic_json(out/'summary.json',summary)
    # Full input hashes plus stat fingerprints on reuse; recheck stats after mapping.
    for item in signature['inputs']+signature['scripts']+[signature['tool']]:
        if fingerprint(item['path']) != {k:v for k,v in item.items() if k!='sha256'}:
            raise ValueError('Input/script/tool changed during validation; no success marker saved')
    outputs=[fingerprint(p,True) for p in sorted(out.iterdir()) if p.is_file() and p.name!='done.json']
    atomic_json(done,dict(status='completed',signature=signature,outputs=outputs))
    return summary


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',required=True); p.add_argument('--results',required=True)
    p.add_argument('--minimap2',required=True); p.add_argument('--threads',type=int,default=4)
    args=p.parse_args()
    if not 1<=args.threads<=64: p.error('--threads must be 1..64')
    try: result=validate(args)
    except (OSError,ValueError,KeyError,subprocess.CalledProcessError) as exc: p.exit(2,'Error: %s\n'%exc)
    print(json.dumps(result,sort_keys=True))


if __name__=='__main__': main()
