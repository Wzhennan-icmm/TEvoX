#!/usr/bin/env python3
"""Extract HG002 original repeat fragments and update the fresh runner manifest.

Run after prepare_human_pair.py. This orchestration does not reinterpret TE
coordinates; the independently tested extraction helper preserves each source
RepeatMasker fragment, including mixed strands within browser joined records.
"""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def update_manifest(manifest, provenance, provenance_path):
    records = [genome for genome in manifest['genomes'] if genome['id'] == 'hg002_mat']
    if len(records) != 1:
        raise ValueError('Expected exactly one HG002 maternal genome')
    genome = records[0]
    if genome['repeat_format'] != 'ucsc-bigrmsk-bed':
        raise ValueError('Expected freshly prepared HG002 bigRmsk input; do not overwrite an existing extraction')
    if provenance.get('status') != 'passed' or not provenance.get('independent_output_reread_passed') or not provenance.get('independent_source_map_reread_passed'):
        raise ValueError('Fragment extraction has not passed independent validation')
    if Path(provenance['input']).resolve() != Path(genome['repeats']).resolve():
        raise ValueError('Extraction source differs from the runner HG002 input')
    if provenance['canonical_source_fragment_sha256'] != provenance['canonical_output_fragment_sha256']:
        raise ValueError('Original and extracted fragment checksums disagree')
    counts = provenance['counts']
    if counts['output_fragment_records'] <= 0 or counts['query_length_verified_fragments'] != counts['output_fragment_records']:
        raise ValueError('Not every output fragment has a verified source query length')
    genome['repeat_source_original'] = genome['repeats']
    genome['repeats'] = provenance['output']
    genome['repeat_format'] = 'repeatmasker-out'
    genome['normalize_args'] = []
    genome['repeat_fragment_extraction_provenance'] = str(provenance_path)
    genome['repeat_fragment_sources'] = provenance['source_map']
    manifest['pair_id'] = 'human_chm13_hg002_mat_extracted'
    manifest['upstream_annotation_qc'] = [{
        'assembly': genome.get('assembly', 'GCA_018852615.3'),
        'source_browser_records': counts['source_browser_records'],
        'original_fragment_records': counts['output_fragment_records'],
        'mixed_orientation_browser_records': counts['mixed_strand_source_records'],
        'display_strand_mismatch_fragments': counts['display_strand_mismatch_fragments'],
        'inconsistent_aligned_summary_records': counts['aligned_summary_mismatch_source_records'],
        'fragments_outside_aligned_summary': counts['fragments_outside_aligned_summary'],
        'all_query_end_plus_remaining_match_fasta_length': True,
        'provenance': str(provenance_path),
        'action': 'Recover original fragment fields/strand/order; no coordinate changes, fragment merging, deduplication or filtering. Explicit browser-summary inconsistencies remain recorded.'}]
    manifest['source_coverage_note'] = ('All %d original fragments from %d selected browser records are preserved, with ordered full-field hashes, source-row/part mapping and exact FASTA query-length checks.' % (counts['output_fragment_records'], counts['source_browser_records']))
    manifest.setdefault('limitations', []).append('HG002 browser-joined records can contain mixed fragment orientations, including LINE inversions. Extract original RepeatMasker fragment strands/coordinates; browser display strand is not a per-fragment strand.')
    return manifest


def main():
    path = ROOT / 'metadata' / 'human_pair.json'
    manifest = json.loads(path.read_text())
    genomes = [genome for genome in manifest['genomes'] if genome['id'] == 'hg002_mat']
    if len(genomes) != 1 or genomes[0]['repeat_format'] != 'ucsc-bigrmsk-bed':
        raise ValueError('Run prepare_human_pair.py first; this conversion expects fresh selected bigRmsk input')
    genome = genomes[0]
    metadata = ROOT / 'metadata' / 'human'
    output = ROOT / 'data' / 'human' / 'hg002_mat' / 'selected_nuclear.repeatmasker.out.gz'
    mapping = metadata / 'hg002_mat_fragment_sources.tsv.gz'
    provenance_path = metadata / 'hg002_mat_fragment_extraction.json'
    for item in manifest['genomes']:
        audit_path = metadata / (item['id'] + '_repeat_duplicates.json')
        source_format = 'bigrmsk' if item['id'] == 'hg002_mat' else 'bed10'
        subprocess.run([sys.executable, str(ROOT / 'scripts' / 'audit_human_repeats.py'),
                        '--input', item['repeats'], '--format', source_format, '--output', str(audit_path)], check=True)
        item['repeat_duplicate_audit'] = str(audit_path)
    audit = metadata / 'hg002_mat_repeat_duplicates.json'
    cmd = [sys.executable, str(ROOT / 'scripts' / 'extract_bigrmsk_fragments.py'),
           '--input', genome['repeats'], '--selection-record', str(metadata / 'hg002_mat_selection.json'),
           '--output', str(output), '--source-map', str(mapping), '--provenance', str(provenance_path),
           '--expected-fragments', '5422582', '--expected-audit', str(audit),
           '--allow-inconsistent-aligned-summary']
    subprocess.run(cmd, check=True)
    provenance = json.loads(provenance_path.read_text())
    historical_manifest = metadata / 'pre_extraction_manifest.json'
    historical_manifest.write_text(json.dumps(manifest, indent=2) + '\n')
    updated = update_manifest(manifest, provenance, provenance_path)
    updated['derived_from_manifest'] = str(historical_manifest)
    temporary = path.with_suffix('.json.part')
    temporary.write_text(json.dumps(updated, indent=2) + '\n')
    temporary.replace(path)
    print('Updated human_pair.json to validated original HG002 RepeatMasker fragments')


if __name__ == '__main__':
    main()
