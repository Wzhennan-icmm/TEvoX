#!/usr/bin/env python3
"""Fetch the six source-pinned human inputs, genomes first; no coordinate changes."""
import concurrent.futures
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
manifest_path = ROOT / 'discovery/human_sources.json'
manifest = json.loads(manifest_path.read_text())
helper = ROOT / 'scripts/fetch_inputs.py'

def download(task):
    assembly, kind, entry = task
    destination = ROOT / 'data/human' / assembly['id'] / entry['filename']
    record = Path(str(destination) + '.provenance.json')
    args = [sys.executable, str(helper), '--url', entry['url'], '--output', str(destination),
            '--record', str(record), '--expected-bytes', str(entry['bytes'])]
    if entry.get('md5'):
        args += ['--md5', entry['md5'], '--checksum-source', entry['checksum_source']]
    subprocess.run(args, check=True)
    provenance = json.loads(record.read_text())
    return assembly['id'], kind, str(destination), str(record), provenance

tasks = [(a, k, e) for a in manifest['assemblies'] for k, e in a['files'].items()]
observed = []
for kind_group in [('fasta',), ('gene_gff3', 'repeats')]:
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for result in pool.map(download, [t for t in tasks if t[1] in kind_group]):
            observed.append(result)
            aid, kind, local, record, provenance = result
            for assembly in manifest['assemblies']:
                if assembly['id'] == aid:
                    assembly['files'][kind].update(local_path=local, provenance_record=record)
            manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    if kind_group == ('fasta',):
        (ROOT/'metadata/human/fastas-ready.txt').write_text('Both exact raw human FASTAs downloaded and provider-MD5 verified.\n')
        print('BOTH_HUMAN_FASTAS_READY', flush=True)
manifest['large_files_downloaded'] = True
manifest['status'] = 'raw-source-files-downloaded; selected-chromosome-transformation-pending'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
(ROOT/'data/human/download_manifest.json').write_text(json.dumps(observed, indent=2) + '\n')
print('ALL_HUMAN_RAW_INPUTS_READY', flush=True)
