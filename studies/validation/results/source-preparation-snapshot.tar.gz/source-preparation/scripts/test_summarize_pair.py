#!/usr/bin/env python3
import argparse
import collections
import csv
from pathlib import Path
import random
import tempfile
import unittest

import summarize_pair as summary
from paf_to_synteny import GAP_FIELDS


class IntervalIndexes(unittest.TestCase):
    def test_union_coverage_against_base_oracle(self):
        generator = random.Random(5271)
        records = [(generator.randrange(200), generator.randrange(1, 30)) for _ in range(80)]
        records = [(start, start + width) for start, width in records]
        index = summary.IntervalUnion({"chr1": records})
        covered = {base for start, end in records for base in range(start, end)}
        self.assertEqual(index.total("chr1"), len(covered))
        for start in range(-10, 250):
            for width in (0, 1, 10, 50):
                self.assertEqual(index.covered("chr1", start, start + width),
                                 len(covered.intersection(range(start, start + width))))
        self.assertEqual(index.covered("missing", 0, 100), 0)

    def test_gap_tree_against_linear_nested_interval_oracle(self):
        generator = random.Random(83)
        gaps = []
        for number in range(1000):
            start = generator.randrange(10000)
            end = start + generator.randrange(1, 5000)
            gaps.append(summary.Gap(str(number), "chr1", start, end, "other", 1000,
                                     "+", 1000, 1000, 60, 0.99, 20000))
        index = summary.GapIndex({"chr1": gaps[:]})
        for _ in range(200):
            start = generator.randrange(15000)
            end = start + generator.randrange(1, 500)
            observed = {gap.alignment_id for gap in index.overlaps("chr1", start, end)}
            expected = {gap.alignment_id for gap in gaps if gap.start < end and gap.end > start}
            self.assertEqual(observed, expected)
        self.assertEqual(list(index.overlaps("missing", 0, 100)), [])


class PairEvidence(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix="tevox-summary-")
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        (self.root / "lengths1.tsv").write_text("A\t20000\n")
        (self.root / "lengths2.tsv").write_text("B\t20000\n")
        (self.root / "n1.bed").write_text("A\t10020\t10030\n")
        (self.root / "n2.bed").write_text("")
        (self.root / "synteny.tsv").write_text(
            "A\t1\t2000\tB\t1\t2000\nA\t1001\t3000\tB\t1001\t3000\n"
            "A\t12001\t14000\tB\t12001\t14000\n")
        self.candidates = [[("I", 5000, 5200), ("unresolved", 8000, 8100),
                            ("N", 10000, 10100), ("edge", 18900, 19000), ("partial", 14950, 15200)],
                           [("D", 7000, 7200), ("opposite_N", 16000, 16200)]]
        metadata_fields = ["fragment_id", "chrom", "start0", "end0", "repeat_name", "canonical_class", "family"]
        for side in (0, 1):
            chromosome = "AB"[side]
            with (self.root / "candidates{}.tsv".format(side + 1)).open("w") as candidates:
                for key, start, end in self.candidates[side]:
                    candidates.write("TE_{}\t{}\t{}\t{}\t+\tLINE\tN/A\t{}\n".format(
                        key, chromosome, start + 1, end, key))
            with (self.root / "metadata{}.tsv".format(side + 1)).open("w") as metadata:
                writer = csv.writer(metadata, delimiter="\t", lineterminator="\n")
                writer.writerow(metadata_fields)
                for key, start, end in self.candidates[side] + [("not_candidate", 100, 150)]:
                    writer.writerow([key, chromosome, start, end, "L1", "LINE", "L1"])
        self.gaps = [self.gap("I", 5000, 5500, 5000, 5000),
                     self.gap("I", 15000, 15200, 15000, 15000),
                     self.gap("D", 7000, 7000, 7000, 7300, strand="-"),
                     self.gap("D", 10050, 10050, 16000, 16300)]
        self.write_gaps()
        self.args = argparse.Namespace(synteny=str(self.root / "synteny.tsv"), gaps=str(self.root / "gaps.tsv"),
            candidates1=str(self.root / "candidates1.tsv"), candidates2=str(self.root / "candidates2.tsv"),
            metadata1=str(self.root / "metadata1.tsv"), metadata2=str(self.root / "metadata2.tsv"),
            lengths1=str(self.root / "lengths1.tsv"), lengths2=str(self.root / "lengths2.tsv"),
            n_runs1=str(self.root / "n1.bed"), n_runs2=str(self.root / "n2.bed"), output_dir=str(self.root / "results"),
            min_anchor_bp=1000, min_alignment_bp=10000, min_mapq=30, min_identity=0.95,
            min_te_gap_fraction=0.8, edge_bp=1000)

    def gap(self, operation, qs, qe, ts, te, strand="+"):
        return dict(alignment_id="paf:{}:{}".format(operation, qs), query="A", query_start=qs,
            query_end=qe, target="B", target_start=ts, target_end=te, strand=strand, operation=operation,
            gap_bp=max(qe - qs, te - ts), left_anchor_bp=1500, right_anchor_bp=1200, mapq=60,
            aligned_identity=0.99, aligned_bases=15000, evidence="two_alignment_flanks")

    def write_gaps(self):
        with (self.root / "gaps.tsv").open("w") as handle:
            writer = csv.DictWriter(handle, fieldnames=GAP_FIELDS, delimiter="\t", lineterminator="\n")
            writer.writeheader()
            writer.writerows(self.gaps)

    def evidence(self, side):
        with (Path(self.args.output_dir) / "genome{}.candidate_evidence.tsv".format(side)).open() as handle:
            return {row["fragment_id"]: row for row in csv.DictReader(handle, delimiter="\t")}

    def test_categories_denominators_union_and_reverse_empty_site(self):
        result = summary.summarize(self.args)
        self.assertEqual(result["genome1"]["categories"], {"anchored_gap_candidate": 2,
            "unresolved_outside_alignment": 1, "low_quality_N_or_contig_edge": 2})
        self.assertEqual(result["genome1"]["normalized_annotation_fragments"], 6)
        self.assertEqual(result["genome1"]["candidate_fragments"], 5)
        self.assertEqual(result["genome1"]["coverage"]["overall"]["aligned_union_bp"], 5000)
        self.assertEqual(result["genome1"]["coverage"]["overall"]["non_N_bp"], 19990)
        first = self.evidence(1)
        self.assertEqual(first["partial"]["TE_fraction_in_gap"], "0.800000")
        self.assertEqual(first["N"]["candidate_N_overlap_bp"], "10")
        self.assertEqual(first["edge"]["near_contig_edge"], "1")
        second = self.evidence(2)
        self.assertEqual(second["D"]["category"], "anchored_gap_candidate")
        self.assertEqual(second["D"]["alignment_strand"], "-")
        self.assertEqual(second["D"]["opposite_empty_site0"], "7000")
        self.assertEqual(second["opposite_N"]["category"], "low_quality_N_or_contig_edge")
        self.assertIn("flank_or_empty_site_overlaps_N", second["opposite_N"]["quality_flags"])

    def test_weak_gap_evidence_and_N_cigar_do_not_upgrade_candidates(self):
        self.gaps[0]["mapq"] = 255
        self.gaps[1]["left_anchor_bp"] = 999
        self.gaps[2]["operation"] = "N"
        self.gaps[3]["aligned_bases"] = 9999
        self.write_gaps()
        result = summary.summarize(self.args)
        self.assertEqual(self.evidence(1)["I"]["category"], "unresolved_outside_alignment")
        self.assertEqual(self.evidence(1)["partial"]["category"], "unresolved_outside_alignment")
        self.assertEqual(self.evidence(2)["D"]["category"], "unresolved_outside_alignment")
        self.assertEqual(result["gap_event_qc"]["excluded_non_indel_gap"], 1)

    def test_inconsistent_candidate_alignment_fails(self):
        with (self.root / "synteny.tsv").open("a") as handle:
            handle.write("A\t5001\t5100\tB\t5001\t5100\n")
        with self.assertRaisesRegex(ValueError, "overlaps supplied synteny"):
            summary.summarize(self.args)

    def test_metadata_coordinate_mismatch_fails(self):
        path = Path(self.args.metadata1)
        path.write_text(path.read_text().replace("I\tA\t5000\t5200", "I\tA\t5001\t5200"))
        with self.assertRaisesRegex(ValueError, "differ from metadata"):
            summary.summarize(self.args)

    def test_output_input_collision_fails_before_writing(self):
        output = Path(self.args.output_dir)
        output.mkdir()
        path = output / "genome1.candidate_evidence.tsv"
        path.write_text(Path(self.args.candidates1).read_text())
        original = path.read_bytes()
        self.args.candidates1 = str(path)
        with self.assertRaisesRegex(ValueError, "overwrite"):
            summary.summarize(self.args)
        self.assertEqual(path.read_bytes(), original)


if __name__ == "__main__":
    unittest.main(verbosity=2)
