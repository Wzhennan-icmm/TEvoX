#!/usr/bin/env python3
"""Exact whole-primary-chromosome selection and Ensembl->GenBank seqid mapping.

Preserves all downloaded sources. Selects complete chromosomes 1-19 and X for
both strains; MT and unplaced contigs are explicitly recorded/excluded. Only the
GFF seqid and sequence-region name change; coordinates and attributes are intact.
"""
import collections
import concurrent.futures
import csv
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]; SCRIPTS=ROOT/'scripts'; DISC=ROOT/'discovery'; DATA=ROOT/'data/mouse'; EXPECTED={str(i) for i in range(1,20)}|{'X'}


def atomic_json(path,obj):
    tmp=Path(str(path)+'.tmp');tmp.write_text(json.dumps(obj,indent=2)+'\n');tmp.replace(path)


def sha256(path):
    d=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):d.update(b)
    return d.hexdigest()


def source_maps(label):
    report=DISC/(label+'_v3_report.txt');aliases=DISC/(label+'_v3_chromAlias.txt')
    records=[];mapping={};lengths={};chosen={}
    def bind(alias,target):
        if not alias or alias=='na':return
        if alias in mapping and mapping[alias]!=target:raise ValueError('Ambiguous alias '+alias)
        mapping[alias]=target
    for line in report.read_text().splitlines():
        if not line or line.startswith('#'):continue
        f=line.split('\t');rec={'name':f[0],'role':f[1],'molecule':f[2],'location':f[3],'accession':f[4],'unit':f[7],'length':int(f[8])};records.append(rec)
        if rec['accession'] in lengths:raise ValueError('Duplicate accession in report')
        lengths[rec['accession']]=rec['length'];bind(rec['accession'],rec['accession']);bind(rec['name'],rec['accession'])
        if rec['role']=='assembled-molecule' and rec['location']=='Chromosome':
            bind(rec['molecule'],rec['accession'])
            if rec['molecule'] in EXPECTED:chosen[rec['molecule']]=rec['accession']
        if rec['location']=='Mitochondrion':bind('MT',rec['accession']);bind('MIT',rec['accession'])
    if set(chosen)!=EXPECTED:raise ValueError('Expected all chromosomes 1-19 and X')
    for line in aliases.read_text().splitlines():
        if not line or line.startswith('#'):continue
        f=line.split('\t');target=f[0]
        if target not in lengths:raise ValueError('ChromAlias target absent from exact assembly report')
        for alias in f:bind(alias,target)
    return report,aliases,records,mapping,lengths,chosen


def gz_writer(path):
    return gzip.GzipFile(filename=str(path),mode='wb',compresslevel=1,mtime=0)


def selected_genes(assembly,folder,mapping,lengths,chosen):
    raw=Path(assembly['files']['gene_gff3']['local_path']);out=folder/'primary.genes.gff3.gz';excluded=folder/'excluded.genes.gff3.gz';tmp=Path(str(out)+'.part');xtmp=Path(str(excluded)+'.part')
    counts=collections.Counter();reasons=collections.Counter();types=collections.Counter();selected_types=collections.Counter();declared={};source_to_target={};mismatches=[];selected=set(chosen.values());build_seen=False
    with gzip.open(raw,'rt') as source,gz_writer(tmp) as dest,gz_writer(xtmp) as omit:
        dest.write(b'##tevox-study-scope complete nuclear chromosomes 1-19 and X; source seqids mapped to exact GenBank accessions\n')
        for line in source:
            counts['physical_lines']+=1
            if line.startswith('##FASTA'):raise ValueError('Embedded FASTA not expected in gene annotation')
            if line.startswith('##sequence-region'):
                _,name,st,en=line.split();target=mapping.get(name)
                if target is None:raise ValueError('Unknown gene sequence-region '+name)
                start,end=int(st),int(en)
                if start!=1:raise ValueError('Unexpected source region start')
                declared[name]=end;source_to_target[name]=target
                if lengths[target]!=end:
                    mismatches.append({'source_seqid':name,'target_seqid':target,'source_length':end,'target_length':lengths[target],'selected':target in selected})
                    if target in selected:raise ValueError('Selected source length differs from exact genome')
                if target in selected:dest.write(('##sequence-region '+target+' 1 '+str(end)+'\n').encode());counts['selected_sequence_regions']+=1
                else:omit.write(line.encode());counts['excluded_sequence_regions']+=1
            elif line.startswith('#!genome-build-accession'):
                if line.split()[-1]!=assembly['assembly_accession']:raise ValueError('Gene source assembly accession mismatch')
                build_seen=True;dest.write(line.encode());omit.write(line.encode())
            elif not line.strip() or line.startswith('#'):
                dest.write(line.encode());omit.write(line.encode())
            else:
                fields=line.rstrip('\r\n').split('\t')
                if len(fields)!=9:raise ValueError('Malformed GFF record')
                name=fields[0];target=mapping.get(name)
                if target is None or name not in declared:raise ValueError('Unknown/undeclared GFF feature sequence '+name)
                start,end=int(fields[3]),int(fields[4])
                if start<1 or end<start or end>declared[name]:raise ValueError('Invalid source GFF coordinate')
                counts['source_feature_rows']+=1;types[fields[2]]+=1
                if target in selected:
                    fields[0]=target;dest.write(('\t'.join(fields)+'\n').encode());counts['selected_feature_rows']+=1;selected_types[fields[2]]+=1
                    if target!=name:counts['renamed_feature_rows']+=1
                else:
                    omit.write(line.encode());counts['excluded_feature_rows']+=1;reasons[name]+=1
    if not build_seen:raise ValueError('Missing gene source assembly-accession declaration')
    tmp.replace(out);xtmp.replace(excluded)
    return {'selected_path':str(out),'excluded_path':str(excluded),'counts':dict(counts),'all_feature_types':dict(types),'selected_feature_types':dict(selected_types),'excluded_features_by_source_seqid':dict(reasons),'sequence_length_discrepancies':mismatches,'source_seqid_map':source_to_target}


def selected_repeats(assembly,folder,lengths,chosen):
    raw=Path(assembly['files']['repeatmasker']['local_path']);out=folder/'primary.repeatMasker.out.gz';excluded=folder/'excluded.repeatMasker.out.gz';tmp=Path(str(out)+'.part');xtmp=Path(str(excluded)+'.part');selected=set(chosen.values());counts=collections.Counter();byseq=collections.Counter()
    with gzip.open(raw,'rt') as source,gz_writer(tmp) as dest,gz_writer(xtmp) as omit:
        for line in source:
            f=line.split()
            if not f or f[0] in {'SW','score','There'}:
                dest.write(line.encode());omit.write(line.encode());continue
            if not f[0].isdigit() or len(f)<14:raise ValueError('Malformed RepeatMasker source row')
            name=f[4];start,end=int(f[5]),int(f[6])
            if name not in lengths or start<1 or end<start or end>lengths[name]:raise ValueError('Repeat source accession/coordinate does not match assembly report')
            counts['source_rows']+=1
            if name in selected:dest.write(line.encode());counts['selected_rows']+=1
            else:omit.write(line.encode());counts['excluded_rows']+=1;byseq[name]+=1
    tmp.replace(out);xtmp.replace(excluded)
    return {'selected_path':str(out),'excluded_path':str(excluded),'counts':dict(counts),'excluded_rows_by_seqid':dict(byseq)}


def prepare(assembly):
    label=assembly['id'];folder=DATA/label;report,aliases,records,mapping,lengths,chosen=source_maps(label)
    selector=folder/'primary_sequence_ids.txt';selector.write_text('\n'.join(chosen[str(i)] for i in range(1,20))+'\n'+chosen['X']+'\n')
    mapfile=folder/'ensembl_to_genbank.tsv';mapfile.write_text('ensembl_or_alias\tgenbank_accession\n'+''.join(k+'\t'+v+'\n' for k,v in sorted(mapping.items())))
    fasta=folder/'primary.fna.gz';full_lengths=folder/'source.fasta.lengths.tsv';selected_lengths=folder/'primary.lengths.tsv';fq=folder/'primary.fasta_selection.json'
    args=[sys.executable,str(SCRIPTS/'fasta_select_fast.py'),'--input',assembly['files']['fasta']['local_path'],'--lengths',str(full_lengths),'--n-runs',str(folder/'source.N_runs.bed'),'--summary',str(fq),'--select',str(selector),'--selected-fasta',str(fasta)]
    print('START_FASTA_SELECTION',label,flush=True)
    with (folder/'fasta_selection.log').open('w') as log:
        subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
    actual={}
    with full_lengths.open() as source:
        for l in source:
            if not l.startswith('#'):
                f=l.split('\t');actual[f[0]]=int(f[1])
    if actual!=lengths:raise ValueError('Full FASTA IDs/lengths differ from exact assembly report')
    selected_lengths.write_text(''.join(chosen[k]+'\t'+str(lengths[chosen[k]])+'\n' for k in [str(i) for i in range(1,20)]+['X']))
    genes=selected_genes(assembly,folder,mapping,lengths,chosen);repeats=selected_repeats(assembly,folder,lengths,chosen)
    with (folder/'genes_preflight.log').open('w') as log:
        subprocess.run([sys.executable,str(SCRIPTS/'preflight_genes.py'),'--input',genes['selected_path'],'--lengths',str(selected_lengths),'--summary',str(folder/'primary.genes.qc.json')],stdout=log,stderr=subprocess.STDOUT,check=True)
    result={'id':label,'assembly_accession':assembly['assembly_accession'],'scope':'complete nuclear chromosomes 1-19 and X','selection_reason':'Root-authorized matched primary chromosome scope; mitochondrial and unplaced scaffolds excluded explicitly. C57 mitochondrial Ensembl/NCBI length mismatch is outside scope.','selected_molecules':[str(i) for i in range(1,20)]+['X'],'selected_accessions':chosen,'selected_sequence_count':len(chosen),'excluded_assembly_sequences':[r for r in records if r['accession'] not in set(chosen.values())],'source_artifacts':assembly['files'],'mapping_evidence':{'assembly_report':str(report),'assembly_report_sha256':sha256(report),'chrom_alias':str(aliases),'chrom_alias_sha256':sha256(aliases),'mapping_tsv':str(mapfile)},'fasta_qc':json.loads(fq.read_text()),'genes':genes,'repeats':repeats,'outputs':{}}
    for key,p in [('fasta',str(fasta)),('genes',genes['selected_path']),('repeats',repeats['selected_path'])]:result['outputs'][key]={'path':p,'bytes':Path(p).stat().st_size,'sha256':sha256(p)}
    atomic_json(folder/'primary_selection.provenance.json',result)
    print('PRIMARY_TUPLE_READY',label,json.dumps({'sequences':len(chosen),'genes':genes['selected_feature_types'].get('gene',0),'repeat_rows':repeats['counts']['selected_rows']}),flush=True)
    return result


def main():
    manifest=json.loads((DISC/'mouse_sources.json').read_text())
    if manifest['status']!='downloaded_source_checksums_verified':raise ValueError('Downloads not yet verified')
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(prepare,manifest['assemblies']))
    pair={'pair_id':'mouse_c57_cast_v3_primary','species':'Mus musculus','preset':'asm10','threads':4,'source_manifest':str(DISC/'mouse_sources.json'),'scope':'Whole primary nuclear chromosomes 1-19 and X of both strains; MT and unplaced scaffolds explicitly excluded, no chromosome sampling','genomes':[],'limitations':manifest['publication_limitations']+[manifest['repeat_comparability']['difference'],'Two strain assemblies do not establish population frequencies; TE candidates need reciprocal unique-flank evidence.']}
    for a,r in zip(manifest['assemblies'],results):
        pair['genomes'].append({'id':a['id'],'material':a['strain'],'assembly':a['assembly_accession']+'_'+a['assembly_name'],'fasta':r['outputs']['fasta']['path'],'genes':r['outputs']['genes']['path'],'repeats':r['outputs']['repeats']['path'],'repeat_format':'repeatmasker-out','normalize_args':[],'selection_provenance':str(DATA/a['id']/'primary_selection.provenance.json')})
        a['analysis_selection']={'scope':r['scope'],'provenance':str(DATA/a['id']/'primary_selection.provenance.json'),'outputs':r['outputs']}
    manifest['status']='downloaded_verified_primary_nuclear_tuples_ready';manifest['pair_manifest']=str(ROOT/'metadata/mouse_pair.json');atomic_json(DISC/'mouse_sources.json',manifest);atomic_json(ROOT/'metadata/mouse_pair.json',pair)
    print('MOUSE_PAIR_MANIFEST_READY',flush=True)

if __name__=='__main__':main()
