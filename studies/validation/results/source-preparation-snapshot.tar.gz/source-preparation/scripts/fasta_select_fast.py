#!/usr/bin/env python3
"""FASTA QC/exact selection CLI with deterministic gzip level 1 output.

All arguments and scientific QC behavior come from fasta_qc.py. This separate
entry point keeps the already validated helper unchanged during active analyses.
Only selected FASTA compression is adjusted; input decompression is unchanged.
"""
import functools
import gzip
import sys
import types

import fasta_qc


def main():
    original = fasta_qc.gzip
    fasta_qc.gzip = types.SimpleNamespace(
        open=gzip.open,
        GzipFile=functools.partial(gzip.GzipFile, compresslevel=1),
    )
    try:
        print('Selected FASTA gzip compression level: 1; mtime: 0', file=sys.stderr)
        return fasta_qc.main()
    finally:
        fasta_qc.gzip = original


if __name__ == '__main__':
    sys.exit(main())
