#!/usr/bin/env python3
"""Sequential local batch continuation; records failures and never invents results.

This study-specific driver waits for the initially launched rat comparison and
the preparation jobs, then imports its unchanged genomic alignment into the
annotation-corrected run. Other species are independent and run sequentially.
"""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / 'scripts'
STATE = ROOT / 'metadata/batch_state.json'
LOGS = ROOT / 'reports/batch_logs'


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


state = {'started_at': stamp(), 'pid': os.getpid(), 'status': 'running', 'stages': []}


def save():
    tmp = STATE.with_suffix('.tmp')
    tmp.write_text(json.dumps(state, indent=2) + '\n')
    tmp.replace(STATE)


def run(label, argv):
    state['current_stage'] = label
    entry = {'label': label, 'argv': [str(v) for v in argv], 'started_at': stamp()}
    state['stages'].append(entry)
    save()
    with (LOGS / (label + '.log')).open('w') as log:
        code = subprocess.call(entry['argv'], stdout=log, stderr=subprocess.STDOUT)
    entry.update(exit_code=code, completed_at=stamp())
    save()
    if code:
        raise RuntimeError(label + ' failed; inspect ' + str(LOGS / (label + '.log')))


def wait_completed(directory, phase):
    marker = directory / (phase + '.done.json')
    state['current_stage'] = 'waiting_for_' + directory.name + '_' + phase
    save()
    started = time.monotonic()
    while not marker.exists():
        if time.monotonic() - started > 24 * 3600:
            raise RuntimeError('Timed out waiting for ' + str(marker))
        log = directory / 'run_commands.jsonl'
        if log.exists():
            records = [json.loads(line) for line in log.read_text().splitlines() if line.strip()]
            relevant = [r for r in records if r.get('phase') == phase]
            if relevant and relevant[-1].get('event') == 'phase_failed':
                raise RuntimeError('Earlier job failed in ' + str(directory) + ': ' + phase)
        time.sleep(10)


def complete_pair(label, manifest, directory, finish_only=False):
    run(label + '_analysis', [sys.executable, SCRIPTS / 'run_pair.py', '--manifest', manifest,
        '--output-dir', directory, '--phase', 'finish' if finish_only else 'all'])
    run(label + '_flanks', [sys.executable, SCRIPTS / 'validate_flanks.py', '--manifest', manifest,
        '--results', directory, '--minimap2', ROOT / 'tools/minimap2-src/minimap2', '--threads', '4'])
    priority = SCRIPTS / 'prioritize_candidates.py'
    if priority.exists():
        run(label + '_priority', [sys.executable, priority, '--results', directory])


def main():
    LOGS.mkdir(parents=True, exist_ok=True)
    save()
    failures = []
    try:
        raw = ROOT / 'results/rat'
        corrected = ROOT / 'results/rat_corrected'
        wait_completed(raw, 'finish')
        wait_completed(corrected, 'prepare')
        run('rat_reuse_alignment', [sys.executable, SCRIPTS / 'reuse_alignment.py',
            '--source-dir', raw, '--output-dir', corrected])
        # The original repeat table contains duplicated records. Archive that
        # preliminary run outside results so it cannot enter the study report.
        archive = ROOT / 'audit/rat_duplicate_source_preliminary'
        archive.parent.mkdir(exist_ok=True)
        if archive.exists():
            raise RuntimeError('Refuse to replace existing raw rat audit archive')
        raw.rename(archive)
        (archive / 'NOT_FOR_BIOLOGICAL_INTERPRETATION.txt').write_text(
            'Preliminary run on provider RepeatMasker rows duplicated exactly twice.\n'
            'Use results/rat_corrected for final candidates. Original location: results/rat.\n'
            'Absolute paths in archived markers retain the historical run location.\n')
        state['preliminary_rat_archive'] = str(archive)
        save()
        complete_pair('rat', ROOT / 'metadata/rat_corrected_pair.json', corrected, True)
    except Exception as exc:
        failures.append({'species': 'rat', 'error': str(exc)})
        state['failures'] = failures
        save()
    for label, manifest in [('maize', 'discovery/maize_pair.json'),
                            ('mouse', 'metadata/mouse_pair.json'),
                            ('human', 'metadata/human_pair.json')]:
        directory = ROOT / 'results' / label
        try:
            wait_completed(directory, 'prepare')
            complete_pair(label, ROOT / manifest, directory)
        except Exception as exc:
            failures.append({'species': label, 'error': str(exc)})
            state['failures'] = failures
            save()
        run('report_after_' + label, [sys.executable, SCRIPTS / 'study_report.py',
            '--study-dir', ROOT, '--output-dir', ROOT / 'reports/study'])
    state['status'] = 'failed' if failures else 'completed'
    state['completed_at'] = stamp()
    state['failures'] = failures
    state['current_stage'] = None
    save()
    return bool(failures)


if __name__ == '__main__':
    sys.exit(main())
