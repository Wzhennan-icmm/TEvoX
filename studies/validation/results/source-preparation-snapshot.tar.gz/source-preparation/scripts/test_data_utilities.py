#!/usr/bin/env python3
"""Small data-integrity regression tests; no network requests or large inputs."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import fasta_qc
import fetch_inputs


class UtilitiesTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def qc_args(self, text, compressed=True, select=None):
        path = self.root / ('source.fa.gz' if compressed else 'source.fa')
        if compressed:
            with gzip.open(path, 'wt') as handle:
                handle.write(text)
        else:
            path.write_text(text)
        if select is not None:
            (self.root / 'select.txt').write_text(select)
        return argparse.Namespace(input=str(path), lengths=str(self.root / 'lengths.tsv'),
                                  n_runs=str(self.root / 'gaps.bed'), summary=str(self.root / 'qc.json'),
                                  select=str(self.root / 'select.txt') if select is not None else None,
                                  selected_fasta=str(self.root / 'selected.fa.gz') if select is not None else None,
                                  force=False)

    def fetch_args(self, content=b'example input\n'):
        return argparse.Namespace(url='https://example.org/genome.fa.gz', output=str(self.root / 'input.gz'),
                                  record=str(self.root / 'input.json'), md5=hashlib.md5(content).hexdigest(),
                                  sha256=None, expected_bytes=len(content), max_bytes=1024 * 1024,
                                  checksum_source='https://example.org/md5checksums.txt')

    def fake_curl(self, content, calls, returncode=0, stderr=b''):
        def fake(command, stdout, stderr):
            calls.append(command)
            Path(command[command.index('--output') + 1]).write_bytes(content)
            stdout.write(b'https://cdn.example.org/genome.fa.gz?token=SECRET')
            class Process:
                def poll(self):
                    return self.returncode
            process = Process()
            process.returncode = returncode
            return process
        return fake

    def test_gzip_selection_and_cross_line_n_runs(self):
        args = self.qc_args('>chr1 original\nACNn\nnTAc\n>chr2\nNNtt\n', select='chr1\n')
        result = fasta_qc.qc(args)
        self.assertEqual(result['total_bases'], 12)
        self.assertEqual(result['n_bases'], 5)
        self.assertEqual(result['lowercase_bases'], 5)
        self.assertEqual(result['excluded_sequences'], [{'sequence_id': 'chr2', 'length': 4}])
        self.assertEqual(Path(args.n_runs).read_text(), 'chr1\t2\t5\nchr2\t0\t2\n')
        self.assertEqual(gzip.open(args.selected_fasta, 'rt').read(), '>chr1 original\nACNnnTAc\n')
        self.assertTrue(result['gzip_integrity_checked'])
        self.assertEqual(result['selected_bases'], 8)
        from normalize_annotations import read_lengths
        self.assertEqual(read_lengths(args.lengths), {'chr1': 8, 'chr2': 4})

    def test_plain_and_ambiguous_iupac(self):
        args = self.qc_args('>one\nACGTRYSWKMBDHVNacgtryswkmbdhvn\n', compressed=False)
        result = fasta_qc.qc(args)
        self.assertFalse(result['gzip_input'])
        self.assertEqual(result['total_bases'], 30)
        self.assertEqual(result['lowercase_bases'], 15)

    def test_duplicate_ids_fail_without_publishing(self):
        args = self.qc_args('>chr1 a\nACGT\n>chr1 b\nACGT\n')
        with self.assertRaisesRegex(ValueError, 'Duplicate FASTA'):
            fasta_qc.qc(args)
        self.assertFalse(Path(args.lengths).exists())
        self.assertFalse(Path(args.summary).exists())
        self.assertEqual(list(self.root.glob('*.tmp')), [])

    def test_missing_selection_does_not_normalize_names(self):
        args = self.qc_args('>chr1\nACGT\n', select='1\n')
        with self.assertRaisesRegex(ValueError, 'absent'):
            fasta_qc.qc(args)
        self.assertFalse(Path(args.selected_fasta).exists())

    def test_invalid_and_empty_sequences(self):
        for sequence, message in [('>x\nAC-GT\n', 'Invalid DNA'), ('>x\n>y\nAC\n', 'Empty FASTA'),
                                  ('ACGT\n', 'before first'), ('> x\nACGT\n', 'whitespace-prefixed')]:
            with self.subTest(sequence=sequence):
                args = self.qc_args(sequence)
                with self.assertRaisesRegex(ValueError, message):
                    fasta_qc.qc(args)

    def test_truncated_gzip_not_published(self):
        args = self.qc_args('>chr1\nACGTNN\n')
        path = Path(args.input)
        path.write_bytes(path.read_bytes()[:-4])
        with self.assertRaises((EOFError, OSError)):
            fasta_qc.qc(args)
        self.assertFalse(Path(args.summary).exists())

    def test_bounded_chunks_and_deterministic_selection(self):
        args = self.qc_args('>chr1\nACNNNNNNNTACGTNN\n', select='chr1\n')
        with mock.patch.object(fasta_qc, 'CHUNK', 8):
            result = fasta_qc.qc(args)
        self.assertEqual(Path(args.n_runs).read_text(), 'chr1\t2\t9\nchr1\t14\t16\n')
        original = Path(args.selected_fasta).read_bytes()
        args.force = True
        fasta_qc.qc(args)
        self.assertEqual(original, Path(args.selected_fasta).read_bytes())

    def test_download_and_reuse_checksum_provenance(self):
        content = b'example input\n'
        args = self.fetch_args(content)
        calls = []
        with mock.patch.object(fetch_inputs.subprocess, 'Popen', self.fake_curl(content, calls)):
            result = fetch_inputs.download(args)
            reused = fetch_inputs.download(args)
        self.assertEqual(len(calls), 1)
        self.assertEqual(result['verification'], 'source_checksum_verified')
        self.assertEqual(result['verified_algorithms'], ['md5'])
        self.assertEqual(result['effective_url'], 'https://cdn.example.org/genome.fa.gz?REDACTED')
        self.assertTrue(reused['reused'])
        self.assertNotIn('SECRET', Path(args.record).read_text())
        self.assertEqual(Path(args.output).read_bytes(), content)
        self.assertIn('--continue-at', calls[0])
        self.assertNotIn('--insecure', calls[0])

    def test_download_checksum_failure_not_published(self):
        args = self.fetch_args()
        with mock.patch.object(fetch_inputs.subprocess, 'Popen', self.fake_curl(b'incorrect', [])):
            with self.assertRaisesRegex(ValueError, 'checksum mismatch'):
                fetch_inputs.download(args)
        self.assertFalse(Path(args.output).exists())
        self.assertFalse(Path(args.record).exists())
        self.assertFalse(Path(args.output + '.part').exists())

    def test_unknown_existing_output_preserved(self):
        args = self.fetch_args()
        Path(args.output).write_bytes(b'user file')
        with self.assertRaisesRegex(ValueError, 'no provenance'):
            fetch_inputs.download(args)
        self.assertEqual(Path(args.output).read_bytes(), b'user file')

    def test_changed_source_and_corrupt_existing_rejected(self):
        content = b'example input\n'
        args = self.fetch_args(content)
        with mock.patch.object(fetch_inputs.subprocess, 'Popen', self.fake_curl(content, [])):
            fetch_inputs.download(args)
        args.url = 'https://example.org/other.fa.gz'
        with self.assertRaisesRegex(ValueError, 'differs'):
            fetch_inputs.download(args)
        args.url = 'https://example.org/genome.fa.gz'
        Path(args.output).write_bytes(b'corrupt')
        with self.assertRaisesRegex(ValueError, 'checksum mismatch'):
            fetch_inputs.download(args)

    def test_local_digest_is_not_publisher_verification(self):
        args = self.fetch_args()
        args.md5 = None
        args.checksum_source = None
        with mock.patch.object(fetch_inputs.subprocess, 'Popen', self.fake_curl(b'example input\n', [])):
            result = fetch_inputs.download(args)
        self.assertEqual(result['verification'], 'local_sha256_only')
        self.assertEqual(result['verified_algorithms'], [])

    def test_resume_only_matching_partial(self):
        content = b'example input\n'
        args = self.fetch_args(content)
        with mock.patch.object(fetch_inputs.subprocess, 'Popen', self.fake_curl(content[:4], [], returncode=18)):
            with self.assertRaisesRegex(ValueError, 'exit code 18'):
                fetch_inputs.download(args)
        self.assertEqual(Path(args.output + '.part').read_bytes(), content[:4])
        with mock.patch.object(fetch_inputs.subprocess, 'Popen', self.fake_curl(content, [])):
            result = fetch_inputs.download(args)
        self.assertEqual(result['resumed_bytes'], 4)

    def test_log_redacts_authentication_values(self):
        message = 'Failure for https://alice:secret@example.org/file?token=secret&signature=private'
        self.assertEqual(fetch_inputs.redact_log(message), 'Failure for https://example.org/file?REDACTED')

    def test_disk_and_size_limits(self):
        args = self.fetch_args()
        args.expected_bytes = args.max_bytes + 1
        with self.assertRaisesRegex(ValueError, 'exceeds'):
            fetch_inputs.download(args)
        args.expected_bytes = 14
        with mock.patch.object(fetch_inputs.shutil, 'disk_usage', return_value=argparse.Namespace(free=1000)):
            with self.assertRaisesRegex(ValueError, 'Insufficient free space'):
                fetch_inputs.download(args)


if __name__ == '__main__':
    unittest.main()
