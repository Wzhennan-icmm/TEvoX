#!/usr/bin/env python3
"""Derive matched human nuclear chromosome inputs without changing sequence bases.

Raw downloads remain intact. Select chr1..22 and X, excluding CHM13's HG002-derived
Y and both mitochondrial sequences. HG002 GenBank IDs are mapped explicitly from
the exact assembly report to the author's maternal chromosome annotation names.
"""
from collections import Counter
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
DISCOVERY = ROOT/'discovery'
MANIFEST = json.loads((DISCOVERY/'human_sources.json').read_text())
MOLECULES = {str(n) for n in range(1,23)} | {'X'}

def sha(path):
    h = hashlib.sha256()
    with open(path,'rb') as handle:
        for chunk in iter(lambda: handle.read(1<<20),b''): h.update(chunk)
    return h.hexdigest()

def report_rows(path):
    rows = []
    for line in path.read_text().splitlines():
        if line and not line.startswith('#'): rows.append(line.split('\t'))
    return rows

def gzip_writer(path):
    raw = open(path,'wb')
    return raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, compresslevel=3, mtime=0)

def select_fasta(source, destination, rows, aid):
    expected, rename = {}, {}
    for row in rows:
        raw_id = row[9] if aid == 'chm13' else row[4]
        assert raw_id not in ('na','')
        expected[raw_id] = int(row[8])
        if row[1] == 'assembled-molecule' and row[2] in MOLECULES and row[3] == 'Chromosome':
            rename[raw_id] = 'chr'+row[2]+('_MATERNAL' if aid == 'hg002_mat' else '')
    assert len(rename)==23 and len(set(rename.values()))==23
    part = Path(str(destination)+'.part')
    raw, output = gzip_writer(part)
    observed = {}; selected = {}; current=None; size=0; sequence_hash=None
    def finish():
        if current is None: return
        if current not in expected: raise ValueError('Unexpected FASTA ID '+current)
        if size != expected[current]: raise ValueError('Assembly-report length mismatch '+current)
        observed[current]={'length':size,'sequence_sha256':sequence_hash.hexdigest()}
        if current in rename: selected[rename[current]]=observed[current]
    try:
        with gzip.open(source,'rb') as handle:
            for line in handle:
                if line.startswith(b'>'):
                    finish()
                    current=line[1:].split(None,1)[0].decode('ascii')
                    if current in observed: raise ValueError('Duplicate FASTA ID '+current)
                    size=0; sequence_hash=hashlib.sha256()
                    if current in rename:
                        description=line[1:].decode('ascii').strip().split(None,1)
                        tail=' '+description[1] if len(description)>1 else ''
                        output.write(('>'+rename[current]+tail+'\n').encode())
                else:
                    if current is None: raise ValueError('Sequence before FASTA header')
                    bases=line.strip()
                    size+=len(bases); sequence_hash.update(bases)
                    if current in rename: output.write(bases+b'\n')
            finish()
        if set(observed)!=set(expected): raise ValueError('Missing assembly-report sequences')
        if set(selected)!=set(rename.values()): raise ValueError('Missing selected chromosomes')
        output.close();raw.close();os.replace(part,destination)
    finally:
        output.close();raw.close()
        if part.exists():part.unlink()
    return {'source':str(source),'output':str(destination),'output_sha256':sha(destination),
            'raw_sequences':observed,'selected_sequences':selected,'raw_to_selected_id':rename,
            'excluded_sequence_ids':sorted(set(observed)-set(rename)),
            'selected_bases':sum(x['length'] for x in selected.values()),
            'base_transformation':'none; original sequence case and bases preserved; HG002 header IDs renamed only'}

def filter_lines(lines,destination,allowed,lengths,kind):
    counts=Counter(); chromosomes=Counter();kept_chromosomes=Counter()
    part=Path(str(destination)+'.part');raw,output=gzip_writer(part)
    try:
        for line in lines:
            if not line.strip():continue
            if line.startswith(b'#'):
                if line.startswith(b'##FASTA'):raise ValueError('Unexpected embedded FASTA in GFF')
                if line.startswith(b'##sequence-region'):
                    seq=line.split()[1].decode()
                    if seq not in allowed:continue
                output.write(line);continue
            fields=line.rstrip(b'\r\n').split(b'\t')
            seq=fields[0].decode();chromosomes[seq]+=1;counts['source_rows']+=1
            if seq not in allowed:
                counts['excluded_rows']+=1;continue
            if kind=='genes':
                if len(fields)!=9:raise ValueError('GFF must have9columns')
                start,end=int(fields[3]),int(fields[4])
                if not 1<=start<=end<=lengths[seq]:raise ValueError('GFF coordinate outofrange')
                if fields[2]==b'gene':counts['kept_gene_features']+=1
            elif kind=='bed':
                if len(fields)!=10:raise ValueError('CHM13 repeatBED musthave10columns')
                start,end=int(fields[1]),int(fields[2])
                if not 0<=start<end<=lengths[seq]:raise ValueError('RepeatBED coordinate outofrange')
            elif kind=='bigrmsk':
                if len(fields)!=14:raise ValueError('HG002 bigRmsk musthave14columns')
                for description in fields[13].decode().split(','):
                    row=description.split()
                    if len(row)<15 or row[4]!=seq:raise ValueError('Invalid embedded RepeatMasker row')
                    start,end=int(row[5]),int(row[6])
                    if not 1<=start<=end<=lengths[seq]:raise ValueError('RepeatMasker coordinate outofrange')
                    counts['kept_repeatmasker_fragments']+=1
            output.write(line.rstrip(b'\r\n')+b'\n')
            counts['kept_rows']+=1;kept_chromosomes[seq]+=1
        if not counts['kept_rows']:raise ValueError('No annotation rows selected')
        if set(kept_chromosomes)!=allowed:raise ValueError('Missing annotations on selected chromosomes')
        output.close();raw.close();os.replace(part,destination)
    finally:
        output.close();raw.close()
        if part.exists():part.unlink()
    return {'output':str(destination),'output_sha256':sha(destination),'counts':dict(counts),
            'source_rows_per_sequence':dict(chromosomes),'selected_rows_per_sequence':dict(kept_chromosomes)}

runner={'pair_id':'human_chm13_hg002_mat','species':'Homo sapiens','preset':'asm10','threads':4,
        'source_manifest':str(DISCOVERY/'human_sources.json'),'genomes':[],
        'limitations':MANIFEST['limitations']}
for assembly in MANIFEST['assemblies']:
    aid=assembly['id'];directory=ROOT/'data/human'/aid
    report=DISCOVERY/('chm13_report.txt' if aid=='chm13' else 'hg002_mat_report.txt')
    files=assembly['files'];fasta=Path(files['fasta']['local_path'])
    selected_fasta=directory/'selected_nuclear.fa.gz'
    record=select_fasta(fasta,selected_fasta,report_rows(report),aid)
    lengths={key:value['length'] for key,value in record['selected_sequences'].items()};allowed=set(lengths)
    selected_genes=directory/'selected_nuclear.genes.gff3.gz'
    with gzip.open(files['gene_gff3']['local_path'],'rb') as handle:
        record['genes']=filter_lines(handle,selected_genes,allowed,lengths,'genes')
    selected_repeats=directory/'selected_nuclear.repeats.tsv.gz'
    if aid=='chm13':
        with open(files['repeats']['local_path'],'rb') as handle:
            record['repeats']=filter_lines(handle,selected_repeats,allowed,lengths,'bed')
        fmt='te-bed'
        arguments=['--bed-coordinates','zero-based-half-open','--bed-class-column','7',
                   '--bed-family-column','8','--bed-strand-column','6','--bed-id-column','10']
    else:
        log=open(ROOT/'metadata/human/bigBedToBed.log','wb')
        process=subprocess.Popen([str(ROOT/'tools/bigBedToBed'),files['repeats']['local_path'],'stdout'],stdout=subprocess.PIPE,stderr=log)
        try:
            record['repeats']=filter_lines(process.stdout,selected_repeats,allowed,lengths,'bigrmsk')
            if process.wait()!=0:raise RuntimeError('bigBedToBed conversion failed')
        finally:
            process.stdout.close()
            if process.poll() is None:process.terminate()
            process.wait();log.close()
        fmt='ucsc-bigrmsk-bed';arguments=[]
    record['assembly_report']=str(report);record['assembly_report_sha256']=sha(report)
    record['source_asset_provenance']={key:value['provenance_record'] for key,value in files.items()}
    record['selection_reason']=MANIFEST['selection']
    record_path=ROOT/'metadata/human'/(aid+'_selection.json')
    record_path.write_text(json.dumps(record,indent=2)+'\n')
    runner['genomes'].append({'id':aid,'material':assembly['individual'],'assembly':assembly['assembly_accession'],
        'fasta':str(selected_fasta),'genes':str(selected_genes),'repeats':str(selected_repeats),
        'repeat_format':fmt,'normalize_args':arguments,'selection_provenance':str(record_path)})
    print(aid,'selected23chromosomes',record['selected_bases'],'bp; annotations complete',flush=True)
(ROOT/'metadata/human_pair.json').write_text(json.dumps(runner,indent=2)+'\n')
MANIFEST['status']='raw-source-files-and-selected-matched-nuclear-inputs-ready'
MANIFEST['runner_manifest']=str(ROOT/'metadata/human_pair.json')
(DISCOVERY/'human_sources.json').write_text(json.dumps(MANIFEST,indent=2)+'\n')
print('HUMAN_PAIR_READY',flush=True)
