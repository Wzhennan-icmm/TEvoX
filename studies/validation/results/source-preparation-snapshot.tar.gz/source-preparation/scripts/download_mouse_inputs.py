#!/usr/bin/env python3
"""Fetch exact modern mouse source tuples; verify MD5 or provider BSD sum."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]; DISC=ROOT/'discovery'; DATA=ROOT/'data/mouse'; FETCH=ROOT/'scripts/fetch_inputs.py'
CONFIG=[('c57','C57BL/6NJ','GCA_921999865.2','C57BL_6NJ_v3','mus_musculus_c57bl6nj','SAMEA9544183'),('cast','CAST/EiJ','GCA_921999005.2','CAST_EiJ_v3','mus_musculus_casteij','SAMEA9544174')]


def atomic_json(path,value):
    temp=Path(str(path)+'.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)


def lookup_md5(path,filename):
    hits=[l.split()[0] for l in path.read_text().splitlines() if l.split() and l.split()[-1].split('/')[-1]==filename]
    if len(hits)!=1:raise ValueError('Ambiguous/missing checksum '+filename)
    return hits[0]


def build_manifest():
    probes={(r['label'],r['kind']):r for r in json.loads((DISC/'mouse_v3_artifact_probe.json').read_text())}
    publication=json.loads((DISC/'mouse_publication_sources.json').read_text())
    m={'pair_id':'mouse_c57_cast_v3','species':'Mus musculus','status':'verified_sources_download_in_progress','publication':publication['paper'],'publication_binding':publication['version_binding'],'publication_limitations':publication['limitations'],'assemblies':[],
       'repeat_comparability':{'provider':'UCSC GenArk','repeatmasker':'4.1.4','rmblastn':'2.13.0+','dfam':'3.6','families_selected':1395,'same_exact_options':False,'difference':"C57 -species 'Mus musculus'; CAST -species 'Mus musculus castaneus'. Family selection count agrees, exact selected library content not independently compared."}}
    for label,strain,acc,name,ens,sample in CONFIG:
        numbers=acc.split('_')[1].split('.')[0];ncbi='https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/'+numbers[:3]+'/'+numbers[3:6]+'/'+numbers[6:]+'/'+acc+'_'+name+'/'
        ucsc='https://hgdownload.soe.ucsc.edu/hubs/GCA/'+numbers[:3]+'/'+numbers[3:6]+'/'+numbers[6:]+'/'+acc+'/'
        ensembl='https://ftp.ensembl.org/pub/release-115/gff3/'+ens+'/'
        a={'id':label,'strain':strain,'assembly_accession':acc,'assembly_name':name,'biosample':sample,'bioproject':'PRJEB47108','annotation_release':'Ensembl 115','gene_build':'2023-06','assembly_release':'2022-07-01','files':{},'metadata_sources':{
           'ncbi_md5checksums.txt':{'url':ncbi+'md5checksums.txt','snapshot':str(DISC/(label+'_v3_ncbi_md5.txt'))},
           'genark_md5sum.txt':{'url':ucsc+'md5sum.txt','snapshot':str(DISC/(label+'_v3_genark_md5.txt'))},
           'ensembl_CHECKSUMS':{'url':ensembl+'CHECKSUMS','snapshot':str(DISC/(label+'_v3_ensembl_CHECKSUMS'))}}}
        for kind,probe_kind in [('fasta','fasta'),('gene_gff3','genes'),('repeatmasker','repeats')]:
            p=probes[label,probe_kind];filename=p['url'].split('/')[-1]
            f={'filename':filename,'url':p['url'],'compressed_bytes':int(p['bytes']),'head_status':p['status'],'local_path':str(DATA/label/filename)}
            if kind=='gene_gff3':
                row=next(x.split() for x in (DISC/(label+'_v3_ensembl_CHECKSUMS')).read_text().splitlines() if x.split()[-1]==filename)
                f.update({'checksum_algorithm':'BSD sum (sum -r)','bsd_sum':int(row[0]),'bsd_blocks_1024':int(row[1]),'checksum_source':ensembl+'CHECKSUMS'})
            else:f.update({'checksum_algorithm':'MD5','md5':lookup_md5(DISC/(label+'_v3_'+('ncbi_md5.txt' if kind=='fasta' else 'genark_md5.txt')),filename),'checksum_source':ncbi+'md5checksums.txt' if kind=='fasta' else ucsc+'md5sum.txt'})
            a['files'][kind]=f
        m['assemblies'].append(a)
    m['total_compressed_bytes']=sum(f['compressed_bytes'] for a in m['assemblies'] for f in a['files'].values())
    if m['total_compressed_bytes']>10*1024**3:raise ValueError('Species download budget exceeded')
    atomic_json(DISC/'mouse_sources.json',m)
    return m


def fetch(assembly,kind):
    folder=DATA/assembly['id'];folder.mkdir(parents=True,exist_ok=True)
    if kind in assembly['metadata_sources']:
        meta=assembly['metadata_sources'][kind];snapshot=Path(meta['snapshot']).read_bytes();url=meta['url'];filename=kind
        extra=['--sha256',hashlib.sha256(snapshot).hexdigest(),'--expected-bytes',str(len(snapshot))]
    else:
        f=assembly['files'][kind];url=f['url'];filename=f['filename']
        extra=['--expected-bytes',str(f['compressed_bytes'])]
        if kind!='gene_gff3':extra+=['--md5',f['md5'],'--checksum-source',f['checksum_source']]
    output=folder/filename;record=Path(str(output)+'.provenance.json')
    staged=Path(str(output)+'.awaiting_bsd') if kind=='gene_gff3' else output
    staged_record=Path(str(staged)+'.provenance.json')
    print('START',assembly['id'],kind,flush=True)
    if kind=='gene_gff3' and output.exists() and record.exists():
        previous=json.loads(record.read_text());sha=hashlib.sha256(output.read_bytes()).hexdigest()
        if previous['observed']['sha256']!=sha:raise ValueError('Previously mapped source altered')
        observed=subprocess.check_output(['sum','-r',str(output)],text=True).split()
        if [int(observed[0]),int(observed[1])]!=[f['bsd_sum'],f['bsd_blocks_1024']]:raise ValueError('BSD checksum mismatch on reuse')
    else:
        cmd=[sys.executable,str(FETCH),'--url',url,'--output',str(staged),'--record',str(staged_record),'--max-bytes',str(6*1024**3)]+extra
        run=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if run.stdout:print(run.stdout.strip(),flush=True)
        if run.returncode:
            print(run.stderr,flush=True);raise ValueError('Download failed '+assembly['id']+' '+kind)
        if kind=='gene_gff3':
            observed=subprocess.check_output(['sum','-r',str(staged)],text=True).split()
            if [int(observed[0]),int(observed[1])]!=[f['bsd_sum'],f['bsd_blocks_1024']]:raise ValueError('Publisher BSD checksum/block-count mismatch')
            provenance=json.loads(staged_record.read_text());provenance['output']=str(output);provenance['checksum_source']=f['checksum_source'];provenance['verification']='source_bsd_sum_verified';provenance['verified_algorithms']=['bsd-sum'];provenance['observed']['bsd_sum']=int(observed[0]);provenance['observed']['bsd_blocks_1024']=int(observed[1]);provenance['expected_provider_checksum']={'algorithm':'BSD sum','sum':f['bsd_sum'],'blocks_1024':f['bsd_blocks_1024']}
            staged.replace(output);atomic_json(record,provenance);staged_record.unlink()
    provenance=json.loads(record.read_text())
    print('DONE',assembly['id'],kind,flush=True)
    return {'id':assembly['id'],'kind':kind,'path':str(output),'record':str(record),'url':url,**provenance['observed'],'verification':provenance['verification']}


def main():
    m=build_manifest();DATA.mkdir(parents=True,exist_ok=True);results=[]
    for phase in [('ncbi_md5checksums.txt','genark_md5sum.txt','ensembl_CHECKSUMS'),('fasta',),('gene_gff3','repeatmasker')]:
        tasks=[(a,k) for a in m['assemblies'] for k in phase]
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            for future in concurrent.futures.as_completed([pool.submit(fetch,a,k) for a,k in tasks]):results.append(future.result())
        if phase==('fasta',):
            atomic_json(DATA/'fastas_ready.json',[r for r in results if r['kind']=='fasta']);print('BOTH_MOUSE_FASTAS_READY_MD5_VERIFIED',flush=True)
    atomic_json(DATA/'download_manifest.json',{'status':'all_sources_verified','source_manifest':str(DISC/'mouse_sources.json'),'files':results})
    for a in m['assemblies']:
        for k,f in a['files'].items():
            r=next(x for x in results if x['id']==a['id'] and x['kind']==k);f.update({'local_sha256':r['sha256'],'verification':r['verification'],'provenance_record':r['record']})
    m['status']='downloaded_source_checksums_verified';m['download_manifest']=str(DATA/'download_manifest.json');atomic_json(DISC/'mouse_sources.json',m)
    print('ALL_MOUSE_INPUTS_DOWNLOADED_VERIFIED',flush=True)

if __name__=='__main__':main()
