#!/usr/bin/env python3
"""Derive predicted gene-body GFF3 spans from GTF exons grouped by gene_id.

This conversion preserves coordinates (1-based inclusive) and is not evidence
of experimentally supported genes. Every source gene_id must be confined to
one sequence and one strand. Output spans min(exon start)..max(exon end),
including introns; source transcript, CDS, and codon rows are not extra genes.
"""
import argparse
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
from urllib.parse import quote

ATTRIBUTE = re.compile(r'\s*([^\s;]+)\s+"((?:\\.|[^"\\])*)"\s*(?:;|$)')


def parse_gtf_attributes(text):
    result = {}
    position = 0
    while position < len(text):
        if not text[position:].strip():
            break
        match = ATTRIBUTE.match(text, position)
        if not match:
            raise ValueError('Malformed quoted GTF attributes')
        key, raw = match.group(1), match.group(2)
        value = re.sub(r'\\([\\"])', r'\1', raw)
        if key in result and result[key] != value:
            raise ValueError('Conflicting duplicate GTF attribute: ' + key)
        result[key] = value
        position = match.end()
    return result


def derive_genes(lines, lengths):
    genes = {}
    counts = Counter()
    features = Counter()
    for line_number, line in enumerate(lines, 1):
        if not line.strip() or line.startswith('#'):
            continue
        fields = line.rstrip('\r\n').split('\t')
        if len(fields) != 9:
            raise ValueError(f'Line {line_number}: expected nine GTF columns')
        chrom, source, feature = fields[:3]
        start, end, strand = int(fields[3]), int(fields[4]), fields[6]
        if chrom not in lengths or not 1 <= start <= end <= lengths[chrom]:
            raise ValueError(f'Line {line_number}: coordinate outside supplied assembly')
        if strand not in {'+', '-', '.'}:
            raise ValueError(f'Line {line_number}: invalid strand')
        attrs = parse_gtf_attributes(fields[8])
        gene_id = attrs.get('gene_id')
        if not gene_id or gene_id == '.':
            raise ValueError(f'Line {line_number}: missing gene_id')
        if gene_id not in genes:
            genes[gene_id] = {'chrom': chrom, 'strand': strand, 'start': None, 'end': None, 'source': source, 'exons': 0}
        gene = genes[gene_id]
        if (gene['chrom'], gene['strand']) != (chrom, strand):
            raise ValueError(f'Line {line_number}: gene_id {gene_id!r} has discordant chromosome or strand')
        if gene['source'] != source:
            raise ValueError(f'Line {line_number}: gene_id {gene_id!r} has discordant source')
        counts['source_rows'] += 1
        features[feature] += 1
        if feature == 'exon':
            gene['start'] = start if gene['start'] is None else min(gene['start'], start)
            gene['end'] = end if gene['end'] is None else max(gene['end'], end)
            gene['exons'] += 1
    for gene_id, gene in genes.items():
        if gene['exons'] == 0:
            raise ValueError(f'gene_id {gene_id!r} has no exon rows')
    counts['derived_predicted_gene_spans'] = len(genes)
    return genes, {'counts': dict(counts), 'source_feature_counts': dict(features)}


def rows(genes, sample):
    esc = lambda value: quote(value, safe='.:_-')
    yield '##gff-version 3\n'
    yield '# Derived predicted gene-body spans from source GTF exons grouped by gene_id; no coordinate shift.\n'
    for gene_id, gene in sorted(genes.items(), key=lambda x: (x[1]['chrom'], x[1]['start'], x[1]['end'], x[0])):
        attrs = 'ID=' + esc(sample + ':Augustus:' + gene_id) + ';Name=' + esc(gene_id) + ';source_gene_id=' + esc(gene_id) + ';prediction_status=ab_initio;Note=Exon-derived%20predicted%20gene-body%20span'
        yield '\t'.join([gene['chrom'], 'AUGUSTUS_GTF_exon_span', 'gene', str(gene['start']), str(gene['end']), '.', gene['strand'], '.', attrs]) + '\n'


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as handle:
        for data in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True)
    parser.add_argument('--chrom-sizes', required=True)
    parser.add_argument('--sample', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--qc', required=True)
    args = parser.parse_args()
    inputs = {Path(args.input).resolve(), Path(args.chrom_sizes).resolve()}
    outputs = [Path(args.output).resolve(), Path(args.qc).resolve()]
    if len(set(outputs)) != 2 or any(path in inputs for path in outputs):
        parser.error('Output paths must be distinct from inputs and each other')
    lengths = {}
    for line in Path(args.chrom_sizes).read_text().splitlines():
        chrom, size = line.split()
        if chrom in lengths or int(size) <= 0:
            raise ValueError('Invalid or duplicate chrom.sizes record')
        lengths[chrom] = int(size)
    opener = gzip.open if args.input.endswith('.gz') else open
    with opener(args.input, 'rt') as handle:
        genes, qc = derive_genes(handle, lengths)
    outpath = Path(args.output)
    outpath.parent.mkdir(parents=True, exist_ok=True)
    with outpath.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
            with io.TextIOWrapper(gz, encoding='utf-8', newline='') as handle:
                handle.writelines(rows(genes, args.sample))
    qc.update(input=str(Path(args.input).resolve()), input_sha256=sha256(args.input), output=str(outpath.resolve()), output_sha256=sha256(outpath), sample=args.sample,
              coordinate_convention='1-based inclusive, unchanged from GTF',
              derivation='gene_id group min(exon start)..max(exon end); transcript/CDS/codon rows do not create additional genes',
              gene_provenance='UCSC GenArk AUGUSTUS ab initio predictions, not author NAM high-confidence gene annotation',
              interpretation='Predicted gene-body proximity is descriptive and does not establish expression, function or experimental validation',
              discordant_chromosome_or_strand_policy='Fail, do not merge',
              output_gff_feature='gene')
    Path(args.qc).write_text(json.dumps(qc, indent=2) + '\n')
    print(json.dumps(qc['counts']))


if __name__ == '__main__':
    main()
