#!/usr/bin/env python3
"""Fetch pinned plant sources using historical provenance without reclassifying it.

Publisher MD5 is verified when provided. Recorded local SHA256 is separately
checked for byte-identical reproduction, never described as a publisher checksum.
"""
import argparse
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def source_records(species):
    name = 'arabidopsis_2025_downloads.json' if species == 'arabidopsis' else 'maize_genark_downloads.json'
    return json.loads((ROOT / 'discovery' / name).read_text())


def fetch(entry):
    target = Path(entry['local_path'])
    if '@STUDY_ROOT@' in str(target) or not target.is_absolute() or ROOT not in target.parents:
        raise ValueError('Run initialize_study.py before downloading into the selected workspace')
    target.parent.mkdir(parents=True, exist_ok=True)
    provenance = Path(str(target) + '.provenance.json')
    cmd = [sys.executable, str(ROOT / 'scripts' / 'fetch_inputs.py'),
           '--url', entry.get('pinned_url', entry['url']), '--output', str(target),
           '--record', str(provenance), '--expected-bytes', str(entry['bytes'])]
    if entry.get('provider_md5'):
        cmd += ['--md5', entry['provider_md5'], '--checksum-source', entry['provider_checksum_url']]
    subprocess.run(cmd, check=True)
    digest = hashlib.sha256()
    with target.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    if digest.hexdigest() != entry['sha256']:
        raise ValueError('Source differs from recorded historical local SHA256: ' + str(target))
    observed = json.loads(provenance.read_text())
    observed['historical_local_sha256_reproduction'] = {'expected': entry['sha256'], 'matched': True, 'publisher_checksum': False}
    provenance.write_text(json.dumps(observed, indent=2) + '\n')
    return {'sample': entry['sample'], 'role': entry['role'], 'path': str(target), 'provenance': str(provenance)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--species', choices=['arabidopsis', 'maize'], required=True)
    parser.add_argument('--list', action='store_true', help='Print pinned sources without downloading')
    args = parser.parse_args()
    records = source_records(args.species)
    if args.list:
        for entry in records:
            print(entry['sample'], entry['role'], entry['bytes'], entry.get('pinned_url', entry['url']))
        return
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        completed = list(pool.map(fetch, records))
    out = ROOT / 'metadata' / (args.species + '_download_reproduction.json')
    out.write_text(json.dumps(completed, indent=2) + '\n')
    print('Verified', len(completed), 'source files')


if __name__ == '__main__':
    main()
