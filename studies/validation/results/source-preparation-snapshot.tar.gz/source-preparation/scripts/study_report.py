#!/usr/bin/env python3
"""Report completed real pair workflows, with explicit pending/failed species.

No placeholder biological metrics are invented for missing or incomplete runs.
Figures show within-pair diagnostics, not cross-species TE activity comparisons.
"""
import argparse
import collections
import csv
import datetime
import hashlib
import json
import os
from pathlib import Path
from urllib.parse import quote, unquote


SPECIES = [("human", "Homo sapiens", "人"), ("mouse", "Mus musculus", "小鼠"),
           ("rat", "Rattus norvegicus", "大鼠"),
           ("arabidopsis", "Arabidopsis thaliana", "拟南芥"), ("maize", "Zea mays", "玉米")]
CATEGORIES = ["anchored_gap_candidate", "unresolved_outside_alignment", "low_quality_N_or_contig_edge"]


def read_json(path):
    return json.loads(Path(path).read_text())


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def fingerprint_matches(record, require_hash=False):
    path = Path(record["path"])
    if not path.is_file() or (require_hash and "sha256" not in record):
        return False
    stat = path.stat()
    actual = dict(path=str(path.resolve()), size=stat.st_size, mtime_ns=stat.st_mtime_ns,
                  ctime_ns=stat.st_ctime_ns, device=stat.st_dev, inode=stat.st_ino)
    if "sha256" in record:
        actual["sha256"] = file_sha256(path)
    return actual == record


def species_key(value):
    value = str(value).lower().strip()
    for key, scientific, chinese in SPECIES:
        if value in (key, scientific.lower(), chinese) or value.startswith(scientific.lower() + " "):
            return key
    return None


def resolve_reference(value, parent):
    path = Path(value)
    return path if path.is_absolute() else parent / path


def completion_status(directory):
    """Require the runner's explicit completion marker and unchanged outputs."""
    marker = directory / "finish.done.json"
    summary = directory / "evidence/summary.json"
    if marker.is_file():
        data = read_json(marker)
        outputs = data.get("outputs", [])
        if data.get("status") != "completed" or not outputs:
            return "incomplete", "完成标记无效", None
        if data.get("signature", {}).get("manifest") != read_json(directory / "manifest.json"):
            return "incomplete", "材料清单与完成标记不一致，需要复核", None
        matched_summary = False
        for output in outputs:
            path = Path(output["path"])
            if not path.is_file():
                return "incomplete", "完成标记引用的结果文件缺失", None
            stat = path.stat()
            observed = dict(path=str(path.resolve()), size=stat.st_size, mtime_ns=stat.st_mtime_ns,
                            ctime_ns=stat.st_ctime_ns, device=stat.st_dev, inode=stat.st_ino)
            if observed != output:
                return "incomplete", "结果文件与完成标记不一致，需要复核", None
            matched_summary = matched_summary or path.resolve() == summary.resolve()
        if not matched_summary or not summary.is_file():
            return "incomplete", "完成标记未包含证据汇总", None
        return "completed", "整对材料分析完成", data.get("completed_at")
    status, reason = "pending", "尚无完成的整对材料分析"
    log = directory / "run_commands.jsonl"
    if log.is_file():
        for line in log.read_text().splitlines():
            if not line.strip():
                continue
            event = json.loads(line)
            if event.get("event") in ("phase_started", "command_started"):
                status, reason = "pending", "流程正在运行或尚未完成"
            if event.get("event") == "command_finished" and event.get("exit_code", 0):
                status, reason = "blocked", "命令执行失败；见运行日志"
            if event.get("event") == "phase_failed":
                status, reason = "blocked", str(event.get("error", "阶段执行失败"))
    return status, reason, None


def optional_flank_validation(directory):
    """Keep supplementary mapping evidence distinct from initial TEvoX counts."""
    folder = directory / "flank_validation"
    marker = folder / "done.json"
    if not marker.is_file():
        return None
    done = read_json(marker)
    if done.get("status") != "completed":
        return {"status": "incomplete", "reason": "Optional flank validation lacks a valid completion marker"}
    found = set()
    for record in done.get("outputs", []):
        path = Path(record["path"])
        if not path.is_file():
            return {"status": "incomplete", "reason": "Optional flank output missing"}
        stat = path.stat()
        actual = dict(path=str(path.resolve()), size=stat.st_size, mtime_ns=stat.st_mtime_ns,
                      ctime_ns=stat.st_ctime_ns, device=stat.st_dev, inode=stat.st_ino,
                      sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        if actual != record:
            return {"status": "incomplete", "reason": "Optional flank output fingerprint/hash differs"}
        found.add(path.name)
    if not {"summary.json", "loci.tsv"} <= found:
        return {"status": "incomplete", "reason": "Optional completion marker omits required outputs"}
    finish_signature = [record for record in done.get("signature", {}).get("inputs", [])
                        if Path(record["path"]).resolve() == (directory / "finish.done.json").resolve()]
    if len(finish_signature) != 1 or finish_signature[0].get("sha256") != hashlib.sha256((directory / "finish.done.json").read_bytes()).hexdigest():
        return {"status": "incomplete", "reason": "Optional validation does not match current pair completion marker"}
    per_genome = {"genome1": {}, "genome2": {}}
    seen = set()
    aliases = {"reciprocal_unique_flank_supported_candidate": "supported", "ambiguous": "ambiguous",
               "failed": "failed", "not_validated": "not_validated"}
    with (folder / "loci.tsv").open() as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            key = "genome" + row["genome"]
            category = aliases[row["status"]]
            fragments = json.loads(row["fragment_ids_json"])
            for fragment in fragments:
                identifier = (key, fragment)
                if identifier in seen:
                    raise ValueError("Duplicate fragment across optional flank loci")
                seen.add(identifier)
            counts = per_genome[key]
            counts[category + "_gap_loci"] = counts.get(category + "_gap_loci", 0) + 1
            counts[category + "_candidate_fragments"] = counts.get(category + "_candidate_fragments", 0) + len(fragments)
    return {"status": "completed", "per_genome": per_genome, "summary": read_json(folder / "summary.json"),
            "result_directory": str(folder)}


def source_details(manifest, manifest_path):
    source_path = manifest.get("source_manifest")
    if not source_path:
        return {}, None
    source_path = resolve_reference(source_path, manifest_path.parent)
    if not source_path.is_file():
        return {}, str(source_path)
    return read_json(source_path), str(source_path)


def optional_priority_exports(directory, validation):
    path = directory / "priority_summary.json"
    if not path.is_file():
        return None
    if not validation or validation.get("status") != "completed":
        return {"status": "incomplete", "reason": "Priority exports require current completed flank evidence"}
    summary = read_json(path)
    outputs = summary.get("outputs", [])
    inputs = summary.get("signature", {}).get("inputs", [])
    required_outputs = {str((directory / name).resolve()) for name in ("priority_candidates.tsv", "priority_loci.tsv")}
    required_inputs = {str((directory / name).resolve()) for name in ("finish.done.json", "flank_validation/done.json")}
    if not required_outputs <= {record["path"] for record in outputs} or not required_inputs <= {record["path"] for record in inputs}:
        return {"status": "incomplete", "reason": "Priority provenance omits required inputs or outputs"}
    for record in inputs + outputs:
        item = Path(record["path"])
        if not item.is_file():
            return {"status": "incomplete", "reason": "Priority input or output is missing"}
        stat = item.stat()
        actual = dict(path=str(item.resolve()), size=stat.st_size, mtime_ns=stat.st_mtime_ns,
                      ctime_ns=stat.st_ctime_ns, device=stat.st_dev, inode=stat.st_ino,
                      sha256=file_sha256(item))
        if actual != record:
            return {"status": "incomplete", "reason": "Priority provenance fingerprint/hash differs"}
    counts = summary.get("counts", {})
    for number in (1, 2):
        observed = validation["per_genome"]["genome" + str(number)]
        if (counts.get("genome%d_candidate_fragments" % number, 0) != observed.get("supported_candidate_fragments", 0)
                or counts.get("genome%d_alignment_gap_loci" % number, 0) != observed.get("supported_gap_loci", 0)):
            return {"status": "incomplete", "reason": "Priority counts differ from supported flank candidates"}
    return {"status": "completed", "summary": summary, "summary_path": str(path),
            "candidates_path": str(directory / "priority_candidates.tsv"), "loci_path": str(directory / "priority_loci.tsv")}


def gap_coordinate_counts(rows):
    source, opposite, paired = (collections.defaultdict(list) for _ in range(3))
    boundaries = collections.defaultdict(set)
    for row in rows:
        interval = (row["source_chrom"], int(row["source_gap_start0"]), int(row["source_gap_end0"]))
        point = (row["opposite_chrom"], int(row["opposite_empty_site0"]), int(row["opposite_empty_site0"]))
        side = row["genome"]
        source[(side,) + interval].append(row["alignment_id"])
        opposite[("2" if side == "1" else "1",) + point].append(row["locus_id"])
        paired[(interval, point) if side == "1" else (point, interval)].append(row["locus_id"])
        if side == "2":
            for boundary in interval[1:]:
                boundaries[(interval[0], boundary, point[0], point[1])].add(row["locus_id"])
    matches = set()
    for row in rows:
        if row["genome"] == "1":
            for boundary in (int(row["source_gap_start0"]), int(row["source_gap_end0"])):
                key = (row["opposite_chrom"], int(row["opposite_empty_site0"]), row["source_chrom"], boundary)
                matches.update((row["locus_id"], other) for other in boundaries.get(key, []))
    return dict(source_interval_exact_duplicate_groups=sum(len(group) > 1 for group in source.values()),
        source_interval_duplicates_with_different_alignment_ids=sum(len(set(group)) > 1 for group in source.values()),
        opposite_empty_point_exact_duplicate_groups=sum(len(group) > 1 for group in opposite.values()),
        normalized_paired_interval_exact_duplicate_groups=sum(len(group) > 1 for group in paired.values()),
        cross_side_mutual_exact_gap_boundary_matches=[list(pair) for pair in sorted(matches)])


def optional_gap_composition(directory, manifest, priorities):
    summary_path, table = directory / "gap_composition_summary.json", directory / "gap_composition.tsv"
    if not summary_path.is_file():
        return None
    def invalid(reason):
        return {"status": "incomplete", "reason": reason}
    if not priorities or priorities.get("status") != "completed":
        return invalid("Gap composition requires current verified priority exports")
    summary = read_json(summary_path)
    if summary.get("status") != "completed" or summary.get("schema_version") != 1 or summary.get("pair_id") != manifest["pair_id"]:
        return invalid("Gap composition status/schema/pair identity differs")
    signature = summary.get("signature", {})
    inputs, scripts, outputs = signature.get("inputs", []), signature.get("scripts", []), summary.get("outputs", [])
    required = {str((directory / name).resolve()) for name in ("manifest.json", "priority_summary.json", "priority_candidates.tsv", "priority_loci.tsv")}
    for genome in manifest["genomes"]:
        required.update(str((directory / genome["id"] / name).resolve()) for name in ("repeats.bed", "lengths.tsv"))
        required.add(str(Path(genome["genes"]).resolve()))
    if not required <= {item["path"] for item in inputs} or not scripts or str(table.resolve()) not in {item["path"] for item in outputs}:
        return invalid("Gap composition provenance omits required inputs/helper/output")
    if not all(fingerprint_matches(item, True) for item in inputs + scripts + outputs):
        return invalid("Gap composition input/helper/output fingerprint or SHA256 differs")
    with table.open() as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    if len({row["locus_id"] for row in rows}) != len(rows):
        return invalid("Gap composition repeats a locus ID")
    per_genome = {genome["id"]: dict(supported_gap_loci=0, supported_candidate_fragments=0,
        retained_TE_union_below_10_percent=0, retained_TE_union_below_50_percent=0, retained_TE_union_below_80_percent=0) for genome in manifest["genomes"]}
    for row in rows:
        side = row["genome"]
        if side not in ("1", "2") or row["genome_id"] != manifest["genomes"][int(side)-1]["id"]:
            return invalid("Gap composition genome identity differs")
        width = int(row["source_gap_end0"]) - int(row["source_gap_start0"])
        all_bases, supported_bases = int(row["retained_annotation_union_bp"]), int(row["supported_candidate_union_bp"])
        fragments = int(row["supported_fragment_count"])
        if width <= 0 or width != int(row["gap_length_bp"]) or not 0 <= supported_bases <= all_bases <= width or fragments <= 0:
            return invalid("Gap composition lengths/union counts are inconsistent")
        if abs(all_bases/width-float(row["retained_annotation_gap_fraction"])) > 1e-12 or abs(supported_bases/width-float(row["supported_candidate_gap_fraction"])) > 1e-12:
            return invalid("Gap composition fractions differ from their gap denominators")
        counts = per_genome[row["genome_id"]]
        counts["supported_gap_loci"] += 1
        counts["supported_candidate_fragments"] += fragments
        for threshold in (10, 50, 80):
            counts["retained_TE_union_below_%d_percent" % threshold] += all_bases/width < threshold/100
    expected = dict(supported_alignment_gap_loci=len(rows), supported_candidate_fragments=sum(value["supported_candidate_fragments"] for value in per_genome.values()))
    expected.update({"gaps_with_retained_TE_union_below_%d_percent" % threshold: sum(value["retained_TE_union_below_%d_percent" % threshold] for value in per_genome.values()) for threshold in (10,50,80)})
    if any(summary.get("counts", {}).get(name) != count for name, count in expected.items()):
        return invalid("Gap composition summary totals differ from verified TSV")
    priority_counts = priorities["summary"]["counts"]
    for side, genome in enumerate(manifest["genomes"], 1):
        counts = per_genome[genome["id"]]
        if counts["supported_gap_loci"] != priority_counts.get("genome%d_alignment_gap_loci" % side, 0) or counts["supported_candidate_fragments"] != priority_counts.get("genome%d_candidate_fragments" % side, 0):
            return invalid("Gap composition counts differ from current priority exports")
        scope = summary.get("gene_feature_scope", {}).get(genome["id"], {})
        source_counts = scope.get("source_feature_counts", {})
        if scope.get("included_feature_type") != "gene" or scope.get("included_exact_gene_rows") != source_counts.get("gene", 0) or scope.get("omitted_feature_counts") != {key:value for key,value in source_counts.items() if key != "gene"}:
            return invalid("Gap composition gene-feature scope is inconsistent")
        if scope.get("omitted_other_gene_like_features") != {key:value for key,value in source_counts.items() if key != "gene" and (key.endswith("_gene") or key == "pseudogene")}:
            return invalid("Gap composition omitted gene-like feature counts are inconsistent")
    coordinates = gap_coordinate_counts(rows)
    if any(summary.get("exact_coordinate_audit", {}).get(name) != value for name,value in coordinates.items()):
        return invalid("Gap exact-coordinate audit differs from verified TSV")
    return dict(status="completed", summary=summary, per_genome=per_genome, table_path=str(table), summary_path=str(summary_path))


def optional_alignment_profile(directory, manifest):
    path, marker = directory / "alignment_profile.json", directory / "align.done.json"
    if not path.is_file():
        return None
    profile = read_json(path)
    def result(status, reason, **extra):
        return dict(status=status, reason=reason, profile_id=profile.get("profile_id", "not_recorded"),
            declared_profile=profile, profile_path=str(path), **extra)
    if profile.get("schema_version") != 1 or profile.get("original_preset") != manifest.get("preset"):
        return result("incomplete", "Declared profile schema/preset differs from current manifest")
    if profile.get("profile_id") != "maize_low_memory_v1" or profile.get("overrides") != ["-w19", "-f50", "-U50,50", "-e0", "-t1", "-K25m"]:
        return result("incomplete", "Declared profile is not the supported audited low-memory configuration")
    if not marker.is_file():
        return result("pending", "Profile declared; no completed alignment marker verifies application")
    done = read_json(marker)
    signature = done.get("signature", {})
    if done.get("status") != "completed" or signature.get("manifest") != manifest:
        return result("incomplete", "Alignment completion marker does not match current manifest")
    tools = signature.get("tools", [])
    if not tools or tools[0].get("path") != profile.get("launcher") or tools[0].get("sha256") != profile.get("launcher_sha256"):
        return result("incomplete", "Declared launcher path/SHA256 differs from completed alignment tool")
    if not fingerprint_matches(tools[0], True):
        return result("incomplete", "Completed alignment launcher fingerprint/SHA256 differs")
    binary = Path(profile["underlying_binary"])
    if not binary.is_file() or file_sha256(binary) != profile.get("underlying_sha256"):
        return result("incomplete", "Pinned underlying minimap2 SHA256 differs")
    outputs = done.get("outputs", [])
    log, paf = directory / "logs/minimap2.stderr.log", directory / "alignment.paf.gz"
    if not {str(log.resolve()), str(paf.resolve())} <= {item["path"] for item in outputs} or not all(fingerprint_matches(item) for item in outputs):
        return result("incomplete", "Completed alignment output/log fingerprints differ")
    fasta_paths = [str(Path(genome["fasta"]).resolve()) for genome in manifest["genomes"]]
    alignment_inputs = {item["path"]:item for item in signature.get("inputs", [])}
    if not all(name in alignment_inputs and fingerprint_matches(alignment_inputs[name]) for name in fasta_paths):
        return result("incomplete", "Profile FASTA inputs differ from completed alignment provenance")
    events = []
    with log.open() as handle:
        for line in handle:
            if line.startswith("TEVOX_MINIMAP2_PROFILE "):
                events.append(json.loads(line.split(" ", 1)[1]))
    if len(events) != 1:
        return result("incomplete", "Alignment stderr lacks one unambiguous applied profile record")
    event = events[0]
    requested = ['-x',manifest['preset'],'-c','--eqx','--secondary=no','-t',str(manifest['threads']),'-I6G','-K250m',fasta_paths[1],fasta_paths[0]]
    effective = [str(binary)] + requested[:-2] + profile.get("overrides", []) + requested[-2:]
    if event.get("profile_id") != profile.get("profile_id") or event.get("underlying_sha256") != profile.get("underlying_sha256") or event.get("requested_argv") != requested or event.get("effective_argv") != effective:
        return result("incomplete", "Applied profile argv or pinned binary differs from declaration/manifest")
    if profile.get("whole_genome_inputs_preserved") is not True or any(option.startswith('-I') for option in profile.get("overrides", [])):
        return result("incomplete", "Profile does not establish preserved complete FASTAs and the single target index")
    return result("applied", "Completed alignment tool, inputs, output log and effective argv verified", applied_record=event,
        log_path=str(log), log_sha256=file_sha256(log), align_marker_sha256=file_sha256(marker))


def assembly_details(genome, source):
    assembly = str(genome.get("assembly", genome.get("assembly_accession", "")))
    identifiers = {str(genome.get(key, "")).lower() for key in ("id", "material", "assembly", "assembly_accession")}
    identifiers.discard("")
    for item in source.get("assemblies", source.get("genomes", [])):
        accession = str(item.get("assembly_accession", item.get("accession", "")))
        values = {str(item.get(key, "")).lower() for key in
                  ("label", "id", "strain", "material", "assembly_name", "assembly_accession", "accession")}
        values.discard("")
        if identifiers & values or (accession and (assembly == accession or assembly.startswith(accession + "_"))):
            return item
    return {}


def input_records(pair_id, genome, detail, manifest_path):
    records = []
    selection_path = resolve_reference(genome["selection_provenance"], manifest_path.parent) if genome.get("selection_provenance") else None
    selection = read_json(selection_path) if selection_path and selection_path.is_file() else {}
    for kind, source_key in (("fasta", "fasta"), ("genes", "gene_gff3"), ("repeats", "repeatmasker")):
        if not genome.get(kind):
            continue
        path = resolve_reference(genome[kind], manifest_path.parent).resolve()
        source_role = "genome" if kind == "fasta" else kind
        file_detail = detail.get("files", {}).get(source_key, detail.get("files", {}).get(kind, genome.get("source_files", {}).get(source_role, {})))
        filtered = genome.get("filtered_annotation_qc", {}).get(kind, {})
        derivation_record = None
        immediate_parent = None
        derivation_method = "derived_file_local_sha256_and_coordinate_checks"
        if kind == "genes" and genome.get("derived_gene_qc"):
            derivation = genome["derived_gene_qc"]
            if Path(derivation.get("output", "")).resolve() != path:
                raise ValueError("Derived gene output differs from source provenance")
            filtered = dict(filtered_path=str(path), filtered_sha256=derivation["output_sha256"],
                filtered_bytes=path.stat().st_size if path.is_file() else "", source_path=derivation["input"],
                source_sha256=derivation["input_sha256"])
            derivation_record = manifest_path
            derivation_method = "derived_file_local_sha256; predicted_gene_spans_from_source_GTF_exons"
        selected = selection.get("outputs", {}).get(kind, selection if kind == "fasta" else selection.get(kind, {}))
        selected_path = selected.get("path", selected.get("output"))
        if selected_path and Path(selected_path).resolve() == path:
            filtered = dict(filtered_path=str(path), filtered_sha256=selected.get("sha256", selected.get("output_sha256", "")),
                filtered_bytes=selected.get("bytes", path.stat().st_size if path.is_file() else ""),
                source_path=file_detail.get("local_path", selection.get("source", "") if kind == "fasta" else ""),
                source_sha256=file_detail.get("local_sha256", file_detail.get("sha256", "")))
            if not filtered["source_path"]:
                raise ValueError("Selected input lacks original source provenance: " + str(path))
            derivation_record = selection_path
            derivation_method = "derived_file_local_sha256; declared_nuclear_sequence_selection_and_coordinate_mapping"
        if kind == "repeats" and genome.get("repeat_fragment_extraction_provenance"):
            derivation_record = resolve_reference(genome["repeat_fragment_extraction_provenance"], manifest_path.parent)
            extraction = read_json(derivation_record)
            if extraction.get("status") != "passed" or Path(extraction.get("output", "")).resolve() != path:
                raise ValueError("Invalid repeat fragment extraction provenance for " + genome["id"])
            filtered = dict(filtered_path=str(path), filtered_sha256=extraction["output_sha256"],
                filtered_bytes=path.stat().st_size if path.is_file() else "", source_path=file_detail["local_path"],
                source_sha256=file_detail["local_sha256"])
            immediate_parent = dict(path=extraction["input"], sha256=extraction["input_sha256"])
            derivation_method = "derived_file_local_sha256; original_RepeatMasker_fragment_extraction_from_selected_browser_records"
        if kind == "repeats" and genome.get("repeat_deduplication_provenance"):
            derivation_record = resolve_reference(genome["repeat_deduplication_provenance"], manifest_path.parent)
            dedup = read_json(derivation_record)
            if dedup.get("status") != "passed" or Path(dedup.get("output", "")).resolve() != path:
                raise ValueError("Invalid repeat deduplication provenance for " + genome["id"])
            filtered = dict(filtered_path=dedup["output"], filtered_sha256=dedup["output_sha256_local"],
                filtered_bytes=dedup["output_bytes"], source_path=dedup["source"], source_sha256=dedup["source_sha256_local"])
            derivation_method = "derived_file_local_sha256; consecutive_exact_source_record_deduplication"
        provenance_path = Path(file_detail.get("provenance_record", str(path) + ".provenance.json"))
        provenance = read_json(provenance_path) if provenance_path.is_file() else {}
        observed = provenance.get("observed", {})
        derived = bool(filtered and Path(filtered.get("filtered_path", "")).resolve() == path)
        records.append({"pair_id": pair_id, "genome_id": genome["id"], "kind": kind,
            "path": str(path), "local_file_present": path.is_file(),
            "url": "" if derived else provenance.get("original_url", file_detail.get("pinned_url", file_detail.get("url", ""))),
            "sha256": filtered.get("filtered_sha256", "") if derived else observed.get("sha256", file_detail.get("local_sha256", file_detail.get("sha256", ""))),
            "md5": "" if derived else observed.get("md5", file_detail.get("verified_md5", file_detail.get("md5", file_detail.get("provider_md5", "")))),
            "bytes": filtered.get("filtered_bytes", "") if derived else observed.get("bytes", file_detail.get("compressed_bytes", file_detail.get("bytes", ""))),
            "verification": (derivation_method if derived else
                provenance.get("verification", "source_checksum_verified" if file_detail.get("md5_verified") else "local_sha256_and_gzip_crc; no_provider_checksum" if file_detail.get("gzip_crc_validated") else "not_recorded")),
            "checksum_source": "" if derived else provenance.get("checksum_source", file_detail.get("provider_checksum_url", file_detail.get("checksum_source", detail.get("checksums_url", "")))),
            "provenance_record": str(derivation_record) if derived and derivation_record else str(provenance_path) if provenance_path.is_file() else str(manifest_path),
            "derived_from": immediate_parent["path"] if immediate_parent else filtered.get("source_path", "") if derived else ""})
        if derived:
            original_path = Path(filtered["source_path"])
            original_provenance_path = Path(file_detail.get("provenance_record", str(original_path) + ".provenance.json"))
            original_provenance = read_json(original_provenance_path) if original_provenance_path.is_file() else {}
            original_observed = original_provenance.get("observed", {})
            records.append({"pair_id": pair_id, "genome_id": genome["id"], "kind": kind + "_source",
                "path": str(original_path), "local_file_present": original_path.is_file(),
                "url": original_provenance.get("original_url", file_detail.get("pinned_url", file_detail.get("url", ""))),
                "sha256": filtered.get("source_sha256", file_detail.get("sha256", "")),
                "md5": original_observed.get("md5", file_detail.get("verified_md5", file_detail.get("md5", file_detail.get("provider_md5", "")))),
                "bytes": original_observed.get("bytes", file_detail.get("compressed_bytes", file_detail.get("bytes", ""))),
                "verification": original_provenance.get("verification", "source_checksum_verified" if file_detail.get("md5_verified") else "local_sha256_and_gzip_crc; no_provider_checksum" if file_detail.get("gzip_crc_validated") else "not_recorded"),
                "checksum_source": original_provenance.get("checksum_source", file_detail.get("provider_checksum_url", file_detail.get("checksum_source", detail.get("checksums_url", "")))),
                "provenance_record": str(original_provenance_path) if original_provenance_path.is_file() else str(manifest_path), "derived_from": ""})
            if immediate_parent:
                parent_path = Path(immediate_parent["path"])
                records.append(dict(pair_id=pair_id, genome_id=genome["id"], kind=kind + "_selected_browser_source",
                    path=str(parent_path), local_file_present=parent_path.is_file(), url="", sha256=immediate_parent["sha256"], md5="",
                    bytes=parent_path.stat().st_size if parent_path.is_file() else "",
                    verification="derived_file_local_sha256; selected_browser_annotation_records", checksum_source="",
                    provenance_record=str(selection_path), derived_from=str(original_path)))
    return records


def normalization_scope(directory, genome):
    qc_path = directory / genome["id"] / "repeats.qc.json"
    if not qc_path.is_file():
        return None
    qc = read_json(qc_path)
    counts = qc.get("counts", {})
    unresolved, unresolved_families = collections.Counter(), collections.Counter()
    rejected_path = directory / genome["id"] / "repeats.rejected.tsv"
    if counts.get("rejected_unresolved_class", 0) and rejected_path.is_file():
        configuration = qc.get("configuration", {})
        with rejected_path.open() as handle:
            for row in csv.DictReader(handle, delimiter="\t"):
                if row["reason"] != "unresolved_class":
                    continue
                record = row["source_record"]
                source_class = "unparsed_source_class"
                source_family = ""
                try:
                    if qc["format"] in ("repeatmasker-out", "ucsc-bigrmsk-bed"):
                        source_class = record.split()[10]
                    elif qc["format"] == "ucsc-rmsk":
                        fields = record.split("\t")
                        source_class = fields[11 if len(fields) == 17 else 10]
                        source_family = fields[12 if len(fields) == 17 else 11]
                    elif qc["format"] == "te-bed" and configuration.get("bed_class_column"):
                        source_class = record.split("\t")[configuration["bed_class_column"] - 1]
                        if configuration.get("bed_family_column"):
                            source_family = record.split("\t")[configuration["bed_family_column"] - 1]
                    elif qc["format"] == "repeat-gff3":
                        attributes = {unquote(key): unquote(value) for key, value in
                            (part.split("=", 1) for part in record.split("\t")[8].split(";") if "=" in part)}
                        source_class = attributes.get(configuration.get("class_attribute", "Classification"), "missing_source_class")
                        if configuration.get("family_attribute"):
                            source_family = attributes.get(configuration["family_attribute"], "")
                except (IndexError, ValueError):
                    source_class = "unparsed_source_class"
                unresolved[source_class] += 1
                unresolved_families[source_class + ("/" + source_family if source_family not in ("", ".") else "")] += 1
        if sum(unresolved.values()) != counts["rejected_unresolved_class"]:
            raise ValueError("Unresolved-class QC differs from rejection records for " + genome["id"])
    return {"qc_path": str(qc_path), "retained_annotation_fragments": counts.get("retained_fragments", 0),
        "excluded_non_TE_fragments": counts.get("rejected_excluded_non_te", 0),
        "excluded_unresolved_class_fragments": counts.get("rejected_unresolved_class", 0),
        "excluded_feature_type_rows": counts.get("rejected_excluded_feature_type", 0),
        "retained_Unknown_class_fragments": counts.get("unknown_class_fragments", qc.get("classes", {}).get("Unknown", 0)),
        "excluded_unresolved_source_classes": dict(unresolved),
        "excluded_unresolved_source_class_families": dict(unresolved_families),
        "interpretation": "The analyzed class scope is explicit and limited. Excluded unresolved classifications can include real TE classes; this is not an exhaustive all-TE inventory."}


def optional_annotation_coverage(directory, genome, scope):
    path = directory / genome["id"] / "annotation_coverage.json"
    if not path.is_file():
        return None
    result = read_json(path)
    signature = result.get("signature", {})
    inputs = signature.get("inputs", [])
    required = {str((path.parent / name).resolve()) for name in ("repeats.bed", "lengths.tsv")}
    if result.get("status") != "completed" or result.get("schema_version") != 1 or {item["path"] for item in inputs} != required:
        return {"status": "incomplete", "reason": "Annotation coverage has invalid status or input provenance"}
    script = signature.get("script")
    if not script:
        return {"status": "incomplete", "reason": "Annotation coverage lacks helper provenance"}
    for record in inputs + [script]:
        item = Path(record["path"])
        if not item.is_file():
            return {"status": "incomplete", "reason": "Annotation coverage input or helper missing"}
        stat = item.stat()
        actual = dict(path=str(item.resolve()), size=stat.st_size, mtime_ns=stat.st_mtime_ns,
                      ctime_ns=stat.st_ctime_ns, device=stat.st_dev, inode=stat.st_ino,
                      sha256=file_sha256(item))
        if actual != record:
            return {"status": "incomplete", "reason": "Annotation coverage input or helper fingerprint/hash differs"}
    if scope is not None and result["overall"]["all"]["fragment_count"] != scope["retained_annotation_fragments"]:
        return {"status": "incomplete", "reason": "Annotation coverage fragment count differs from normalization QC"}
    return dict(status="completed", path=str(path), **{key: result[key] for key in ("overall", "per_contig", "interpretation", "signature")})


def collect(study_dir, status_file=None):
    study_dir = Path(study_dir)
    # Metadata manifests supply material identities even before execution begins.
    pairs = {}
    for path in sorted((study_dir / "metadata").glob("*_pair.json")):
        manifest = read_json(path)
        if "pair_id" in manifest and len(manifest.get("genomes", [])) == 2:
            pairs[manifest["pair_id"]] = {"manifest": manifest, "manifest_path": path, "directory": None}
    directories = {}
    for path in sorted((study_dir / "results").glob("*/manifest.json")):
        manifest = read_json(path)
        identifier = manifest["pair_id"]
        if identifier in directories:
            raise ValueError("Duplicate run directories for pair_id " + identifier)
        directories[identifier] = path.parent
        pairs[identifier] = {"manifest": manifest, "manifest_path": path, "directory": path.parent}
    superseded = []
    for identifier, entry in list(pairs.items()):
        manifest, path = entry["manifest"], entry["manifest_path"]
        origin = manifest.get("derived_from_manifest")
        corrected = [genome for genome in manifest["genomes"] if genome.get("repeat_deduplication_provenance")]
        if not origin or not corrected:
            continue
        origin_path = resolve_reference(origin, path.parent)
        original = read_json(origin_path)
        previous = original["pair_id"]
        if previous == identifier or previous not in pairs:
            continue
        current_fastas = {str(resolve_reference(genome["fasta"], path.parent).resolve()) for genome in manifest["genomes"]}
        original_fastas = {str(resolve_reference(genome["fasta"], origin_path.parent).resolve()) for genome in original["genomes"]}
        if current_fastas != original_fastas or manifest.get("species") != original.get("species"):
            raise ValueError("Repeat correction cannot supersede a different material pair")
        for genome in corrected:
            record = read_json(resolve_reference(genome["repeat_deduplication_provenance"], path.parent))
            if record.get("status") != "passed":
                raise ValueError("Repeat correction lacks passed source audit")
        old = pairs.pop(previous)
        superseded.append({"pair_id": previous, "superseded_by": identifier,
            "manifest_path": str(old["manifest_path"]),
            "result_directory": str(old["directory"]) if old["directory"] else None,
            "reason": "Original source annotation duplicates; explicitly derived corrected manifest supersedes this run"})
    results, inputs = [], []
    for pair_id, entry in pairs.items():
        manifest, path, directory = entry["manifest"], entry["manifest_path"], entry["directory"]
        source, source_path = source_details(manifest, path)
        scientific = manifest.get("species", source.get("taxon", ""))
        key = species_key(scientific)
        if key is None:
            raise ValueError("Manifest needs a recognized species for " + pair_id)
        if directory is None:
            status, reason, completed_at = "pending", "已记录材料，尚无完成的整对分析", None
        else:
            status, reason, completed_at = completion_status(directory)
        genomes = []
        for genome in manifest["genomes"]:
            detail = assembly_details(genome, source)
            publications = genome.get("publications", detail.get("publications", []))
            if isinstance(publications, (str, dict)):
                publications = [publications]
            publication = genome.get("publication", detail.get("publication"))
            if publication:
                publications = list(publications) + [publication]
            if not publications and manifest.get("publication"):
                publications = [manifest["publication"]]
            if not publications and source.get("publication"):
                publications = [source["publication"]]
            material = genome.get("material", detail.get("strain", genome["id"]))
            material_details = material if isinstance(material, dict) else {}
            if material_details:
                material = material_details.get("Accession_Name", material_details.get("inbred", material_details.get("name", genome["id"])))
            assembly = genome.get("assembly", genome.get("assembly_accession", detail.get("assembly_accession", manifest.get("assembly_version", "not_recorded"))))
            if material_details.get("Assembly_ID"):
                assembly = "author Assembly_ID {}; {}".format(material_details["Assembly_ID"], assembly)
            gene_source = detail.get("files", {}).get("gene_gff3", {})
            recorded_gene_asset = "; ".join(str(gene_source[name]) for name in ("format", "filename") if gene_source.get(name))
            genomes.append({"id": genome["id"], "material": material, "material_details": material_details,
                "assembly": assembly,
                "annotation_release": genome.get("annotation_release", detail.get("annotation_release", manifest.get("gene_version", recorded_gene_asset or manifest.get("gene_provenance", "not_recorded")))),
                "repeat_format": genome.get("repeat_format", "not_recorded"), "publications": publications})
            if directory is not None:
                scope = normalization_scope(directory, genome)
                if scope is not None:
                    genomes[-1]["normalization_scope"] = scope
                coverage = optional_annotation_coverage(directory, genome, scope)
                if coverage is not None:
                    genomes[-1]["annotation_coverage"] = coverage
            inputs.extend(input_records(pair_id, genome, detail, path))
        result = {"pair_id": pair_id, "species_key": key, "species": scientific, "status": status,
                  "reason": reason, "completed_at": completed_at, "genomes": genomes,
                  "manifest_path": str(path.resolve()), "source_manifest": source_path,
                  "result_directory": str(directory.resolve()) if directory else None,
                  "limitations": manifest.get("limitations", [])}
        result["source_scope_and_policies"] = {name: manifest[name] for name in
            ("analysis_scope", "scope", "assembly_scope", "source_coverage_note", "te_feature_policy", "family_comparison_policy", "checksum_policy", "repeat_provenance", "repeat_scope", "release_note", "upstream_annotation_qc", "gene_provenance", "gene_conversion", "gene_interpretation")
            if name in manifest}
        result["source_scope_and_policies"].update({name: source[name] for name in
            ("publication_binding", "publication_limitations", "repeat_comparability", "repeat_methods", "selection") if name in source})
        if directory is not None:
            profile = optional_alignment_profile(directory, manifest)
            if profile is not None:
                result["alignment_profile"] = profile
        if status == "completed":
            evidence = read_json(directory / "evidence/summary.json")
            for side in ("genome1", "genome2"):
                values = evidence[side]
                if sum(values["categories"].values()) != values["candidate_fragments"]:
                    raise ValueError("Evidence category totals inconsistent in " + str(directory))
            result["evidence"] = evidence
            extra = optional_flank_validation(directory)
            if extra is not None:
                result["flank_validation"] = extra
            priorities = optional_priority_exports(directory, extra)
            if priorities is not None:
                result["priority_exports"] = priorities
            composition = optional_gap_composition(directory, manifest, priorities)
            if composition is not None:
                result["gap_composition"] = composition
        results.append(result)
    overrides = read_json(status_file) if status_file else {}
    species_status = []
    for key, scientific, chinese in SPECIES:
        matching = [pair for pair in results if pair["species_key"] == key]
        completed = any(pair["status"] == "completed" for pair in matching)
        status = ("completed" if completed else "blocked" if any(pair["status"] == "blocked" for pair in matching)
                  else "incomplete" if any(pair["status"] == "incomplete" for pair in matching) else "pending")
        reason = "; ".join(pair["reason"] for pair in matching) if matching else "尚未形成可执行材料清单或完成结果"
        override = overrides.get(key, {})
        if override and not completed:
            if override.get("status") not in {None, "pending", "blocked", "incomplete"}:
                raise ValueError("Status overrides cannot invent completed analyses")
            status, reason = override.get("status", status), override.get("reason", reason)
        species_status.append(dict(species_key=key, species=scientific, chinese=chinese, status=status, reason=reason))
    return {"generated_at": datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
        "species_status": species_status, "pairs": results, "inputs": inputs, "superseded_pairs": superseded,
        "interpretation": "Within-species assembly/annotation fragment candidates only. Optional reciprocal-flank support "
            "is conditional on reported mappings, not confirmed insertion/deletion events. Unknown repeat class is uncertain. "
            "Different annotation methods prevent biological comparison of candidate counts across species."}


SUMMARY_FIELDS = ["species", "pair_id", "genome_id", "material", "assembly", "status", "annotation_fragments",
    "aligned_union_fraction", "aligned_non_N_fraction", "raw_candidate_fragments", "anchored_gap_candidates",
    "unresolved_candidates", "N_or_edge_candidates", "Unknown_class_candidates", "anchored_Unknown_class_candidates",
    "optional_supported_gap_loci", "optional_supported_candidate_fragments", "excluded_non_TE_fragments",
    "excluded_unresolved_class_fragments", "retained_Unknown_class_fragments", "annotation_union_bases", "annotation_union_fraction",
    "annotation_known_class_union_fraction", "annotation_Unknown_union_fraction", "annotation_fragment_bases_sum",
    "gap_TE_union_below_10_percent", "gap_TE_union_below_50_percent", "gap_TE_union_below_80_percent",
    "gene_context_exact_gene_rows", "gene_context_omitted_other_gene_like_rows", "alignment_profile_id", "alignment_profile_status"]


def summary_rows(report):
    rows = []
    represented = set()
    for pair in report["pairs"]:
        represented.add(pair["species_key"])
        for number, genome in enumerate(pair["genomes"], 1):
            row = dict(species=pair["species"], pair_id=pair["pair_id"], genome_id=genome["id"],
                       material=genome["material"], assembly=genome["assembly"], status=pair["status"])
            profile = pair.get("alignment_profile", {})
            if profile:
                row.update(alignment_profile_id=profile["profile_id"], alignment_profile_status=profile["status"])
            scope = genome.get("normalization_scope", {})
            row.update({name: scope[name] for name in ("excluded_non_TE_fragments", "excluded_unresolved_class_fragments", "retained_Unknown_class_fragments") if name in scope})
            coverage = genome.get("annotation_coverage", {})
            if coverage.get("status") == "completed":
                overall = coverage["overall"]
                row.update(annotation_union_bases=overall["all"]["union_bases"], annotation_union_fraction=overall["all"]["union_fraction"],
                    annotation_known_class_union_fraction=overall["known_class"]["union_fraction"],
                    annotation_Unknown_union_fraction=overall["unknown_class"]["union_fraction"],
                    annotation_fragment_bases_sum=overall["all"]["fragment_bases_sum"])
            if pair["status"] == "completed":
                evidence = pair["evidence"]["genome{}".format(number)]
                coverage, categories = evidence["coverage"]["overall"], evidence["categories"]
                row.update(annotation_fragments=evidence["normalized_annotation_fragments"],
                    aligned_union_fraction=coverage["aligned_fraction"], aligned_non_N_fraction=coverage["aligned_non_N_fraction"],
                    raw_candidate_fragments=evidence["candidate_fragments"], anchored_gap_candidates=categories.get(CATEGORIES[0], 0),
                    unresolved_candidates=categories.get(CATEGORIES[1], 0), N_or_edge_candidates=categories.get(CATEGORIES[2], 0),
                    Unknown_class_candidates=evidence["candidate_fragments_per_class"].get("Unknown", 0),
                    anchored_Unknown_class_candidates=evidence["candidate_categories_per_class"].get(CATEGORIES[0], {}).get("Unknown", 0))
                validation = pair.get("flank_validation", {})
                if validation.get("status") == "completed":
                    counts = validation["per_genome"]["genome{}".format(number)]
                    row.update(optional_supported_gap_loci=counts.get("supported_gap_loci", 0),
                               optional_supported_candidate_fragments=counts.get("supported_candidate_fragments", 0))
                composition = pair.get("gap_composition", {})
                if composition.get("status") == "completed":
                    counts = composition["per_genome"][genome["id"]]
                    row.update({"gap_TE_union_below_%d_percent" % threshold: counts["retained_TE_union_below_%d_percent" % threshold] for threshold in (10, 50, 80)})
                    scope = composition["summary"]["gene_feature_scope"][genome["id"]]
                    row.update(gene_context_exact_gene_rows=scope["included_exact_gene_rows"],
                        gene_context_omitted_other_gene_like_rows=sum(scope["omitted_other_gene_like_features"].values()))
            rows.append(row)
    for species in report["species_status"]:
        if species["species_key"] not in represented:
            rows.append(dict(species=species["species"], status=species["status"]))
    return rows


def write_tsv(path, fields, rows):
    with path.open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n", extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def format_publication(publication):
    if isinstance(publication, str):
        return publication
    title = publication.get("title", "文献")
    doi = publication.get("doi")
    url = "https://doi.org/" + doi if doi else publication.get("url", "")
    year = str(publication.get("year", ""))
    details = [str(publication[name]) for name in ("first_author", "journal") if publication.get(name)]
    if publication.get("first_online"):
        details.append("在线 " + publication["first_online"])
    if publication.get("journal_collection_date"):
        details.append("卷期 " + publication["journal_collection_date"])
    return "{}{}{}{}".format(title, "（" + year + "）" if year else "", "；" + "；".join(details) if details else "", " " + url if url else "")


def markdown_cell(value):
    return str(value).replace("|", "\\|").replace("\n", " ")


def markdown_local_link(path, output):
    """Render a local path relative to the Markdown directory, without changing provenance."""
    relative = os.path.relpath(Path(path).resolve(), Path(output).resolve())
    return quote(Path(relative).as_posix(), safe="/")


def write_markdown(report, output):
    lines = ["**TEvoX 同种不同材料比较报告**", "", "生成时间：{}（北京时间）。".format(report["generated_at"][:19].replace("T", " ")),
        "", "差异候选只纳入具有有效流程完成标记的实际结果；准备完成的材料可单独列出经输入校验的注释覆盖率。数值表示重复注释片段，不能直接解释为完整 TE 插入/缺失事件。", "",
        "| 物种 | 状态 | 说明 |", "| --- | --- | --- |"]
    labels = {"completed": "已完成", "pending": "待完成", "blocked": "受阻", "incomplete": "结果待复核"}
    for species in report["species_status"]:
        lines.append("| {} | {} | {} |".format(species["chinese"], labels[species["status"]], markdown_cell(species["reason"])))
    for previous in report.get("superseded_pairs", []):
        lines += ["", "源注释重复纠正：`{}` 已由 `{}` 替代；旧流程结果仅作为审计记录，不纳入当前生物学计数。".format(
            previous["pair_id"], previous["superseded_by"])]
    for pair in report["pairs"]:
        lines += ["", "**{}：{}**".format(pair["species"], pair["pair_id"]), ""]
        for name, value in pair.get("source_scope_and_policies", {}).items():
            lines.append("{}：{}".format(name, markdown_cell(value)))
        if pair.get("source_scope_and_policies"):
            lines.append("")
        for limitation in pair.get("limitations", []):
            lines.append("材料限制：" + str(limitation))
        if pair.get("limitations"):
            lines.append("")
        for genome in pair["genomes"]:
            lines.append("- {}：组装 `{}`；基因注释来源/版本 `{}`；重复注释输入 `{}`。".format(
                genome["material"], genome["assembly"], genome["annotation_release"], genome["repeat_format"]))
            for publication in genome["publications"]:
                lines.append("  文献：" + format_publication(publication))
            if not genome["publications"]:
                lines.append("  文献证据尚未写入运行清单或来源清单，不能据此认定为最早发表材料。")
            scope = genome.get("normalization_scope")
            if scope:
                lines.append("  注释纳入范围：保留 {:,} 个片段；按预设非 TE 类排除 {:,} 个，因源分类未映射排除 {:,} 个，保留 Unknown 类 {:,} 个。另按特征类型排除 {:,} 行。".format(
                    scope["retained_annotation_fragments"], scope["excluded_non_TE_fragments"], scope["excluded_unresolved_class_fragments"],
                    scope["retained_Unknown_class_fragments"], scope["excluded_feature_type_rows"]))
                if scope["excluded_unresolved_class_fragments"]:
                    examples = sorted(scope["excluded_unresolved_source_class_families"].items(), key=lambda item: (-item[1], item[0]))[:6]
                    lines.append("  未纳入源分类：{}。这可能包含真实 TE 类，不能将结果称为全部 TE 的完整清单。".format(
                        "；".join("{}={:,}".format(name, count) for name, count in examples)))
            coverage = genome.get("annotation_coverage", {})
            if coverage.get("status") == "completed":
                overall = coverage["overall"]
                lines.append("  所纳入注释的区间并集覆盖 {:,}/{:,} bp（{:.2%}，分母含所纳入序列中的 N 碱基）；片段长度直接相加为 {:,} bp。已知类并集覆盖 {:.2%}，Unknown 并集覆盖 {:.4%}；二者可能重叠，不能直接相加。这衡量当前注释覆盖范围，不等于独立测定的基因组真实 TE 含量。".format(
                    overall["all"]["union_bases"], overall["genome_bases"], overall["all"]["union_fraction"], overall["all"]["fragment_bases_sum"],
                    overall["known_class"]["union_fraction"], overall["unknown_class"]["union_fraction"]))
            elif coverage:
                lines.append("  注释覆盖率待复核：{}。".format(coverage.get("reason", "未完成")))
        profile = pair.get("alignment_profile", {})
        if profile.get("status") == "applied":
            lines += ["", "比对配置 `{}` 已核对完成标记、工具 SHA-256 和实际运行参数；完整输入 FASTA 与单一目标索引保留。追加参数：`{}`。该配置降低重复密集区域的比对敏感性，候选数量依赖配置；未比对 TE 不能据此判定真实缺失。完整执行参数和校验记录见 [配置描述]({}) 及汇总 JSON。".format(
                profile["profile_id"], " ".join(profile["declared_profile"]["overrides"]), markdown_local_link(profile["profile_path"], output))]
        elif profile:
            lines += ["", "比对配置 `{}` {}：{}。尚未将配置声明视为已用于完成的分析。".format(
                profile["profile_id"], "待完成核验" if profile["status"] == "pending" else "待复核", profile["reason"])]
        if pair["status"] != "completed":
            lines += ["", "当前状态：{}。{}。未填入生物学结果数值。".format(labels[pair["status"]], pair["reason"])]
            continue
        lines += ["", "| 材料 | 合格比对覆盖率 | 注释片段总数 | 原始候选片段 | 双侧比对缺口候选 | 未解析 | N/边界影响 |", "| --- | ---: | ---: | ---: | ---: | ---: | ---: |"]
        for number, genome in enumerate(pair["genomes"], 1):
            evidence = pair["evidence"]["genome{}".format(number)]
            counts = evidence["categories"]
            lines.append("| {} | {:.2%} | {:,} | {:,} | {:,} | {:,} | {:,} |".format(genome["material"],
                evidence["coverage"]["overall"]["aligned_fraction"], evidence["normalized_annotation_fragments"],
                evidence["candidate_fragments"], *(counts.get(category, 0) for category in CATEGORIES)))
        lines += ["", "覆盖率按每条序列上的合格比对区间取并集计算；分母为实际纳入 FASTA 的序列总长度，不包含未提供的序列。非 N 碱基覆盖率与逐序列统计保存在机器可读结果中。",
            "双侧比对缺口候选要求片段至少 80% 位于 I/D 缺口，双侧连续比对各至少 1 kb，MAPQ≥30、比对一致性≥95%、比对碱基≥10 kb。该初始分类仅依据原始组装比对；额外独立侧翼检查如已完成，结果另列于下。"]
        for number, genome in enumerate(pair["genomes"], 1):
            evidence = pair["evidence"]["genome{}".format(number)]
            unknown = evidence["candidate_fragments_per_class"].get("Unknown", 0)
            lines.append("{} 的 Unknown 类候选片段为 {:,} 条，仅保留为分类不确定记录，不作为已确认 TE 证据。".format(genome["material"], unknown))
        validation = pair.get("flank_validation", {})
        if validation.get("status") == "completed":
            lines += ["", "额外互惠侧翼检查已完成，原始 TEvoX 数值保持不变：",
                "", "| 材料 | 获侧翼支持的候选片段 | 对应不同缺口位点 | 多定位歧义片段 | 未通过片段 |", "| --- | ---: | ---: | ---: | ---: |"]
            for number, genome in enumerate(pair["genomes"], 1):
                counts = validation["per_genome"]["genome{}".format(number)]
                lines.append("| {} | {:,} | {:,} | {:,} | {:,} |".format(genome["material"],
                    counts.get("supported_candidate_fragments", 0), counts.get("supported_gap_loci", 0),
                    counts.get("ambiguous_candidate_fragments", 0), counts.get("failed_candidate_fragments", 0)))
            lines += ["", "这里的唯一互惠支持限定于 minimap2 返回的命中、既定阈值和最多 20 个次级命中；到达报告上限的位点归为歧义。允许目标端点 50 bp 容差。多个注释片段可属于同一缺口位点，二者均不等同于已确认 TE 插入事件。"]
        elif validation:
            lines += ["", "额外侧翼检查结果待复核：{}。".format(validation.get("reason", "未完成"))]
        priorities = pair.get("priority_exports", {})
        if priorities.get("status") == "completed":
            lines += ["", "带基因邻近信息的侧翼支持候选见 [片段清单]({})、[去重缺口位点清单]({})。收录所有通过当前侧翼条件的已知 TE 类候选，不做因果排序；位点表的基因距离来自贡献注释片段，而非整个缺口。".format(
                markdown_local_link(priorities["candidates_path"], output), markdown_local_link(priorities["loci_path"], output))]
        elif priorities:
            lines += ["", "候选基因邻近清单待复核：{}。".format(priorities.get("reason", "未完成"))]
        composition = pair.get("gap_composition", {})
        if composition.get("status") == "completed":
            lines += ["", "缺口组成补充审计按缺口内所有纳入 TE 注释的区间并集计算，重叠片段仅计一次；各阈值为累计计数。初始 80% 条件的分母是 TE 片段长度，不是缺口长度。带 TE 片段的结构差异候选不一定由完整 TE 插入解释。",
                "", "| 材料 | 侧翼支持缺口 | TE 覆盖缺口 <10% | <50% | <80% |", "| --- | ---: | ---: | ---: | ---: |"]
            for genome in pair["genomes"]:
                counts = composition["per_genome"][genome["id"]]
                lines.append("| {} | {:,} | {:,} | {:,} | {:,} |".format(genome["material"], counts["supported_gap_loci"],
                    *(counts["retained_TE_union_below_%d_percent" % threshold] for threshold in (10, 50, 80))))
            lines.append("")
            for genome in pair["genomes"]:
                scope = composition["summary"]["gene_feature_scope"][genome["id"]]
                omitted = scope["omitted_other_gene_like_features"]
                details = "；".join("{}={:,}".format(name, count) for name,count in sorted(omitted.items())) or "无其他此类特征行"
                lines.append("{} 的邻近基因分析只纳入源 GFF 特征类型严格为 `gene` 的 {:,} 行；未纳入的其他基因类特征：{}。全部未纳入特征类型及行数见审计 JSON；没有用其他特征类型补充非编码基因或假基因。".format(
                    genome["material"], scope["included_exact_gene_rows"], details))
            coordinates = composition["summary"]["exact_coordinate_audit"]
            lines += ["", "精确坐标重复审计：同侧相同缺口区间 {:,} 组（其中不同 alignment ID 为 {:,} 组）；相同对侧空位点 {:,} 组；相同配对区间 {:,} 组；两侧互相对应到缺口精确边界 {:,} 对。此检查没有聚类结构事件，零精确重复也不保证所有位点代表独立事件。".format(
                coordinates["source_interval_exact_duplicate_groups"], coordinates["source_interval_duplicates_with_different_alignment_ids"],
                coordinates["opposite_empty_point_exact_duplicate_groups"], coordinates["normalized_paired_interval_exact_duplicate_groups"],
                len(coordinates["cross_side_mutual_exact_gap_boundary_matches"])),
                "缺口组成与支持片段覆盖详见 [逐位点 TSV]({})、[审计 JSON]({})。".format(markdown_local_link(composition["table_path"], output), markdown_local_link(composition["summary_path"], output))]
        elif composition:
            lines += ["", "缺口组成补充审计待复核：{}。".format(composition.get("reason", "未完成"))]
    lines += ["", "数据下载地址、完整 SHA-256/MD5、来源校验记录见 [study_inputs.tsv](study_inputs.tsv)；汇总表见 [study_summary.tsv](study_summary.tsv)，完整结果见 [study_summary.json](study_summary.json)。",
        "各类及家族的注释分母与候选计数见 [study_classes.tsv](study_classes.tsv)、[study_families.tsv](study_families.tsv)。",
        "", "![Within-pair candidate and coverage diagnostics](study_diagnostics.png)", "",
        "同种不同材料之间的组装质量、重复库和注释方法差异可产生候选差异；不同物种之间不比较这些候选数量来推断 TE 活性。注释碎片未重建为完整元件，基因邻近关系不代表表达或因果效应。即使通过有限搜索下的互惠侧翼检查，结果仍为候选支持，不是实验确认的真实存在/缺失，也不推断进化获得/丢失方向。"]
    (output / "study_report.md").write_text("\n".join(lines) + "\n")


def make_figure(report, output):
    cache = output / ".plot-cache"
    cache.mkdir(exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", str(cache / "matplotlib"))
    os.environ.setdefault("XDG_CACHE_HOME", str(cache))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.ticker import MaxNLocator, StrMethodFormatter
    panels, pending = [], []
    for species in report["species_status"]:
        completed = [pair for pair in report["pairs"] if pair["species_key"] == species["species_key"] and pair["status"] == "completed"]
        panels.extend((species, pair) for pair in completed)
        if not completed:
            pending.append(species)
    if pending:
        panels.append((None, None))
    figure, axes = plt.subplots(len(panels), 2, figsize=(13, max(4, 2.7 * len(panels))), squeeze=False)
    colors = ["#2A7F62", "#667085", "#D18C36"]
    labels = ["Anchored gap candidate", "Unresolved alignment", "N / contig edge"]
    for index, (species, pair) in enumerate(panels):
        left, right = axes[index]
        if pair is None:
            for axis in (left, right):
                axis.axis("off")
            left.text(0, 0.9, "No completed analysis:", fontsize=12, weight="bold", transform=left.transAxes)
            left.text(0, 0.72, "\n".join(species["species"] + ": " + species["status"] for species in pending),
                      fontsize=10, va="top", linespacing=1.5, transform=left.transAxes)
            continue
        names = []
        for genome in pair["genomes"]:
            name = str(genome["material"])
            if (pair["species_key"] == "human" and genome["id"] == "hg002_mat"
                    and name == "HG002/NA24385/GM24385, maternal haplotype"):
                name = "HG002 maternal"
            names.append(name)
        positions, offsets = [1, 0], [0, 0]
        for category, color, label in zip(CATEGORIES, colors, labels):
            values = [pair["evidence"]["genome{}".format(side)]["categories"].get(category, 0) for side in (1, 2)]
            left.barh(positions, values, left=offsets, height=0.58, color=color, label=label)
            offsets = [a + b for a, b in zip(offsets, values)]
        left.set_yticks(positions, names)
        left.set_title(species["species"] + " — candidate fragments", loc="left", fontsize=11)
        left.set_xlabel("Annotation fragments (within pair only)")
        left.xaxis.set_major_locator(MaxNLocator(nbins=4, integer=True))
        left.xaxis.set_major_formatter(StrMethodFormatter("{x:,.0f}"))
        left.set_xlim(0, max(offsets + [1]) * 1.08)
        coverages = [100 * pair["evidence"]["genome{}".format(side)]["coverage"]["overall"]["aligned_fraction"] for side in (1, 2)]
        right.barh(positions, coverages, height=0.58, color="#466E9B")
        right.set_yticks(positions, names)
        right.set_xlim(0, 105)
        right.set_xticks([0, 25, 50, 75, 100])
        right.set_xlabel("Qualified alignment union / assembly (%)")
        for position, value in zip(positions, coverages):
            right.text(min(value + 1, 100), position, "{:.1f}%".format(value), va="center", fontsize=9)
        right.set_title("Assembly coverage", loc="left", fontsize=11)
        for axis in (left, right):
            axis.spines[["top", "right"]].set_visible(False)
    handles = [plt.Rectangle((0, 0), 1, 1, color=color) for color in colors]
    figure.legend(handles, labels, loc="upper center", ncol=3, bbox_to_anchor=(0.5, 0.968), frameon=False)
    figure.suptitle("TEvoX within-pair diagnostics — candidate fragments, not validated TE events", y=0.995, fontsize=14)
    figure.text(0.5, 0.008, "Unknown repeat classes remain uncertain. Annotation methods prevent biological count comparisons across species.",
                ha="center", fontsize=9)
    figure.tight_layout(rect=(0, 0.025, 1, 0.94))
    figure.savefig(output / "study_diagnostics.png", dpi=180)
    figure.savefig(output / "study_diagnostics.svg")
    plt.close(figure)


def write_report(report, output_dir):
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    (output / "study_summary.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    write_tsv(output / "study_summary.tsv", SUMMARY_FIELDS, summary_rows(report))
    input_fields = ["pair_id", "genome_id", "kind", "path", "url", "bytes", "sha256", "md5", "verification", "checksum_source", "provenance_record", "local_file_present", "derived_from"]
    write_tsv(output / "study_inputs.tsv", input_fields, report["inputs"])
    classes, families = [], []
    for pair in report["pairs"]:
        if pair["status"] != "completed":
            continue
        for number, genome in enumerate(pair["genomes"], 1):
            evidence = pair["evidence"]["genome{}".format(number)]
            for name, count in evidence["annotation_fragments_per_class"].items():
                row = dict(pair_id=pair["pair_id"], genome_id=genome["id"], canonical_class=name,
                    annotation_fragments=count, candidate_fragments=evidence["candidate_fragments_per_class"].get(name, 0))
                row.update({category: evidence["candidate_categories_per_class"].get(category, {}).get(name, 0) for category in CATEGORIES})
                coverage = genome.get("annotation_coverage", {})
                if coverage.get("status") == "completed":
                    values = coverage["overall"]["classes"].get(name, {})
                    row.update(annotation_union_bases=values.get("union_bases", 0), annotation_union_fraction=values.get("union_fraction", 0))
                classes.append(row)
            for name, count in evidence["annotation_fragments_per_class_family"].items():
                families.append(dict(pair_id=pair["pair_id"], genome_id=genome["id"], class_family=name,
                    annotation_fragments=count, candidate_fragments=evidence["candidate_fragments_per_class_family"].get(name, 0)))
    write_tsv(output / "study_classes.tsv", ["pair_id", "genome_id", "canonical_class", "annotation_fragments", "candidate_fragments"] + CATEGORIES + ["annotation_union_bases", "annotation_union_fraction"], classes)
    write_tsv(output / "study_families.tsv", ["pair_id", "genome_id", "class_family", "annotation_fragments", "candidate_fragments"], families)
    make_figure(report, output)
    write_markdown(report, output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--status-file", help="Optional {human/mouse/rat/arabidopsis/maize: {status,reason}}; cannot mark completion")
    args = parser.parse_args()
    try:
        report = collect(args.study_dir, args.status_file)
        write_report(report, args.output_dir)
    except (OSError, ValueError, KeyError) as error:
        parser.exit(1, "Error: {}\n".format(error))
    print(str(Path(args.output_dir) / "study_report.md"))


if __name__ == "__main__":
    main()
