#!/usr/bin/env python3
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

import annotation_coverage as coverage


class AnnotationUnionCoverage(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="tevox-annotation-coverage-unit-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.lengths = self.root / "lengths.tsv"
        self.lengths.write_text("chr1\t30\nchr2\t20\nempty_contig\t10\n")
        self.bed = self.root / "repeats.bed"

    def write_bed(self, rows):
        self.bed.write_text("".join("%s\t%d\t%d\tF%d\t0\t%s\t%s\n" % (chrom, start, end, number, strand, category)
            for number, (chrom, start, end, strand, category) in enumerate(rows)))

    def compute(self):
        return coverage.coverage(self.bed, self.lengths, str(self.root))

    def test_overlapping_nested_bookended_duplicate_and_class_unions(self):
        rows = [("chr1", 0, 10, "+", "DNA"), ("chr1", 5, 15, "+", "LTR"),
            ("chr1", 8, 9, "-", "DNA"), ("chr1", 15, 20, "+", "Unknown"),
            ("chr1", 25, 30, "+", "DNA"), ("chr1", 7, 8, "+", "Unknown"),
            ("chr2", 0, 5, "-", "Unknown"), ("chr2", 5, 10, "+", "DNA"),
            ("chr2", 10, 15, "-", "Unknown"), ("chr2", 5, 10, "-", "DNA")]
        random.Random(13).shuffle(rows)
        self.write_bed(rows)
        result = self.compute()
        total = result["overall"]
        self.assertEqual(total["genome_bases"], 60)
        self.assertEqual(total["all"]["fragment_count"], 10)
        self.assertEqual(total["all"]["fragment_bases_sum"], 52)
        self.assertEqual(total["all"]["union_bases"], 40)
        self.assertEqual(total["all"]["summed_minus_union_bases"], 12)
        self.assertAlmostEqual(total["all"]["union_fraction"], 2 / 3)
        self.assertEqual(total["known_class"]["union_bases"], 25)
        self.assertEqual(total["unknown_class"]["union_bases"], 16)
        self.assertEqual(total["classes"]["DNA"]["union_bases"], 20)
        self.assertEqual(total["classes"]["LTR"]["union_bases"], 10)
        self.assertEqual(result["per_contig"]["empty_contig"]["all"]["union_fraction"], 0)
        self.assertEqual(result["signature"]["inputs"][0]["sha256"], coverage.sha256(self.bed))
        self.assertFalse(list(self.root.glob("tevox-annotation-coverage-*")))

    def test_random_intervals_match_independent_per_base_oracle(self):
        rng = random.Random(73)
        rows, oracle = [], {}
        for _ in range(1000):
            chrom, length = rng.choice([("chr1", 30), ("chr2", 20)])
            start = rng.randrange(length)
            end = rng.randrange(start + 1, length + 1)
            category = rng.choice(["DNA", "LTR", "Unknown"])
            rows.append((chrom, start, end, rng.choice(["+", "-"]), category))
            oracle.setdefault((chrom, category), set()).update(range(start, end))
        rng.shuffle(rows)
        self.write_bed(rows)
        result = self.compute()
        for chrom in ("chr1", "chr2", "empty_contig"):
            actual = result["per_contig"][chrom]
            by_class = [oracle.get((chrom, name), set()) for name in ("DNA", "LTR", "Unknown")]
            self.assertEqual(actual["all"]["union_bases"], len(set().union(*by_class)))
            self.assertEqual(actual["known_class"]["union_bases"], len(by_class[0] | by_class[1]))
            self.assertEqual(actual["unknown_class"]["union_bases"], len(by_class[2]))
        self.assertEqual(result["overall"]["all"]["fragment_count"], len(rows))

    def test_empty_annotation_has_real_zero_coverage(self):
        self.write_bed([])
        result = self.compute()
        self.assertEqual(result["overall"]["all"]["union_bases"], 0)
        self.assertEqual(result["overall"]["all"]["union_fraction"], 0)
        self.assertEqual(result["overall"]["classes"], {})

    def test_actual_fasta_qc_length_schema(self):
        self.lengths.write_text("#sequence_id\tlength\tn_count\tlowercase_count\tselected\nchr1\t30\t0\t0\t1\n")
        self.write_bed([("chr1", 0, 15, "+", "DNA")])
        result = self.compute()
        self.assertEqual(result["overall"]["genome_bases"], 30)
        self.assertEqual(result["overall"]["all"]["union_fraction"], 0.5)

    def test_invalid_coordinates_and_contigs_rejected(self):
        for record in [("chr1", -1, 2, "+", "DNA"), ("chr1", 0, 31, "+", "DNA"),
                       ("chr1", 1, 1, "+", "DNA"), ("missing", 0, 1, "+", "DNA")]:
            with self.subTest(record=record):
                self.write_bed([record])
                with self.assertRaisesRegex(ValueError, "out-of-bounds"):
                    self.compute()
                self.assertFalse(list(self.root.glob("tevox-annotation-coverage-*")))

    def test_changed_inputs_cannot_receive_successful_provenance(self):
        self.write_bed([("chr1", 0, 10, "+", "DNA")])
        original = coverage.build_database
        def altered(*args):
            digest = original(*args)
            with self.bed.open("a") as handle:
                handle.write("# changed during processing\n")
            return digest
        with mock.patch.object(coverage, "build_database", side_effect=altered):
            with self.assertRaisesRegex(ValueError, "inputs changed"):
                self.compute()

    def test_cli_atomic_output_and_input_collision(self):
        self.write_bed([("chr1", 0, 10, "+", "DNA")])
        output = self.root / "coverage.json"
        command = [sys.executable, coverage.__file__, "--bed", str(self.bed), "--lengths", str(self.lengths), "--output"]
        result = subprocess.run(command + [str(output)], text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(output.read_text())["overall"]["all"]["union_bases"], 10)
        before = output.read_bytes()
        self.write_bed([("chr1", 0, 31, "+", "DNA")])
        self.assertNotEqual(subprocess.run(command + [str(output)], capture_output=True).returncode, 0)
        self.assertEqual(output.read_bytes(), before)
        before = self.bed.read_bytes()
        self.assertNotEqual(subprocess.run(command + [str(self.bed)], capture_output=True).returncode, 0)
        self.assertEqual(self.bed.read_bytes(), before)


if __name__ == "__main__":
    unittest.main(verbosity=2)
