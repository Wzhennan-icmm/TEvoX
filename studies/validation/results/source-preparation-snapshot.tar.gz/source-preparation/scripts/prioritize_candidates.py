#!/usr/bin/env python3
"""Export all reciprocal-flank-supported known-class annotation candidates.

Priority is an evidence filter, not an arbitrary ranking or top-N selection.
Loci are deduplicated alignment gaps, not reconstructed TE insertion events.
Gene overlap/proximity describes annotation context, not expression or causality.
"""
import argparse
import collections
import csv
import json
import os
from pathlib import Path
import tempfile

from run_pair import atomic_json, fingerprint, now, read_json

SUPPORTED = 'reciprocal_unique_flank_supported_candidate'
KNOWN_CLASSES = {'LINE', 'SINE', 'LTR', 'DNA', 'RC'}
LOCUS_KEYS = ['genome','alignment_id','source_chrom','source_gap_start0','source_gap_end0',
              'opposite_chrom','opposite_empty_site0','alignment_strand']
GENE_FIELDS = ['overlap_gene_ids_json','overlap_gene_names_json','nearest_gene_ids_json',
               'nearest_gene_names_json','nearest_gene_body_distance_bp','gene_annotation_status']
CONTEXT_FIELDS = ['pair_id','genome','genome_id','material','assembly','locus_id','alignment_id',
                  'source_gap_start0','source_gap_end0','opposite_genome_id','opposite_material',
                  'opposite_chrom','opposite_empty_site0','alignment_strand']
CANDIDATE_FIELDS = CONTEXT_FIELDS + ['fragment_id','chrom','start1','end1','strand','repeat_name',
                   'canonical_class','repeat_family','classification_note'] + GENE_FIELDS + ['evidence_level']
LOCUS_FIELDS = CONTEXT_FIELDS + ['source_chrom','fragment_count','fragment_ids_json','repeat_names_json',
               'repeat_classes_json','repeat_class_family_pairs_json','overlap_gene_ids_json',
               'overlap_gene_names_json','nearest_gene_ids_json','nearest_gene_names_json',
               'minimum_fragment_nearest_gene_distance_bp','fragment_gene_context_json','evidence_level']



def genome_labels(genome, manifest):
    material = genome.get('material', genome['id'])
    if isinstance(material, dict):
        material_name = material.get('Accession_Name') or genome['id']
        author_id = material.get('Assembly_ID')
    else:
        material_name, author_id = material or genome['id'], None
    assembly = genome.get('assembly')
    if not assembly or assembly == '.':
        version = genome.get('assembly_version') or manifest.get('assembly_version')
        author_id = genome.get('authorAssembly_ID', author_id)
        parts = [str(version)] if version else []
        if author_id is not None:
            parts.append('author Assembly_ID=' + str(author_id))
        assembly = '; '.join(parts) or '.'
    return str(material_name), str(assembly)


def checked_record(record, content_hash):
    if fingerprint(record['path'], content_hash) != record:
        raise ValueError('Stale fingerprint/hash: ' + record['path'])


def validated_inputs(results):
    finish_path, done_path = results/'finish.done.json', results/'flank_validation/done.json'
    if not finish_path.is_file() or not done_path.is_file():
        raise ValueError('Completed pair and reciprocal flank validation markers are required')
    finish, done = read_json(finish_path), read_json(done_path)
    if finish.get('status') != 'completed' or done.get('status') != 'completed':
        raise ValueError('Analysis/flank validation is incomplete')
    if not finish.get('outputs') or not done.get('outputs'):
        raise ValueError('Completion markers must enumerate verified outputs')
    for record in finish['outputs']:
        checked_record(record, False)
    for record in done['outputs']:
        checked_record(record, True)
    signature = done.get('signature', {})
    if not signature.get('inputs') or not signature.get('scripts') or not signature.get('tool'):
        raise ValueError('Missing flank input/script/tool signature')
    for record in signature['inputs'] + signature['scripts'] + [signature['tool']]:
        checked_record(record, True)
    manifest = read_json(results/'manifest.json')
    if finish.get('signature', {}).get('manifest') != manifest:
        raise ValueError('Pair manifest differs from completed analysis')
    if len(manifest.get('genomes', [])) != 2:
        raise ValueError('Exactly two genomes are required')
    expected_inputs = [results/'manifest.json', finish_path] + [results/'evidence'/('genome%d.candidate_evidence.tsv'%n) for n in (1,2)]
    checked_inputs = {Path(item['path']).resolve() for item in signature['inputs']}
    if not {p.resolve() for p in expected_inputs} <= checked_inputs:
        raise ValueError('Flank signature does not cover current manifest/evidence/finish marker')
    loci_path = results/'flank_validation/loci.tsv'
    if loci_path.resolve() not in {Path(item['path']).resolve() for item in done['outputs']}:
        raise ValueError('Flank marker does not cover locus table')
    gene_paths = [results/g['id']/'candidate_genes.tsv' for g in manifest['genomes']]
    if not {p.resolve() for p in gene_paths} <= {Path(item['path']).resolve() for item in finish['outputs']}:
        raise ValueError('Gene context is not covered by the finished analysis marker')
    return manifest, expected_inputs + [done_path, loci_path] + gene_paths


def arrays(row, prefix):
    identifiers = json.loads(row[prefix+'_gene_ids_json'])
    names = json.loads(row[prefix+'_gene_names_json'])
    if not isinstance(identifiers,list) or not isinstance(names,list) or len(identifiers)!=len(names):
        raise ValueError('Invalid gene ID/name arrays')
    if not all(isinstance(value,str) for value in identifiers+names):
        raise ValueError('Gene IDs/names must be strings')
    return list(zip(identifiers,names))


def build_tables(manifest, locus_rows, evidence_rows, gene_rows):
    counts=collections.Counter()
    grouped={}
    for row in locus_rows:
        if row['status'] != SUPPORTED:
            continue
        key=tuple(row[k] for k in LOCUS_KEYS)
        if row['genome'] not in {'1','2'}:
            raise ValueError('Invalid genome side in locus table')
        fragments=json.loads(row['fragment_ids_json'])
        if not isinstance(fragments,list) or not all(isinstance(x,str) for x in fragments):
            raise ValueError('Fragment IDs must be a JSON string list')
        if key not in grouped:
            grouped[key]=dict(row=row,fragments=set())
        elif grouped[key]['row']['locus_id']!=row['locus_id']:
            raise ValueError('Conflicting IDs for the same alignment-gap locus')
        counts['duplicate_fragment_references_ignored']+=len(fragments)-len(set(fragments)-grouped[key]['fragments'])
        grouped[key]['fragments'].update(fragments)
    wanted={(row['row']['genome'],fid) for row in grouped.values() for fid in row['fragments']}
    evidence,genes={},{}
    for source,target,label in [(evidence_rows,evidence,'evidence'),(gene_rows,genes,'gene context')]:
        for side,row in source:
            key=(str(side),row['fragment_id'])
            if key not in wanted:
                continue
            if key in target:
                raise ValueError('Duplicate fragment in '+label+': '+str(key))
            target[key]=row
    if wanted-evidence.keys():
        raise ValueError('Supported fragments missing evidence')
    known_wanted={key for key in wanted if evidence[key]['canonical_class']!='Unknown'}
    if known_wanted-genes.keys():
        raise ValueError('Supported fragments missing gene context')
    candidate_output,locus_output=[],[]
    assigned_fragments=set()
    overlap_gene_keys=set()
    for key,group in sorted(grouped.items()):
        locus=group['row'];side=int(locus['genome'])-1
        genome,other=manifest['genomes'][side],manifest['genomes'][1-side]
        context={field:locus[field] for field in ['genome','locus_id','alignment_id','source_gap_start0',
                  'source_gap_end0','opposite_chrom','opposite_empty_site0','alignment_strand']}
        material_name,assembly_label=genome_labels(genome,manifest)
        opposite_material,_=genome_labels(other,manifest)
        context.update(pair_id=manifest['pair_id'],genome_id=genome['id'],material=material_name,
            assembly=assembly_label,opposite_genome_id=other['id'],opposite_material=opposite_material)
        fragments=[];names=set();classes=set();families=set();gene_context={};overlap=set();nearest=set();distances=[]
        for fid in sorted(group['fragments']):
            identity=(locus['genome'],fid);evidence_row=evidence[identity]
            if evidence_row['canonical_class']=='Unknown':
                counts['excluded_unknown_class_fragments']+=1
                continue
            gene=genes[identity]
            if evidence_row['canonical_class'] not in KNOWN_CLASSES:
                raise ValueError('Unrecognized canonical repeat class')
            if identity in assigned_fragments:
                raise ValueError('Fragment belongs to multiple distinct supported loci')
            for efield,lfield in [('selected_alignment_id','alignment_id'),('chrom','source_chrom'),('gap_start0','source_gap_start0'),
                    ('gap_end0','source_gap_end0'),('opposite_chrom','opposite_chrom'),('opposite_empty_site0','opposite_empty_site0'),('alignment_strand','alignment_strand')]:
                if evidence_row[efield]!=locus[lfield]:
                    raise ValueError('Locus/evidence disagreement for '+fid)
            if evidence_row['category']!='anchored_gap_candidate':
                raise ValueError('Supported locus references a non-anchored fragment')
            for field in ['chrom','start1','end1','strand','canonical_class','repeat_family','repeat_name']:
                if evidence_row[field]!=gene[field]:
                    raise ValueError('Evidence/gene context disagreement for '+fid)
            overlap_pairs=arrays(gene,'overlap')
            overlap.update(overlap_pairs);nearest.update(arrays(gene,'nearest'))
            if overlap_pairs:
                counts['genome%d_candidate_fragments_overlapping_gene'%(side+1)]+=1
                overlap_gene_keys.update((side,gene_id) for gene_id,_ in overlap_pairs)
            distance=gene['nearest_gene_body_distance_bp']
            if distance!='.':
                if int(distance)<0:raise ValueError('Negative gene distance')
                distances.append(int(distance))
            assigned_fragments.add(identity);fragments.append(fid)
            names.add(evidence_row['repeat_name']);classes.add(evidence_row['canonical_class'])
            families.add((evidence_row['canonical_class'],evidence_row['repeat_family']))
            gene_context[fid]={field:(json.loads(gene[field]) if field.endswith('_json') else gene[field]) for field in GENE_FIELDS}
            row=dict(context,fragment_id=fid,evidence_level=SUPPORTED)
            row.update({field:evidence_row[field] for field in ['chrom','start1','end1','strand','repeat_name','canonical_class','repeat_family','classification_note']})
            row.update({field:gene[field] for field in GENE_FIELDS})
            candidate_output.append(row)
        if not fragments:
            counts['excluded_loci_without_known_class_fragments']+=1
            continue
        overlap,nearest=sorted(overlap),sorted(nearest)
        for pairs in (overlap,nearest):
            if len({gene_id for gene_id,_ in pairs})!=len(pairs):
                raise ValueError('Conflicting names for the same gene ID within a locus')
        row=dict(context,source_chrom=locus['source_chrom'],fragment_count=len(fragments),
            fragment_ids_json=json.dumps(fragments),repeat_names_json=json.dumps(sorted(names)),repeat_classes_json=json.dumps(sorted(classes)),
            repeat_class_family_pairs_json=json.dumps(sorted(families)),
            overlap_gene_ids_json=json.dumps([g[0] for g in overlap]),overlap_gene_names_json=json.dumps([g[1] for g in overlap]),
            nearest_gene_ids_json=json.dumps([g[0] for g in nearest]),nearest_gene_names_json=json.dumps([g[1] for g in nearest]),
            minimum_fragment_nearest_gene_distance_bp=min(distances) if distances else '.',
            fragment_gene_context_json=json.dumps(gene_context,sort_keys=True),evidence_level=SUPPORTED)
        locus_output.append(row)
        counts['genome%d_candidate_fragments'%(side+1)]+=len(fragments)
        counts['genome%d_alignment_gap_loci'%(side+1)]+=1
    counts['candidate_fragments']=len(candidate_output);counts['alignment_gap_loci']=len(locus_output)
    counts['overlap_gene_ids_distinct_within_genome']=len(overlap_gene_keys)
    for side in (0,1):
        counts['genome%d_distinct_overlap_gene_ids'%(side+1)]=sum(genome_side==side for genome_side,_ in overlap_gene_keys)
    return candidate_output,locus_output,dict(counts)


def iter_rows(path):
    with open(path) as handle:
        yield from csv.DictReader(handle,delimiter='\t')


def atomic_tsv(path, fields, rows):
    fd,name=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'w') as handle:
            writer=csv.DictWriter(handle,fieldnames=fields,delimiter='\t',lineterminator='\n')
            writer.writeheader();writer.writerows(rows)
        os.replace(name,path)
    finally:
        Path(name).unlink(missing_ok=True)


def export(args):
    results=Path(args.results).resolve(strict=True)
    manifest,inputs=validated_inputs(results)
    signature=dict(inputs=[fingerprint(path,True) for path in inputs],script=fingerprint(__file__,True))
    outputs=[results/'priority_candidates.tsv',results/'priority_loci.tsv']
    summary_path=results/'priority_summary.json'
    if any(path.is_symlink() for path in outputs+[summary_path]):
        raise ValueError('Priority output may not be a symlink')
    if summary_path.exists():
        existing=read_json(summary_path)
        if existing.get('signature')!=signature or any(fingerprint(record['path'],True)!=record for record in existing['outputs']):
            raise ValueError('Existing priority outputs are stale; preserve/archive before regeneration')
        return existing
    if any(path.exists() for path in outputs):
        raise ValueError('Existing priority tables have no matching provenance summary')
    evidence=((side,row) for side in (1,2) for row in iter_rows(results/'evidence'/('genome%d.candidate_evidence.tsv'%side)))
    genes=((side,row) for side,genome in enumerate(manifest['genomes'],1) for row in iter_rows(results/genome['id']/'candidate_genes.tsv'))
    candidates,loci,counts=build_tables(manifest,iter_rows(results/'flank_validation/loci.tsv'),evidence,genes)
    for path,fields,rows in [(outputs[0],CANDIDATE_FIELDS,candidates),(outputs[1],LOCUS_FIELDS,loci)]:
        atomic_tsv(path,fields,rows)
    for record in signature['inputs']+[signature['script']]:
        checked_record(record,True)
    summary=dict(pair_id=manifest['pair_id'],created_at=now(),counts=counts,signature=signature,
        outputs=[fingerprint(path,True) for path in outputs],
        selection='All reciprocal_unique_flank_supported_candidate fragments of known canonical TE class; no top-N or causal ranking.',
        interpretation='Locus counts are deduplicated alignment-gap loci, not confirmed TE insertions or reconstructed TE events. Gene unions describe contributing annotation fragments; distances refer to those fragments, not the entire gap. Flank uniqueness is conditional on reported minimap2 mappings and thresholds.')
    atomic_json(summary_path,summary)
    return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results',required=True)
    args=parser.parse_args()
    try: summary=export(args)
    except (OSError,ValueError,KeyError) as exc:parser.exit(2,'Error: %s\n'%exc)
    print(json.dumps(summary['counts'],sort_keys=True))


if __name__=='__main__':main()
