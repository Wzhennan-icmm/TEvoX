#!/usr/bin/env python3
import csv
import copy
import hashlib
import json
import os
import re
from pathlib import Path
import tempfile
import unittest
from urllib.parse import unquote, urlsplit

import study_report as reporter
import annotation_coverage


def fingerprint(path):
    stat = path.stat()
    return dict(path=str(path.resolve()), size=stat.st_size, mtime_ns=stat.st_mtime_ns,
                ctime_ns=stat.st_ctime_ns, device=stat.st_dev, inode=stat.st_ino)


def hashed_fingerprint(path):
    return dict(fingerprint(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest())


class ActualCompletionReporting(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix="tevox-report-unit-fixture-")
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.result = self.root / "results/rat"
        (self.result / "evidence").mkdir(parents=True)
        (self.root / "metadata").mkdir()
        self.manifest = {"pair_id": "test_fixture_rat", "species": "Rattus norvegicus", "genomes": [
            {"id": "fixture_a", "material": "Synthetic fixture A", "assembly": "TEST_A", "repeat_format": "te-bed"},
            {"id": "fixture_b", "material": "Synthetic fixture B", "assembly": "TEST_B", "repeat_format": "te-bed"}]}
        (self.result / "manifest.json").write_text(json.dumps(self.manifest))
        evidence = {"normalized_annotation_fragments": 100, "candidate_fragments": 10,
            "categories": {"anchored_gap_candidate": 3, "unresolved_outside_alignment": 5, "low_quality_N_or_contig_edge": 2},
            "coverage": {"overall": {"aligned_fraction": 0.8, "aligned_non_N_fraction": 0.82}},
            "annotation_fragments_per_class": {"LINE": 90, "Unknown": 10},
            "candidate_fragments_per_class": {"LINE": 8, "Unknown": 2},
            "candidate_categories_per_class": {"anchored_gap_candidate": {"LINE": 2, "Unknown": 1},
                "unresolved_outside_alignment": {"LINE": 4, "Unknown": 1}, "low_quality_N_or_contig_edge": {"LINE": 2}},
            "annotation_fragments_per_class_family": {"LINE/L1": 90, "Unknown/.": 10},
            "candidate_fragments_per_class_family": {"LINE/L1": 8, "Unknown/.": 2}}
        self.summary = self.result / "evidence/summary.json"
        self.summary.write_text(json.dumps({"genome1": evidence, "genome2": evidence}))

    def mark_complete(self):
        (self.result / "finish.done.json").write_text(json.dumps({"status": "completed", "outputs": [fingerprint(self.summary)],
                                                                 "signature": {"manifest": self.manifest},
                                                                 "completed_at": "2026-10-03T08:00:00+00:00"}))

    def test_summary_without_completion_marker_is_not_a_result(self):
        report = reporter.collect(self.root)
        self.assertNotIn("evidence", report["pairs"][0])
        self.assertEqual(report["pairs"][0]["status"], "pending")
        rows = reporter.summary_rows(report)
        self.assertNotIn("raw_candidate_fragments", rows[0])
        self.assertEqual(len(report["species_status"]), 5)

    def test_verified_completion_and_changed_output_detection(self):
        self.mark_complete()
        report = reporter.collect(self.root)
        self.assertEqual(report["pairs"][0]["status"], "completed")
        row = reporter.summary_rows(report)[0]
        self.assertEqual(row["raw_candidate_fragments"], 10)
        self.assertEqual(row["anchored_Unknown_class_candidates"], 1)
        self.summary.write_text(self.summary.read_text() + "\n")
        report = reporter.collect(self.root)
        self.assertEqual(report["pairs"][0]["status"], "incomplete")
        self.assertNotIn("evidence", report["pairs"][0])

    def test_blocked_status_is_explicit_and_overrides_cannot_claim_completion(self):
        (self.result / "run_commands.jsonl").write_text(json.dumps({"event": "phase_failed", "error": "verified fixture failure"}) + "\n")
        self.assertEqual(reporter.collect(self.root)["pairs"][0]["status"], "blocked")
        status = self.root / "status.json"
        status.write_text(json.dumps({"human": {"status": "completed", "reason": "invalid claim"}}))
        with self.assertRaisesRegex(ValueError, "cannot invent"):
            reporter.collect(self.root, status)

    def test_report_tables_and_exportable_figures(self):
        self.mark_complete()
        report = reporter.collect(self.root)
        output = self.root / "report"
        reporter.write_report(report, output)
        for name in ("study_summary.json", "study_summary.tsv", "study_inputs.tsv", "study_classes.tsv",
                     "study_families.tsv", "study_report.md", "study_diagnostics.png", "study_diagnostics.svg"):
            self.assertTrue((output / name).is_file(), name)
            self.assertGreater((output / name).stat().st_size, 0)
        with (output / "study_summary.tsv").open() as handle:
            rows = list(csv.DictReader(handle, delimiter="\t"))
        human = next(row for row in rows if row["species"] == "Homo sapiens")
        self.assertEqual(human["raw_candidate_fragments"], "")
        markdown = (output / "study_report.md").read_text()
        self.assertIn("Unknown", markdown)
        self.assertIn("不能直接解释", markdown)
        self.assertIn("Synthetic fixture A", markdown)

    def test_pair_level_publication_and_dictionary_material(self):
        self.manifest["assembly_version"] = "v2.1"
        self.manifest["gene_version"] = "genes_v05"
        self.manifest["publication"] = {"title": "Synthetic test publication", "year": 2025}
        self.manifest["genomes"][0]["material"] = {"Accession_Name": "Fixture accession", "Assembly_ID": 123}
        self.manifest["genomes"][0].pop("assembly")
        (self.result / "manifest.json").write_text(json.dumps(self.manifest))
        self.mark_complete()
        genome = reporter.collect(self.root)["pairs"][0]["genomes"][0]
        self.assertEqual(genome["material"], "Fixture accession")
        self.assertEqual(genome["assembly"], "author Assembly_ID 123; v2.1")
        self.assertEqual(genome["annotation_release"], "genes_v05")
        self.assertEqual(len(genome["publications"]), 1)

    def test_optional_validation_preserves_initial_counts_and_requires_hashes(self):
        self.mark_complete()
        folder = self.result / "flank_validation"
        folder.mkdir()
        (folder / "summary.json").write_text(json.dumps({"limitations": ["synthetic test"]}))
        (folder / "loci.tsv").write_text('genome\tstatus\tfragment_ids_json\n1\treciprocal_unique_flank_supported_candidate\t["a", "b"]\n')
        outputs = []
        for path in (folder / "summary.json", folder / "loci.tsv"):
            record = fingerprint(path)
            record["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
            outputs.append(record)
        marker = self.result / "finish.done.json"
        (folder / "done.json").write_text(json.dumps({"status": "completed", "outputs": outputs,
            "signature": {"inputs": [{"path": str(marker), "sha256": hashlib.sha256(marker.read_bytes()).hexdigest()}]}}))
        report = reporter.collect(self.root)
        row = reporter.summary_rows(report)[0]
        self.assertEqual(row["raw_candidate_fragments"], 10)
        self.assertEqual(row["optional_supported_candidate_fragments"], 2)
        self.assertEqual(row["optional_supported_gap_loci"], 1)
        priority_outputs = []
        for name in ("priority_candidates.tsv", "priority_loci.tsv"):
            path = self.result / name
            path.write_text("synthetic fixture only\n")
            record = fingerprint(path)
            record["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
            priority_outputs.append(record)
        priority_inputs = []
        for path in (self.result / "finish.done.json", folder / "done.json"):
            record = fingerprint(path)
            record["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
            priority_inputs.append(record)
        (self.result / "priority_summary.json").write_text(json.dumps({
            "counts": {"genome1_candidate_fragments": 2, "genome1_alignment_gap_loci": 1},
            "outputs": priority_outputs, "signature": {"inputs": priority_inputs}}))
        report = reporter.collect(self.root)
        self.assertEqual(report["pairs"][0]["priority_exports"]["status"], "completed")
        (self.result / "priority_loci.tsv").write_text("changed fixture\n")
        report = reporter.collect(self.root)
        self.assertEqual(report["pairs"][0]["priority_exports"]["status"], "incomplete")
        (folder / "loci.tsv").write_text((folder / "loci.tsv").read_text() + "\n")
        report = reporter.collect(self.root)
        self.assertEqual(report["pairs"][0]["status"], "completed")
        self.assertEqual(report["pairs"][0]["flank_validation"]["status"], "incomplete")
        self.assertNotIn("optional_supported_candidate_fragments", reporter.summary_rows(report)[0])

    def test_normalization_exclusion_scope_and_actual_source_classes(self):
        directory = self.result / "fixture_a"
        directory.mkdir()
        cases = [
            ("repeatmasker-out", {}, "1 0 0 0 chr1 1 40 (0) + R Retroposon/L1-dep 1 40 (0) 1", "Retroposon/L1-dep"),
            ("ucsc-bigrmsk-bed", {}, "1 0 0 0 chr1 1 40 (0) + R Retroposon/L1-dep 1 40 (0) 1", "Retroposon/L1-dep"),
            ("te-bed", {"bed_class_column": 7, "bed_family_column": 8},
                "chr1\t0\t40\tSVA_A\t0\t+\tRetroposon\tSVA", "Retroposon/SVA"),
            ("repeat-gff3", {"class_attribute": "Classification"},
                "chr1\tfixture\trepeat_region\t1\t40\t.\t+\t.\tID=test;Classification=DNA%3F", "DNA?"),
            ("ucsc-rmsk", {}, "\t".join(["0"] * 11 + ["Retroposon", "SVA"] + ["0"] * 4), "Retroposon/SVA")]
        for fmt, configuration, raw, expected in cases:
            with self.subTest(format=fmt):
                qc = {"format": fmt, "configuration": configuration, "counts": {
                    "retained_fragments": 100, "rejected_excluded_non_te": 2,
                    "rejected_unresolved_class": 1, "unknown_class_fragments": 10}}
                (directory / "repeats.qc.json").write_text(json.dumps(qc))
                with (directory / "repeats.rejected.tsv").open("w") as handle:
                    writer = csv.writer(handle, delimiter="\t")
                    writer.writerow(["source_line", "reason", "source_record"])
                    writer.writerow([1, "excluded_non_te", "unused fixture"])
                    writer.writerow([2, "unresolved_class", raw])
                report = reporter.collect(self.root)
                scope = report["pairs"][0]["genomes"][0]["normalization_scope"]
                self.assertEqual(scope["excluded_unresolved_source_class_families"], {expected: 1})
                self.assertEqual(scope["retained_Unknown_class_fragments"], 10)
                row = reporter.summary_rows(report)[0]
                self.assertEqual(row["excluded_unresolved_class_fragments"], 1)
                self.assertEqual(row["excluded_non_TE_fragments"], 2)
                self.assertNotIn("raw_candidate_fragments", row)
        qc["counts"]["rejected_unresolved_class"] = 2
        (directory / "repeats.qc.json").write_text(json.dumps(qc))
        with self.assertRaisesRegex(ValueError, "QC differs"):
            reporter.collect(self.root)

    def test_derived_repeat_input_keeps_original_and_corrected_checksums_distinct(self):
        original, derived = self.root / "raw.gz", self.root / "deduplicated.gz"
        original.write_bytes(b"fixture raw")
        derived.write_bytes(b"fixture derived")
        provenance = self.root / "dedup.json"
        provenance.write_text(json.dumps({"status": "passed", "source": str(original), "output": str(derived),
            "source_sha256_local": "original-sha-fixture", "output_sha256_local": "derived-sha-fixture", "output_bytes": 15}))
        Path(str(original) + ".provenance.json").write_text(json.dumps({"observed": {"md5": "provider-md5-fixture", "bytes": 11},
            "verification": "source_checksum_verified", "original_url": "https://example.invalid/source.gz"}))
        genome = {"id": "fixture", "repeats": str(derived), "repeat_deduplication_provenance": str(provenance)}
        records = reporter.input_records("test", genome, {}, self.root / "manifest.json")
        self.assertEqual(len(records), 2)
        self.assertEqual(records[0]["sha256"], "derived-sha-fixture")
        self.assertEqual(records[0]["md5"], "")
        self.assertEqual(records[0]["url"], "")
        self.assertEqual(records[0]["derived_from"], str(original))
        self.assertEqual(records[1]["sha256"], "original-sha-fixture")
        self.assertEqual(records[1]["md5"], "provider-md5-fixture")
        self.assertEqual(records[1]["verification"], "source_checksum_verified")

    def test_explicit_duplicate_source_correction_supersedes_original_pair(self):
        for genome in self.manifest["genomes"]:
            genome["fasta"] = str(self.root / (genome["id"] + ".fa"))
        original = self.root / "metadata/original_pair.json"
        original.write_text(json.dumps(self.manifest))
        (self.result / "manifest.json").write_text(json.dumps(self.manifest))
        self.mark_complete()
        corrected = copy.deepcopy(self.manifest)
        corrected["pair_id"] = "test_fixture_rat_corrected"
        corrected["derived_from_manifest"] = str(original)
        provenance = self.root / "dedup.json"
        provenance.write_text(json.dumps({"status": "passed"}))
        corrected["genomes"][1]["repeat_deduplication_provenance"] = str(provenance)
        (self.root / "metadata/corrected_pair.json").write_text(json.dumps(corrected))
        report = reporter.collect(self.root)
        self.assertEqual(len(report["pairs"]), 1)
        self.assertEqual(report["pairs"][0]["pair_id"], corrected["pair_id"])
        self.assertEqual(report["pairs"][0]["status"], "pending")
        self.assertNotIn("evidence", report["pairs"][0])
        self.assertEqual(report["superseded_pairs"][0]["pair_id"], self.manifest["pair_id"])

    def test_source_level_publication_and_explicit_gene_asset_version(self):
        source = self.root / "source.json"
        source.write_text(json.dumps({"publication": {"title": "Fixture project paper", "doi": "10.example/fixture",
            "first_online": "2025-12-01", "journal_collection_date": "2026-02-11"},
            "publication_binding": "Fixture project binding only; exact versions absent from article",
            "publication_limitations": ["Fixture version caveat"], "assemblies": [{"id": "fixture_a",
            "files": {"gene_gff3": {"filename": "fixture.Liftoff_v5.2.gff3.gz", "format": "Fixture Liftoff5.2"}}}]}))
        self.manifest["source_manifest"] = str(source)
        (self.result / "manifest.json").write_text(json.dumps(self.manifest))
        pair = reporter.collect(self.root)["pairs"][0]
        self.assertEqual(pair["genomes"][0]["publications"][0]["title"], "Fixture project paper")
        self.assertIn("Liftoff5.2", pair["genomes"][0]["annotation_release"])
        self.assertIn("absent", pair["source_scope_and_policies"]["publication_binding"])
        self.assertIn("2025-12-01", reporter.format_publication(pair["genomes"][0]["publications"][0]))

    def test_selected_sequence_provenance_schemas_keep_derived_hashes(self):
        raw, selected = self.root / "raw.fa", self.root / "selected.fa"
        raw.write_text(">fixture\nACGT\n")
        selected.write_text(">fixture\nACGT\n")
        provenance = self.root / "selection.json"
        genome = {"id": "fixture", "fasta": str(selected), "selection_provenance": str(provenance)}
        detail = {"files": {"fasta": {"local_path": str(raw), "local_sha256": "raw-hash", "md5": "source-md5"}}}
        for schema in ({"outputs": {"fasta": {"path": str(selected), "sha256": "selected-hash", "bytes": 12}}},
                       {"source": str(raw), "output": str(selected), "output_sha256": "selected-hash"}):
            with self.subTest(schema=schema):
                provenance.write_text(json.dumps(schema))
                rows = reporter.input_records("fixture", genome, detail, self.root / "manifest.json")
                self.assertEqual(rows[0]["sha256"], "selected-hash")
                self.assertEqual(rows[0]["md5"], "")
                self.assertEqual(rows[1]["sha256"], "raw-hash")
                self.assertEqual(rows[1]["md5"], "source-md5")

    def test_browser_fragment_extraction_preserves_three_stage_provenance(self):
        paths = [self.root / name for name in ("source.bb", "selected.bed.gz", "fragments.out.gz")]
        for path in paths:
            path.write_bytes(b"fixture")
        selection = self.root / "selection.json"
        selection.write_text(json.dumps({"repeats": {"output": str(paths[1]), "output_sha256": "selected-hash"}}))
        extraction = self.root / "extraction.json"
        extraction.write_text(json.dumps({"status": "passed", "input": str(paths[1]), "input_sha256": "selected-hash",
            "output": str(paths[2]), "output_sha256": "fragments-hash"}))
        genome = {"id": "fixture", "repeats": str(paths[2]), "selection_provenance": str(selection),
            "repeat_fragment_extraction_provenance": str(extraction)}
        detail = {"files": {"repeats": {"local_path": str(paths[0]), "local_sha256": "source-hash"}}}
        rows = reporter.input_records("fixture", genome, detail, self.root / "manifest.json")
        self.assertEqual([row["sha256"] for row in rows], ["fragments-hash", "source-hash", "selected-hash"])
        self.assertEqual(rows[0]["derived_from"], str(paths[1]))
        self.assertEqual(rows[2]["derived_from"], str(paths[0]))

    def test_predicted_gene_span_derivation_preserves_provider_checksum(self):
        original, derived = self.root / "original.gtf.gz", self.root / "predicted.gff3.gz"
        original.write_bytes(b"fixture original")
        derived.write_bytes(b"fixture derived")
        genome = {"id": "fixture", "genes": str(derived), "source_files": {"genes": {
            "local_path": str(original), "sha256": "source-hash", "provider_md5": "source-md5", "md5_verified": True,
            "provider_checksum_url": "https://example.invalid/CHECKSUMS"}}, "derived_gene_qc": {
            "input": str(original), "input_sha256": "source-hash", "output": str(derived), "output_sha256": "derived-hash"}}
        rows = reporter.input_records("fixture", genome, {}, self.root / "manifest.json")
        self.assertEqual(rows[0]["sha256"], "derived-hash")
        self.assertEqual(rows[0]["md5"], "")
        self.assertEqual(rows[1]["sha256"], "source-hash")
        self.assertEqual(rows[1]["md5"], "source-md5")
        self.assertEqual(rows[1]["verification"], "source_checksum_verified")

    def test_supplemental_annotation_coverage_verifies_inputs_without_inventing_candidates(self):
        folder = self.result / "fixture_a"
        folder.mkdir()
        bed, lengths = folder / "repeats.bed", folder / "lengths.tsv"
        bed.write_text("chr1\t0\t20\tF1\t0\t+\tDNA\nchr1\t10\t30\tF2\t0\t+\tUnknown\n")
        lengths.write_text("chr1\t100\n")
        (folder / "annotation_coverage.json").write_text(json.dumps(annotation_coverage.coverage(bed, lengths)))
        report = reporter.collect(self.root)
        row = reporter.summary_rows(report)[0]
        self.assertEqual(row["annotation_union_bases"], 30)
        self.assertEqual(row["annotation_union_fraction"], 0.3)
        self.assertEqual(row["annotation_Unknown_union_fraction"], 0.2)
        self.assertNotIn("raw_candidate_fragments", row)
        bed.write_text(bed.read_text() + "# changed\n")
        report = reporter.collect(self.root)
        self.assertEqual(report["pairs"][0]["genomes"][0]["annotation_coverage"]["status"], "incomplete")
        self.assertNotIn("annotation_union_bases", reporter.summary_rows(report)[0])

    def make_gap_fixture(self):
        for genome in self.manifest["genomes"]:
            folder = self.result / genome["id"]
            folder.mkdir()
            (folder / "repeats.bed").write_text("chr1\t0\t20\tF1\t0\t+\tDNA\n")
            (folder / "lengths.tsv").write_text("chr1\t100\n")
            genes = folder / "genes.gff3"
            genes.write_text("chr1\tfixture\tgene\t1\t10\t.\t+\t.\tID=g1\n")
            genome["genes"] = str(genes)
        (self.result / "manifest.json").write_text(json.dumps(self.manifest))
        self.mark_complete()
        folder = self.result / "flank_validation"
        folder.mkdir()
        (folder / "summary.json").write_text('{}')
        (folder / "loci.tsv").write_text('genome\tstatus\tfragment_ids_json\n1\treciprocal_unique_flank_supported_candidate\t["a", "b"]\n2\treciprocal_unique_flank_supported_candidate\t["c"]\n')
        (folder / "done.json").write_text(json.dumps({"status": "completed", "outputs": [hashed_fingerprint(folder / name) for name in ("summary.json", "loci.tsv")],
            "signature": {"inputs": [hashed_fingerprint(self.result / "finish.done.json")]}}))
        for name in ("priority_candidates.tsv", "priority_loci.tsv"):
            (self.result / name).write_text("synthetic fixture only\n")
        priority = {"counts": {"genome1_candidate_fragments": 2, "genome1_alignment_gap_loci": 1, "genome2_candidate_fragments": 1, "genome2_alignment_gap_loci": 1},
            "outputs": [hashed_fingerprint(self.result / name) for name in ("priority_candidates.tsv", "priority_loci.tsv")],
            "signature": {"inputs": [hashed_fingerprint(self.result / name) for name in ("finish.done.json", "flank_validation/done.json")]}}
        (self.result / "priority_summary.json").write_text(json.dumps(priority))
        rows = []
        for side, bases, fragments in ((1, 20, 2), (2, 90, 1)):
            rows.append(dict(locus_id="L%d" % side, alignment_id="paf:%d" % side, genome=str(side), genome_id=self.manifest["genomes"][side-1]["id"],
                source_chrom="chr1", source_gap_start0="0", source_gap_end0="100", gap_length_bp="100", opposite_chrom="chr1", opposite_empty_site0="200",
                retained_annotation_union_bp=str(bases), supported_candidate_union_bp="10", supported_fragment_count=str(fragments),
                retained_annotation_gap_fraction=str(bases/100), supported_candidate_gap_fraction="0.1"))
        self.gap_rows = rows
        self.publish_gap_table()
        paths = [self.result / name for name in ("manifest.json", "priority_summary.json", "priority_candidates.tsv", "priority_loci.tsv")]
        for genome in self.manifest["genomes"]:
            paths += [self.result / genome["id"] / name for name in ("repeats.bed", "lengths.tsv")]
            paths.append(Path(genome["genes"]))
        self.gap_summary = dict(status="completed", schema_version=1, pair_id=self.manifest["pair_id"],
            signature={"inputs": [hashed_fingerprint(path) for path in paths], "scripts": [hashed_fingerprint(Path(reporter.__file__))]},
            outputs=[hashed_fingerprint(self.result / "gap_composition.tsv")],
            counts={"supported_alignment_gap_loci": 2, "supported_candidate_fragments": 3,
                "gaps_with_retained_TE_union_below_10_percent": 0, "gaps_with_retained_TE_union_below_50_percent": 1, "gaps_with_retained_TE_union_below_80_percent": 1},
            gene_feature_scope={genome["id"]: {"included_feature_type": "gene", "included_exact_gene_rows": 1,
                "source_feature_counts": {"gene": 1, "ncRNA_gene": 2, "pseudogene": 3, "exon": 4},
                "omitted_feature_counts": {"ncRNA_gene": 2, "pseudogene": 3, "exon": 4},
                "omitted_other_gene_like_features": {"ncRNA_gene": 2, "pseudogene": 3}} for genome in self.manifest["genomes"]},
            exact_coordinate_audit=reporter.gap_coordinate_counts(rows))
        self.publish_gap_summary()

    def publish_gap_table(self):
        with (self.result / "gap_composition.tsv").open("w") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(self.gap_rows[0]), delimiter="\t")
            writer.writeheader()
            writer.writerows(self.gap_rows)

    def publish_gap_summary(self):
        (self.result / "gap_composition_summary.json").write_text(json.dumps(self.gap_summary))

    def test_gap_composition_verified_counts_gene_scope_and_rendering(self):
        self.make_gap_fixture()
        report = reporter.collect(self.root)
        self.assertEqual(report["pairs"][0]["gap_composition"]["status"], "completed")
        row = reporter.summary_rows(report)[0]
        self.assertEqual(row["gap_TE_union_below_50_percent"], 1)
        self.assertEqual(row["gene_context_omitted_other_gene_like_rows"], 5)
        reporter.write_markdown(report, self.root)
        markdown = (self.root / "study_report.md").read_text()
        self.assertIn("分母是 TE 片段长度", markdown)
        self.assertIn("ncRNA_gene=2", markdown)
        self.assertIn("没有聚类结构事件", markdown)
        self.assertIn("gap_composition.tsv", markdown)

    def test_markdown_links_resolve_for_relative_and_absolute_study_dirs(self):
        self.make_gap_fixture()
        previous = Path.cwd()
        try:
            os.chdir(self.root)
            for absolute in (False, True):
                with self.subTest(absolute=absolute):
                    study_dir = self.root if absolute else Path(".")
                    output = Path("reports with spaces") / ("absolute (draft)" if absolute else "relative #draft")
                    if absolute:
                        output = self.root / output
                    report = reporter.collect(study_dir)
                    before = copy.deepcopy(report)
                    reporter.write_report(report, output)
                    self.assertEqual(report, before)
                    self.assertEqual(json.loads((output / "study_summary.json").read_text()), before)
                    links = re.findall(r"!?\[[^\]\n]*\]\(([^)\n]+)\)", (output / "study_report.md").read_text())
                    self.assertGreaterEqual(len(links), 10)
                    for link in links:
                        parsed = urlsplit(link)
                        self.assertFalse(parsed.scheme, link)
                        self.assertFalse(parsed.query or parsed.fragment, link)
                        self.assertFalse(Path(unquote(parsed.path)).is_absolute(), link)
                        self.assertTrue((output / unquote(parsed.path)).is_file(), link)
                    expected = reporter.markdown_local_link(self.result / "priority_candidates.tsv", output)
                    self.assertIn(expected, links)
                    self.assertIn(reporter.markdown_local_link(self.result / "gap_composition.tsv", output), links)
        finally:
            os.chdir(previous)

    def test_markdown_local_links_escape_spaces_and_url_delimiters(self):
        target = self.result / "candidate [set] (v1) #?% 中文.tsv"
        target.write_text("fixture only\n")
        output = self.root / "reports with spaces"
        output.mkdir()
        absolute_link = reporter.markdown_local_link(target, output)
        previous = Path.cwd()
        try:
            os.chdir(self.root)
            self.assertEqual(reporter.markdown_local_link(target.relative_to(self.root), output.relative_to(self.root)), absolute_link)
        finally:
            os.chdir(previous)
        for escaped in ("%20", "%5B", "%5D", "%28", "%29", "%23", "%3F", "%25"):
            self.assertIn(escaped, absolute_link)
        parsed = urlsplit(absolute_link)
        self.assertFalse(parsed.scheme or parsed.query or parsed.fragment)
        self.assertEqual((output / unquote(parsed.path)).resolve(), target)

    def test_gap_composition_rejects_changed_output_or_source(self):
        self.make_gap_fixture()
        for path in (self.result / "gap_composition.tsv", Path(self.manifest["genomes"][0]["genes"])):
            with self.subTest(path=path.name):
                previous = path.read_bytes()
                path.write_bytes(previous + b"# changed\n")
                result = reporter.collect(self.root)["pairs"][0]["gap_composition"]
                self.assertEqual(result["status"], "incomplete")
                self.assertIn("SHA256", result["reason"])
                path.write_bytes(previous)
                for records in (self.gap_summary["outputs"], self.gap_summary["signature"]["inputs"]):
                    for index, record in enumerate(records):
                        if record["path"] == str(path):
                            records[index] = hashed_fingerprint(path)
                self.publish_gap_summary()

    def test_gap_composition_rejects_inconsistent_totals_scope_and_duplicates(self):
        self.make_gap_fixture()
        original = copy.deepcopy(self.gap_summary)
        mutations = [("counts", "supported_candidate_fragments", 99),
                     ("exact_coordinate_audit", "source_interval_exact_duplicate_groups", 1)]
        for section, key, value in mutations:
            self.gap_summary = copy.deepcopy(original)
            self.gap_summary[section][key] = value
            self.publish_gap_summary()
            self.assertEqual(reporter.collect(self.root)["pairs"][0]["gap_composition"]["status"], "incomplete")
        self.gap_summary = copy.deepcopy(original)
        self.gap_summary["gene_feature_scope"]["fixture_a"]["omitted_other_gene_like_features"] = {}
        self.publish_gap_summary()
        self.assertIn("gene-like", reporter.collect(self.root)["pairs"][0]["gap_composition"]["reason"])

    def test_exact_coordinate_duplicate_counts_ignore_alignment_id(self):
        first = dict(locus_id="L1", alignment_id="paf:1", genome="1", source_chrom="a", source_gap_start0="0", source_gap_end0="10", opposite_chrom="b", opposite_empty_site0="20")
        second = dict(first, locus_id="L2", alignment_id="paf:2")
        third = dict(first, locus_id="L3", genome="2", source_chrom="b", source_gap_start0="20", source_gap_end0="25", opposite_chrom="a", opposite_empty_site0="10")
        observed = reporter.gap_coordinate_counts([first, second, third])
        for key in ("source_interval_exact_duplicate_groups", "source_interval_duplicates_with_different_alignment_ids", "opposite_empty_point_exact_duplicate_groups", "normalized_paired_interval_exact_duplicate_groups"):
            self.assertEqual(observed[key], 1)
        self.assertEqual(observed["cross_side_mutual_exact_gap_boundary_matches"], [["L1", "L3"], ["L2", "L3"]])

    def make_profile_fixture(self, complete=True):
        self.manifest.update(preset="asm20", threads=2)
        for genome in self.manifest["genomes"]:
            fasta = self.root / (genome["id"] + ".fa")
            fasta.write_text(">fixture\nACGT\n")
            genome["fasta"] = str(fasta)
        (self.result / "manifest.json").write_text(json.dumps(self.manifest))
        launcher, binary = self.root / "launcher", self.root / "minimap2"
        launcher.write_text("synthetic pinned launcher")
        binary.write_text("synthetic pinned binary")
        self.profile = dict(schema_version=1, profile_id="maize_low_memory_v1", original_preset="asm20", launcher=str(launcher),
            launcher_sha256=reporter.file_sha256(launcher), underlying_binary=str(binary), underlying_sha256=reporter.file_sha256(binary),
            overrides=["-w19", "-f50", "-U50,50", "-e0", "-t1", "-K25m"], whole_genome_inputs_preserved=True)
        (self.result / "alignment_profile.json").write_text(json.dumps(self.profile))
        requested = ['-x','asm20','-c','--eqx','--secondary=no','-t','2','-I6G','-K250m', self.manifest['genomes'][1]['fasta'], self.manifest['genomes'][0]['fasta']]
        self.profile_event = dict(profile_id=self.profile["profile_id"], underlying_sha256=self.profile["underlying_sha256"], requested_argv=requested,
            effective_argv=[str(binary)] + requested[:-2] + self.profile["overrides"] + requested[-2:])
        (self.result / "logs").mkdir()
        (self.result / "alignment.paf.gz").write_bytes(b"synthetic fixture only")
        self.publish_profile_log()
        if complete:
            self.publish_align_marker()

    def publish_profile_log(self):
        (self.result / "logs/minimap2.stderr.log").write_text("TEVOX_MINIMAP2_PROFILE " + json.dumps(self.profile_event) + "\n")

    def publish_align_marker(self):
        (self.result / "align.done.json").write_text(json.dumps(dict(status="completed", signature={"manifest": self.manifest,
            "tools": [hashed_fingerprint(Path(self.profile["launcher"]))],
            "inputs": [fingerprint(Path(genome["fasta"])) for genome in self.manifest["genomes"]]},
            outputs=[fingerprint(self.result / name) for name in ("alignment.paf.gz", "logs/minimap2.stderr.log")])) )

    def test_profile_declaration_alone_is_pending_and_never_invents_results(self):
        self.make_profile_fixture(complete=False)
        report = reporter.collect(self.root)
        self.assertEqual(report["pairs"][0]["alignment_profile"]["status"], "pending")
        self.assertNotIn("raw_candidate_fragments", reporter.summary_rows(report)[0])
        reporter.write_markdown(report, self.root)
        self.assertIn("尚未将配置声明视为", (self.root / "study_report.md").read_text())

    def test_profile_requires_completed_tool_and_actual_effective_argv(self):
        self.make_profile_fixture()
        report = reporter.collect(self.root)
        self.assertEqual(report["pairs"][0]["alignment_profile"]["status"], "applied")
        self.assertEqual(reporter.summary_rows(report)[0]["alignment_profile_status"], "applied")
        reporter.write_markdown(report, self.root)
        self.assertIn("降低重复密集区域的比对敏感性", (self.root / "study_report.md").read_text())
        altered = dict(self.profile, overrides=self.profile["overrides"] + ["-I1G"])
        (self.result / "alignment_profile.json").write_text(json.dumps(altered))
        self.assertIn("supported audited", reporter.collect(self.root)["pairs"][0]["alignment_profile"]["reason"])
        (self.result / "alignment_profile.json").write_text(json.dumps(self.profile))
        self.profile_event["effective_argv"].remove("-f50")
        self.publish_profile_log()
        self.publish_align_marker()
        self.assertIn("argv", reporter.collect(self.root)["pairs"][0]["alignment_profile"]["reason"])

    def test_profile_markdown_link_is_relative_to_report_directory(self):
        self.make_profile_fixture()
        report = reporter.collect(self.root)
        original = copy.deepcopy(report)
        output = self.root / "reports with spaces" / "nested"
        output.mkdir(parents=True)
        reporter.write_markdown(report, output)
        links = re.findall(r"\[配置描述\]\(([^)\n]+)\)", (output / "study_report.md").read_text())
        self.assertEqual(len(links), 1)
        self.assertEqual((output / unquote(links[0])).resolve(), self.result / "alignment_profile.json")
        self.assertFalse(Path(unquote(links[0])).is_absolute())
        self.assertEqual(report, original)

    def test_profile_rejects_changed_launcher_binary_fasta_log_and_alignment(self):
        self.make_profile_fixture()
        for path in (Path(self.profile["launcher"]), Path(self.profile["underlying_binary"]), Path(self.manifest["genomes"][0]["fasta"]),
                     self.result / "logs/minimap2.stderr.log", self.result / "alignment.paf.gz"):
            with self.subTest(path=path.name):
                previous = path.read_bytes()
                path.write_bytes(previous + b"changed")
                self.assertEqual(reporter.collect(self.root)["pairs"][0]["alignment_profile"]["status"], "incomplete")
                path.write_bytes(previous)
                self.publish_align_marker()


if __name__ == "__main__":
    unittest.main(verbosity=2)
