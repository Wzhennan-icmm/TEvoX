#!/usr/bin/env python3
"""Real miniature prepare/TEvoX/evidence pipeline, with a deterministic mock aligner."""
import argparse
import gzip
import json
from pathlib import Path
import tempfile
import unittest
import run_pair


class PairIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='tevox-pair-unit-test-')
        self.root = Path(self.temp.name)
        self.out = self.root / 'outputs'
        self.aligner = self.root / 'minimap2-mock'
        self.write_aligner()
        genomes = []
        for identifier, length, start in [('a', 25000, 10020), ('b', 24800, 5000)]:
            with gzip.open(self.root / (identifier + '.fa.gz'), 'wt') as handle:
                handle.write('>chr1\n' + 'A' * length + '\n')
            (self.root / (identifier + '.gff')).write_text('##gff-version 3\nchr1\ttest\tgene\t10401\t11000\t.\t+\t.\tID=gene1;Name=GeneOne\n')
            (self.root / (identifier + '.bed')).write_text('chr1\t%d\t%d\tRepeatOne\t0\t+\tLINE\n' % (start, start + 100))
            genomes.append({'id': identifier, 'fasta': identifier + '.fa.gz', 'genes': identifier + '.gff',
                            'repeats': identifier + '.bed', 'repeat_format': 'te-bed',
                            'normalize_args': ['--bed-coordinates', 'zero-based-half-open', '--bed-class-column', '7', '--bed-strand-column', '6']})
        self.manifest = self.root / 'manifest.json'
        self.manifest.write_text(json.dumps({'pair_id': 'test_only', 'preset': 'asm5', 'threads': 1, 'genomes': genomes}))

    def tearDown(self):
        self.temp.cleanup()

    def write_aligner(self, exit_code=0):
        paf = 'chr1\t25000\t0\t25000\t+\tchr1\t24800\t0\t24800\t24800\t25000\t60\ttp:A:P\tcg:Z:10000=200I14800='
        self.aligner.write_text('#!/usr/bin/env python3\nimport sys\nif "--version" in sys.argv:\n print("mock-unit-test-only")\n sys.exit(0)\nprint(%r)\nsys.exit(%d)\n' % (paf, exit_code))
        self.aligner.chmod(0o700)

    def runner(self, phase='all'):
        return run_pair.Runner(argparse.Namespace(manifest=str(self.manifest), output_dir=str(self.out), phase=phase,
                                                 tevox=str(run_pair.ROOT / 'tools' / 'tevox'), minimap2=str(self.aligner)))

    def test_real_complete_pipeline_and_verified_resume(self):
        self.runner().run()
        summary = json.loads((self.out / 'evidence' / 'summary.json').read_text())
        self.assertEqual(summary['genome1']['candidate_fragments'], 1)
        self.assertEqual(summary['genome1']['categories']['anchored_gap_candidate'], 1)
        self.assertEqual(summary['genome2']['candidate_fragments'], 0)
        self.assertTrue((self.out / 'a' / 'candidate_genes.tsv').is_file())
        before = (self.out / 'alignment.paf.gz').stat().st_mtime_ns
        self.runner().run()
        self.assertEqual(before, (self.out / 'alignment.paf.gz').stat().st_mtime_ns)
        events = [json.loads(line) for line in (self.out / 'run_commands.jsonl').read_text().splitlines()]
        self.assertEqual(sum(event['event'] == 'phase_reused' for event in events), 3)

    def test_changed_input_prevents_alignment_reuse(self):
        self.runner('prepare').run()
        with (self.root / 'a.gff').open('a') as handle:
            handle.write('#source metadata changed\n')
        with self.assertRaisesRegex(ValueError, 'prepare marker missing/stale'):
            self.runner('align').run()
        self.assertFalse((self.out / 'align.done.json').exists())

    def test_alignment_failure_has_no_success_or_partial_output(self):
        self.runner('prepare').run()
        self.write_aligner(exit_code=7)
        with self.assertRaisesRegex(ValueError, 'minimap2 failed'):
            self.runner('align').run()
        self.assertFalse((self.out / 'alignment.paf.gz').exists())
        self.assertFalse((self.out / 'alignment.paf.gz.part').exists())
        self.assertFalse((self.out / 'align.done.json').exists())
        events = [json.loads(line) for line in (self.out / 'run_commands.jsonl').read_text().splitlines()]
        self.assertEqual(events[-1]['event'], 'phase_failed')

    def test_modified_alignment_rejected_by_finish(self):
        self.runner('prepare').run()
        self.runner('align').run()
        with (self.out / 'alignment.paf.gz').open('ab') as handle:
            handle.write(b'corruption')
        with self.assertRaisesRegex(ValueError, 'align marker missing/stale'):
            self.runner('finish').run()

    def test_input_output_override_forbidden(self):
        manifest = json.loads(self.manifest.read_text())
        manifest['genomes'][0]['normalize_args'] = ['--output-prefix', '/tmp/wrong']
        self.manifest.write_text(json.dumps(manifest))
        with self.assertRaisesRegex(ValueError, 'overrides forbidden'):
            self.runner('prepare')


if __name__ == '__main__':
    unittest.main()
