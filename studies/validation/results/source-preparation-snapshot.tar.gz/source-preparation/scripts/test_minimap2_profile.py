#!/usr/bin/env python3
import contextlib
import io
import json
from pathlib import Path
import random
import subprocess
import tempfile
import unittest

import make_minimap2_profile


class Minimap2ProfileTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='tevox-profile-test-')
        self.root = Path(self.temporary.name)
        self.binary = self.root / 'minimap2'
        self.binary.write_text('#!/usr/bin/env python3\nimport json,sys\nprint(json.dumps(sys.argv[1:]))\n')
        self.binary.chmod(0o700)
        self.launcher = self.root / 'maize-profile'
        for name in ('target.fa', 'query.fa'):
            (self.root / name).write_text('>one\nACGT\n')
        self.arguments = ['-x', 'asm20', '-c', '--eqx', '--secondary=no', '-t', '4', '-I6G', '-K250m',
                          str(self.root / 'target.fa'), str(self.root / 'query.fa')]
        make_minimap2_profile.generate(self.binary, self.launcher)

    def tearDown(self):
        self.temporary.cleanup()

    def execute(self, arguments=None):
        return subprocess.run([str(self.launcher)] + (arguments if arguments is not None else self.arguments),
                              text=True, capture_output=True, timeout=30)

    def test_override_order_and_explicit_runtime_record(self):
        result = self.execute()
        self.assertEqual(result.returncode, 0, result.stderr)
        actual = json.loads(result.stdout)
        self.assertEqual(actual, self.arguments[:-2] + make_minimap2_profile.OVERRIDES + self.arguments[-2:])
        self.assertIn('TEVOX_MINIMAP2_PROFILE', result.stderr)
        self.assertIn('maize_low_memory_v1', result.stderr)
        self.assertLess(actual.index('-x'), actual.index('-w19'))
        self.assertEqual(actual[-2:], self.arguments[-2:])

    def test_underlying_binary_mutation_is_rejected(self):
        with self.binary.open('a') as handle:
            handle.write('# changed executable bytes\n')
        result = self.execute()
        self.assertEqual(result.returncode, 2)
        self.assertIn('SHA256 changed', result.stderr)
        self.assertEqual(result.stdout, '')

    def test_other_presets_and_multipart_target_options_rejected(self):
        wrong = self.arguments.copy()
        wrong[1] = 'asm10'
        self.assertEqual(self.execute(wrong).returncode, 2)
        wrong = self.arguments.copy()
        wrong[7] = '-I1G'
        self.assertEqual(self.execute(wrong).returncode, 2)
        self.assertEqual(self.execute(self.arguments + ['-f500']).returncode, 2)

    def test_version_and_sidecar_not_runtime_configuration(self):
        sidecar = Path(str(self.launcher) + '.profile.json')
        sidecar.write_text('{"overrides":["-I1G"]}\n')
        result = self.execute(['--version'])
        self.assertEqual(result.returncode, 0)
        self.assertEqual(json.loads(result.stdout), ['--version'])
        self.assertEqual(json.loads(self.execute().stdout)[-8:-2], make_minimap2_profile.OVERRIDES)

    def test_idempotent_generation_and_existing_file_protection(self):
        before = self.launcher.stat().st_mtime_ns
        make_minimap2_profile.generate(self.binary, self.launcher)
        self.assertEqual(self.launcher.stat().st_mtime_ns, before)
        self.launcher.write_text('user-owned replacement')
        with self.assertRaisesRegex(ValueError, 'Existing launcher differs'):
            make_minimap2_profile.generate(self.binary, self.launcher)
        self.assertEqual(self.launcher.read_text(), 'user-owned replacement')

    def test_real_minimap2_small_sequence_validity(self):
        actual = Path(__file__).resolve().parents[1] / 'tools' / 'minimap2-src' / 'minimap2'
        if not actual.is_file():
            self.skipTest('Actual minimap2 unavailable; unit tests still verify launcher behavior')
        rng = random.Random(1003)
        bases = ''.join(rng.choices('ACGT', k=20000))
        for name in ('target.fa', 'query.fa'):
            (self.root / name).write_text('>seq1\n' + bases + '\n')
        launcher = self.root / 'official-profile'
        make_minimap2_profile.generate(actual, launcher)
        result = subprocess.run([str(launcher)] + self.arguments, text=True, capture_output=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('mid_occ = 50', result.stderr)
        self.assertIn('skip: 19', result.stderr)
        fields = result.stdout.splitlines()[0].split('\t')
        self.assertEqual(fields[:12], ['seq1', '20000', '0', '20000', '+', 'seq1', '20000', '0', '20000', '20000', '20000', '60'])
        self.assertIn('cg:Z:20000=', fields)


if __name__ == '__main__':
    unittest.main()
