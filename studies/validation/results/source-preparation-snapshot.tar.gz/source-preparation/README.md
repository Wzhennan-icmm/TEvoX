# 已发表基因组比较：可复现工作流源码

本目录提供五个物种各一对材料的来源清单、下载与注释准备脚本、TEvoX 分析、独立侧翼验证和报告生成。只包含源码与小型来源记录；基因组、注释大文件、二进制、比对结果和成功标记须在自己的工作目录重新生成。

| 物种 | 两个材料 | 执行清单 |
| --- | --- | --- |
| 人 | CHM13hTERT / HG002 母源单倍型 | `metadata/human_pair.json` |
| 小鼠 | C57BL/6NJ v3 / CAST/EiJ v3 | `metadata/mouse_pair.json` |
| 大鼠 | BN/NHsdMcwi GRCr8 / SHRSP/BbbUtx T2T | `metadata/rat_corrected_pair.json` |
| 拟南芥 | Nyl-7 / Sq-1，v2.1 | `discovery/arabidopsis_pair.json` |
| 玉米 | B73 NAM5 / Oh43 NAM1 | `discovery/maize_pair.json` |

完整来源、论文 DOI、精确组装、URL、提供方校验和与历史本地散列在 [source_catalog.json](source_catalog.json)。各物种的详细限制保存在 `discovery/*_sources.md`、`discovery/plants.md` 和对应 JSON。`source_snapshot.json` 记录复制前后脚本/元数据的 SHA256；历史验证记录不代表新工作目录已下载或已分析。

## 初始化独立工作目录

推荐 Linux、Python 3.10+、C 编译器、GNU Make、curl 和 GNU coreutils（部分来源审计使用 `sort`、`sum -r`）。核心 Python 分析仅用标准库；报告绘图另需 matplotlib，本次验证版本为3.10.8。科学工作流在 Linux 验证；TEvoX 本体的系统适配范围见仓库平台文档，不能据此推定全部外部生信工具在每个平台均已验证。

在 TEvoX 仓库根目录运行：

```sh
TEVOX_REPO="$PWD"
STUDY_ROOT="$HOME/tevox-published-genomes"
python3 studies/published-genomes/initialize_study.py --study-root "$STUDY_ROOT"
make -j2 TARGET="$STUDY_ROOT/tools/tevox" OBJDIR="$STUDY_ROOT/tools/tevox-obj"
git clone https://github.com/lh3/minimap2.git "$STUDY_ROOT/tools/minimap2-src"
git -C "$STUDY_ROOT/tools/minimap2-src" checkout 79c9cc186b95f50bd899f69b48eba995ced810c6
make -C "$STUDY_ROOT/tools/minimap2-src" -j2
"$STUDY_ROOT/tools/minimap2-src/minimap2" --version
cd "$STUDY_ROOT"
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements-report.txt
```

该 commit 对应本次使用的 minimap2 **2.30-r1287**。初始化只复制源码/元数据、替换清单中的 `@STUDY_ROOT@`，不联网、不下载、不安装工具。目标必须是新目录或空目录；路径可包含空格。科学分析脚本保持源码快照的逻辑，个别下载/准备脚本仅将固定工作区路径改为 `__file__` 所在目录。

人类 HG002 的 bigRmsk 转换另需 UCSC `bigBedToBed`。从 [UCSC 官方工具目录](https://hgdownload.soe.ucsc.edu/admin/exe/) 取得适合运行机器的版本，将可执行文件放到 `tools/bigBedToBed`；不使用其他操作系统的二进制。已转换的输入进行后续分析时不再需要此工具。

完整运行需要数十 GB 的空间，原始文件、派生输入、索引和 PAF 都占用空间；请预留余量并按物种顺序运行。默认每次比对 4 线程，仅并行一个全基因组索引，程序保留至少 1 GiB 空闲磁盘。

## 下载与准备输入

下载通过 HTTPS，保留来源 URL、文件大小、散列和原文件。MD5、Ensembl BSD sum 或作者校验值与本地 SHA256 分开记录。人类部分注释和拟南芥数据未发现提供方完整对象校验值；不能将 multipart S3 ETag 或本地 SHA256 当作作者 MD5。

### 拟南芥

```sh
python3 scripts/download_plant_inputs.py --species arabidopsis --list
python3 scripts/download_plant_inputs.py --species arabidopsis
python3 discovery/filter_arabidopsis_primary.py
```

保留五条已分布染色体，基因和 EDTA 注释按精确 seqID 筛选。只使用 manifest 明列的十种 TE feature，避免 LTR wrapper/子片段/TSD 重复计数；未知 `repeat_region` 不包括在这一 TE 集合中。小写 `classification` 为分类键，样本间 `TE_...` 名称不是共享家族 ID。

### 玉米

```sh
python3 scripts/download_plant_inputs.py --species maize
python3 scripts/gtf_predicted_genes.py \
  --input data/maize/b73/GCF_902167145.1_Zm-B73-REFERENCE-NAM-5.0.augustus.gtf.gz \
  --chrom-sizes discovery/b73_chromsizes.metadata --sample b73 \
  --output data/maize/b73/predicted.genes.gff3.gz \
  --qc discovery/maize_b73_gene_conversion.json
python3 scripts/gtf_predicted_genes.py \
  --input data/maize/oh43/GCA_902167015.1_Zm-Oh43-REFERENCE-NAM-1.0.augustus.gtf.gz \
  --chrom-sizes discovery/oh43_chromsizes.metadata --sample oh43 \
  --output data/maize/oh43/predicted.genes.gff3.gz \
  --qc discovery/maize_oh43_gene_conversion.json
```

基因组来自 Hufford et al. 2021 的 NAM 项目，但实际采用的重复与基因注释为 UCSC 补算，不是作者 Pan-EDTA/高置信基因集。两套 RepeatMasker 均报告 open-4.0.8 与 Dfam_Consensus-20181026/RepBase-20181026；Oh43 额外列出 `-frag 20000`。Augustus 预测中每个材料约14.1万个 gene_id，可能含错误或 TE 相关模型，玉米训练模型未由 track 描述明确。转换仅由同一 gene_id 的 exon 最小/最大坐标构造预测 gene-body；基因邻近关系只作描述。

### 大鼠

```sh
python3 scripts/download_rat_inputs.py
python3 scripts/deduplicate_repeatmasker.py \
  --input data/rat/shrsp/GCF_021556685.1_SHRSP_T2T_rm.out.gz \
  --output data/rat/shrsp/GCF_021556685.1_SHRSP_T2T_rm.deduplicated.out.gz \
  --report metadata/rat_shrsp_repeat_dedup.json
```

必须使用 `rat_corrected_pair.json`。历史核查发现官方 SHRSP repeat 文件9,119,000条记录恰好成对重复；派生文件去掉4,559,500条所有字段完全相同的连续重复，原文件保留。脚本不合并不同 TE 片段；非连续重复会导致失败，需调查而不是放宽规则。提供方文件校验通过不代表内容没有重复。

### 小鼠

```sh
python3 scripts/download_mouse_inputs.py
python3 scripts/select_mouse_primary.py
python3 scripts/audit_repeat_duplicates.py \
  --input data/mouse/c57/GCA_921999865.2.repeatMasker.out.gz \
  --output data/mouse/c57/repeat_duplicate_audit.json --temp-dir data/mouse/c57
python3 scripts/audit_repeat_duplicates.py \
  --input data/mouse/cast/GCA_921999005.2.repeatMasker.out.gz \
  --output data/mouse/cast/repeat_duplicate_audit.json --temp-dir data/mouse/cast
python3 scripts/audit_repeat_identities.py
python3 scripts/finalize_mouse_provenance.py
```

选择两材料完整核染色体1–19和X，明确排除MT和未定位序列。Ensembl115序列名仅按精确 assembly report/chromAlias 映射，坐标不变。来源绑定是 Helmy et al. 项目 PRJEB47108 的 v3 组装；论文主文没有直接打印这些 accession.version，且论文与提交记录的 contig N50 不同，不能宣称精确复刻论文统计。两套 RepeatMasker 物种参数不同，所选家族内容未逐条比较。

### 人

```sh
python3 scripts/download_human_inputs.py
python3 scripts/prepare_human_pair.py
python3 scripts/prepare_human_repeat_inputs.py
```

比较两个不同供者材料，仅 chr1–22及X；CHM13 v2 的Y来自HG002，故排除Y及MT。HG002只使用母源单倍型。CHM13基因组严格使用作者/GenBank匹配集，不能替换为不等价的GCF文件。bigRmsk 的可视化 BED 范围含侧翼或缺口，同一 joined record 内原始片段还可能有不同方向（例如LINE的5′倒位）。额外准备步骤调用 `extract_bigrmsk_fragments.py`，保留原始5,422,582个RepeatMasker片段各自的全部字段、链和顺序，先审计原始片段计数与重复，再验证来源/输出的有序canonical散列并独立重读输出及source-row/part映射，最后原子更新运行清单为 `repeatmasker-out`。原文件有一条片段比浏览器 aligned-summary 起点早1bp；该准备步骤显式允许并记录这一汇总边界异常，仍要求每条原始片段的 end+remaining 等于精确FASTA长度，且不改坐标。不能用浏览器显示链覆盖所有片段，也不能把可视化跨度当作TE区间。两套重复注释版本不同，是解释差异时的限制。

## 分析与侧翼验证

每个物种先按上节生成实际输入；以下命令按顺序执行。可以只运行准备好的物种。

```sh
python3 scripts/run_pair.py --manifest discovery/arabidopsis_pair.json --output-dir results/arabidopsis
python3 scripts/run_pair.py --manifest discovery/maize_pair.json --output-dir results/maize
python3 scripts/run_pair.py --manifest metadata/rat_corrected_pair.json --output-dir results/rat
python3 scripts/run_pair.py --manifest metadata/mouse_pair.json --output-dir results/mouse
python3 scripts/run_pair.py --manifest metadata/human_pair.json --output-dir results/human
```

也可传入 `--phase prepare`、`--phase align`、`--phase finish` 分段执行。非默认工具位置用 `--tevox /absolute/path/tevox --minimap2 /absolute/path/minimap2`。材料清单须提供两个不同FASTA及匹配的 gene/repeat 输入；路径相对于清单目录或为绝对路径。

玉米默认 `asm20` 在本次云环境曾因内存分配失败而中止。可选的显式恢复配置详见 [maize-low-memory-v1.md](docs/maize-low-memory-v1.md)。该配置于2026-10-03完成实际全基因组比对：B73全部687条序列对Oh43全部757条序列，完整FASTA未切分，目标保留单个完整索引；Real 4114.997秒、CPU 4113.734秒、程序报告峰值RSS 13.617GB。[验证记录](provenance/minimap2-maize-profile-full-alignment-validation.json)核对了真实完成标记、输入/输出指纹、启动器及程序散列和实际参数；其证明范围是align阶段，下游完成状态须另行核验。更严格的重复种子过滤降低重复丰富区域的比对敏感性，未比对TE数量因此依赖配置，不能解释为真实生物学缺失。这也不是硬内存上限或其他机器的资源保证。先构建本机minimap2并完成prepare，再明确选择：

```sh
python3 scripts/make_minimap2_profile.py \
  --binary tools/minimap2-src/minimap2 --output tools/minimap2-maize-low-memory-v1
cp tools/minimap2-maize-low-memory-v1.profile.json results/maize/alignment_profile.json
python3 scripts/run_pair.py --manifest discovery/maize_pair.json \
  --output-dir results/maize --phase align --minimap2 tools/minimap2-maize-low-memory-v1
python3 scripts/run_pair.py --manifest discovery/maize_pair.json \
  --output-dir results/maize --phase finish --minimap2 tools/minimap2-maize-low-memory-v1
```

源码包只附生成器，启动器须在实际工作目录重新生成以固定底层程序的绝对路径和SHA256。将生成的配置描述复制到prepare建立的结果目录，供报告核验；这份JSON本身只声明配置，不能证明配置已应用。只有比对成功标记、启动器路径/散列、实际程序字节、输入及日志指纹和stderr记录的请求/实际参数全部匹配后，报告才标记为已应用。align和finish必须使用同一个启动器，独立侧翼验证继续使用原始minimap2。已存在完整或失败的旧运行须先依照指纹规则保留原日志、处理旧输出；本包不自动替换结果。

本次玉米的主分析、独立侧翼、候选导出和缺口审计随后也完成并通过[下游验证](provenance/minimap2-maize-profile-full-workflow-validation.json)：8,628个已知类别且有侧翼支持的注释片段，归入2,736个对齐缺口位点。合格对齐并集覆盖B73的56.69335%、Oh43的55.81209%；约44%的未覆盖序列仍未解决，不能全部当作真实差异。计数不是已确认的TE插入事件，且受本配置较低的重复区域敏感性影响。基因上下文仍使用UCSC AUGUSTUS从头预测，不能解释为作者高置信基因或功能证据；最终结果及独立来源抽查应阅读各自的结果报告。

归一化完成后，可补充每个材料的TE覆盖度QC，不改已验证的准备输出：

```sh
for bed in results/*/*/repeats.bed; do
  [ -f "$bed" ] || continue
  material_dir="${bed%/*}"
  python3 scripts/annotation_coverage.py --bed "$bed" \
    --lengths "$material_dir/lengths.tsv" --output "$material_dir/annotation_coverage.json"
done
```

该辅助程序仅用标准库SQLite；报告自动核验输入和脚本指纹后，分别展示总TE、已知类别和Unknown的区间并集覆盖度及片段长度总和。重叠区间只计一次；各类别并集仍可能相互重叠，不能简单相加。

每对完成后，独立回贴两侧侧翼，例如：

```sh
python3 scripts/validate_flanks.py \
  --manifest discovery/arabidopsis_pair.json --results results/arabidopsis \
  --minimap2 "$PWD/tools/minimap2-src/minimap2" --threads 4
python3 scripts/prioritize_candidates.py --results results/arabidopsis
python3 scripts/audit_gap_composition.py --results results/arabidopsis
python3 scripts/study_report.py --study-dir "$PWD" --output-dir reports/final
```

另外四对使用上表清单和对应 `results/<species>` 路径。`prioritize_candidates.py` 仅导出通过校验、已知类别的侧翼支持候选及基因上下文，生成 `priority_candidates.tsv`、`priority_loci.tsv`、`priority_summary.json`；不虚构生物学优先级或任取 top-N，同一缺口位点的片段在 loci 表汇总，仍不是已确认的 TE 插入事件。报告仅纳入校验有效的完成结果；未完成物种保持明确状态，不制造占位数值。报告使用 matplotlib 的无界面后端输出 PNG/SVG；无需图形桌面。

`audit_gap_composition.py` 是独立的补充审计，要求上述候选导出已完成且指纹校验通过，生成 `gap_composition.tsv` 和 `gap_composition_summary.json`。它将所有保留的归一化TE区间以及侧翼支持候选分别裁剪到每个缺口，计算各自的区间并集碱基数和占缺口长度的比例；按类别统计的并集可能重叠，不能相加，源注释中此前排除的类别仍不包括在内。该审计还检查精确坐标重复及两侧边界对应关系，不合并位点或推断生物学事件。可用 `--temporary-directory DIR` 指定SQLite临时目录。

报告会核验补充审计的来源/输出散列、指纹及计数后展示缺口TE覆盖比例和基因feature范围；缺失或无效的补充记录保持明确状态，不改变原始候选总数，也不补造数值。玉米配置的已声明、待验证、已应用或不完整状态同样单独呈现。

JSON中的 `gene_feature_scope` 明列原始GFF的feature计数。现有基因邻近分析只纳入精确 `feature=gene` 的记录；例如 `ncRNA_gene`、`pseudogene` 等其他类型不在该范围内，不能把结果解释成所有基因类型的完整注释。与gene-body的距离只描述坐标关系，不证明功能、表达或因果效应。

结果包括 `alignment.paf.gz`、实际对齐 `synteny.tsv`、`gaps.tsv`、逐候选证据、基因上下文、命令日志和输入/工具/输出指纹。`finish.done.json` 及侧翼 `done.json` 只有步骤成功且完整性检查通过才生成。

续跑会核对输入 stat、脚本/工具 SHA256 及结果指纹，移动旧结果、更改输入或脚本可能使成功标记失效。不要手改成功标记。仅修正注释而希望复用已有比对时，`reuse_alignment.py` 要求新目录已完成 prepare，并核验有序FASTA指纹、preset、threads、minimap2散列和既有命令；内容看似相同不是复用依据。

`complete_study.py` 是此次云工作区已有运行的续接调度器，依赖预先存在的原始大鼠完成记录和其他 prepare 记录，并会将原始重复注释的大鼠初步结果移到审计目录。它不是从零启动的通用入口；新工作目录使用上面的逐对命令。

## 结果能说明什么

TEvoX 的 `unique` 是与给定对齐覆盖区间**完全不重叠的 TE 注释片段**，不是已经证实的插入/缺失。流程根据 minimap2 CIGAR 提取实际对齐碱基，保留 insertion/deletion gaps，不以整个PAF跨度填满缺口。主比对默认 MAPQ≥30、对齐碱基≥10kb、一致率≥95%；每条候选TE注释片段至少80%的长度处于缺口内，且两侧各有≥1kb连续对齐证据。这个80%的分母是TE片段长度，**不表示缺口的80%由TE构成**；缺口中TE的实际占比由上述补充审计单独计算。N碱基、序列边缘及对侧空位点单独检查。

独立侧翼验证可支持更可信的候选，但唯一性受 minimap2 报告范围和阈值约束；仍不能确定祖先状态、插入方向、群体频率、调控作用或实验真实性。一个插入事件可能被注释成多个片段。跨物种注释库、完整度和基因模型不同，不用绝对候选数量比较“TE活性高低”。

## 测试

在已初始化工作目录、已构建 `tools/tevox` 和 `tools/minimap2-src/minimap2` 并安装报告依赖后：

```sh
python3 -m unittest discover -s scripts -p 'test_*.py'
python3 -m unittest discover -s tests -p 'test_*.py'
```

测试包含坐标、注释层级、CIGAR、来源下载完整性、重复注释处理、结果复用、合成真实minimap2侧翼映射及报告有效性。部分整体流程测试使用明确的 mock aligner，不是实际基因组验证；真实minimap2测试缺少工具时会跳过。初始化自身的两项测试从源码包执行：

```sh
python3 studies/published-genomes/tests/test_package_initialization.py
```

冻结源码包原有132项测试通过；新增间隙组成审计的7项测试已在源码包及含空格的迁移目录中单独通过，玉米启动器另有6项测试在迁移目录通过，其中包含真实minimap2的20kb合成序列比对；初始化的2项测试已针对文档复制重新通过。最终报告器的21项测试也在迁移目录通过，其中新增7项缺口组成与实际配置来源测试。报告本地链接修复另新增3项测试，生产与仓库副本的24项报告测试均通过；实际快照14个本地链接相对且可解析，JSON语义不变。总计155项不同测试，重复执行不重复计数。记录见 `package_validation.json` 与 `provenance/gap-composition-validation.json`；此次补充仅复测受影响的套件，未重新运行全部既有测试或全基因组分析。单独运行新增测试：

```sh
python3 scripts/test_audit_gap_composition.py
```
