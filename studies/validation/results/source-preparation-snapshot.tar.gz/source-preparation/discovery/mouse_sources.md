# Modern mouse genome comparison sources

Verified sources for two distinct strains in the published long-read Mouse Genomes Project, PRJEB47108. All raw downloads are preserved.

| Strain | Assembly | BioSample |
|---|---|---|
| C57BL/6NJ | GCA_921999865.2 (C57BL_6NJ_v3) | SAMEA9544183 |
| CAST/EiJ | GCA_921999005.2 (CAST_EiJ_v3) | SAMEA9544174 |

Publication: Helmy et al., *High-quality mouse reference genomes reveal the structural complexity of the murine protein-coding landscape*, Cell Genomics, DOI [10.1016/j.xgen.2025.101074](https://doi.org/10.1016/j.xgen.2025.101074), PMID 41330379. First online 2025-12-01; issue 2026-02-11.

The paper explicitly deposits the 17 long-read assemblies to PRJEB47108 and identifies CAST/EiJ and C57BL/6NJ; authoritative ENA accession records explicitly bind exact v3 versions to PRJEB47108. The main article does not print these accession.version or v3 strings.

## Exact downloaded input files

### C57BL/6NJ

| Input | Provider | Compressed bytes | Provider checksum |
|---|---|---:|---|
| [fasta](https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/921/999/865/GCA_921999865.2_C57BL_6NJ_v3/GCA_921999865.2_C57BL_6NJ_v3_genomic.fna.gz) | NCBI GenBank | 789,570,616 | MD5 `630ac3123b4938c90f0f2b927267b2b5` |
| [gene_gff3](https://ftp.ensembl.org/pub/release-115/gff3/mus_musculus_c57bl6nj/Mus_musculus_c57bl6nj.C57BL_6NJ_v3.115.gff3.gz) | Ensembl 115 | 20,844,108 | BSD sum 24914, 20356 blocks of 1024 bytes |
| [repeatmasker](https://hgdownload.soe.ucsc.edu/hubs/GCA/921/999/865/GCA_921999865.2/GCA_921999865.2.repeatMasker.out.gz) | UCSC GenArk | 147,025,938 | MD5 `c695318cc936b90860eb4eb4eb085c5a` |

Each local input has a `.provenance.json` recording original URL, file size, SHA256 and provider-checksum verification. Ensembl `CHECKSUMS` uses **BSD sum (`sum -r`)**, not MD5; both sum and 1024-byte block count passed verification.

### CAST/EiJ

| Input | Provider | Compressed bytes | Provider checksum |
|---|---|---:|---|
| [fasta](https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/921/999/005/GCA_921999005.2_CAST_EiJ_v3/GCA_921999005.2_CAST_EiJ_v3_genomic.fna.gz) | NCBI GenBank | 786,637,315 | MD5 `c90532d400f688a28d13e0b5e01cc25e` |
| [gene_gff3](https://ftp.ensembl.org/pub/release-115/gff3/mus_musculus_casteij/Mus_musculus_casteij.CAST_EiJ_v3.115.gff3.gz) | Ensembl 115 | 21,010,744 | BSD sum 12244, 20519 blocks of 1024 bytes |
| [repeatmasker](https://hgdownload.soe.ucsc.edu/hubs/GCA/921/999/005/GCA_921999005.2/GCA_921999005.2.repeatMasker.out.gz) | UCSC GenArk | 147,210,864 | MD5 `4aef58f16805d2eb51e2037f4b6e1bf0` |

Each local input has a `.provenance.json` recording original URL, file size, SHA256 and provider-checksum verification. Ensembl `CHECKSUMS` uses **BSD sum (`sum -r`)**, not MD5; both sum and 1024-byte block count passed verification.

Total raw compressed input: 1,912,299,585 bytes (1.781 GiB).

## Analysis scope and coordinate mapping

The authorized comparison uses **all complete primary nuclear chromosomes 1–19 and X** in each strain. No chromosome is sampled. Mitochondrial and unplaced sequences are excluded from derived FASTA, gene and repeat inputs, with counts and excluded records retained. This is primary nuclear genome scope, not every deposited scaffold.

Ensembl uses chromosome names 1–19/X; the NCBI FASTA and GenArk RepeatMasker use GenBank accession names. Derived GFF3 changes only sequence IDs and matching sequence-region directives using exact NCBI assembly-report and UCSC chromAlias mappings; coordinates and attributes remain intact. Primary chromosome lengths must agree across the full NCBI FASTA, its assembly report and Ensembl sequence-region directives.

C57BL/6NJ provides an explicit reason to omit mitochondria: Ensembl MT length is 16,299 bp while NCBI OW971572.1 is 16,300 bp. We do not force these mismatched coordinates together. CAST mitochondrial length agrees at 16,299 bp, but MT is excluded from both strains to preserve a common comparison scope.

## Repeat annotation comparability

Both GenArk annotations use RepeatMasker 4.1.4, RMBlast 2.13.0+, Dfam 3.6 and 1,395 selected families. Taxon options differ: C57BL/6NJ uses Mus musculus; CAST/EiJ uses Mus musculus castaneus. Exact selected family content was not independently compared, so these are not claimed to have identical settings. The Helmy paper reports a different RepeatMasker version (4.1.2-p1); the downloaded UCSC tracks are an independently documented annotation source.

## Publication and interpretation limits

- Paper Table 1 reports CAST contig N50 22.55 Mb and C57BL/6NJ 5.31 Mb, whereas ENA v3 records report 32.955239 and 8.304515 Mb. Paper statistics cover chromosomes 1–19 and X, but this alone has not been shown to explain the differences. Do not claim exact recreation of paper assemblies/statistics without supplementary-version confirmation.
- The assembly workflow uses de novo Falcon CLR contigs but RagTag chromosome organization guided by GRCm39 and Hi-C/manual curation. It is not wholly reference-independent.
- The old Lilue et al. 2018 paper supports the earlier short-read assemblies; use Helmy et al. DOI 10.1016/j.xgen.2025.101074 for this modern long-read project.
- Two strains do not establish population frequencies. TEvoX results are assembly-specific annotation-fragment candidates; reciprocal orthologous unique-flank evidence is needed to infer insertion/deletion events.

Machine-readable sources: `mouse_sources.json`. Download provenance: `../data/mouse/download_manifest.json`. Execution tuple: `../metadata/mouse_pair.json`. Exact selection counts, mapping, excluded records and selected-output SHA256 are recorded per strain in `../data/mouse/{c57,cast}/primary_selection.provenance.json`.

## Completed selection and record audits

| Strain | Whole nuclear chromosomes | Selected bases | Literal gene features | Selected repeat rows | Excluded sequences | Excluded repeat rows |
|---|---:|---:|---:|---:|---:|---:|
| C57BL/6NJ | 20 | 2,509,150,141 | 26,719 | 4,653,345 | 188 | 7,756 |
| CAST/EiJ | 20 | 2,514,319,647 | 26,198 | 4,656,338 | 127 | 6,887 |

Both GFF preflights passed with zero invalid gene rows and zero unknown sequence IDs. All primary sequence lengths match the exact NCBI assembly reports and Ensembl sequence-region directives. All GFF feature types are preserved; literal `gene` counts above exclude separately typed `ncRNA_gene` and `pseudogene` features. Stable Ensembl gene IDs remain available, though selected `gene` rows lack `Name`.

Bounded external-sort audits of all raw RepeatMasker records found zero whitespace-canonical full-record duplicates and zero repeated query/source-ID/start/end identities in either strain. Full-record comparison includes every field, the source ID and optional overlap marker. Primary files preserve source records without deduplication or overlap merging; they are strict subsets of the audited raw files. Per-strain `repeat_duplicate_audit.json`, `repeat_identity_audit.json` and selection provenance store counts, evidence and SHA256 hashes.
