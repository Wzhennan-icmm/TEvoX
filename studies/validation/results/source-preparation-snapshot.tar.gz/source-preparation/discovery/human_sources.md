# Human source pair

The pair is CHM13hTERT (`GCA_009914755.4`, BioSample `SAMN03255769`) versus the HG002/NA24385 maternal Q100 v1.1 haplotype (`GCA_018852615.3`, BioSample `SAMN03283347`). They represent different human samples. The exact URLs, source metadata, checksums, and local files are recorded in [human_sources.json](human_sources.json).

The associated publications are Nurk et al., *Science* 2022, [DOI 10.1126/science.abj6987](https://doi.org/10.1126/science.abj6987), PMID 35357919; and Hansen et al., *Cell* 2026, [DOI 10.1016/j.cell.2026.06.016](https://doi.org/10.1016/j.cell.2026.06.016). Author repositories and Crossref metadata support the citations. HG002 v1.1 is deliberately pinned to matching annotation assets, rather than substituting a newer project assembly.

## Sequence and annotation selection

All provider originals are preserved. The analysis copies retain nuclear chromosomes 1–22 and X only. CHM13 v2.0 includes a Y chromosome derived from HG002, so that chromosome cannot represent an independent CHM13 donor and is excluded. Both mitochondrial sequences are also excluded.

The HG002 NCBI FASTA uses GenBank CP accessions. The preparation script maps these headers to author annotation names such as `chr1_MATERNAL` using the exact assembly report; sequence bases and case are unchanged. Genes and repeats are filtered to the same 23 chromosome IDs and checked against their assembly lengths.

CHM13 JHU RefSeq Liftoff v5.2 genes were selected because this annotation was the source for HG002 Liftoff v0.6. The HG002 v1.1 repeat asset is a bigRmsk bigBed file with 14 fields. Field 14 contains comma-separated original RepeatMasker fragment rows. The workflow recovers those original aligned coordinates, not the browser visualization spans or joined spans that may contain gaps. The official UCSC `bigBedToBed` executable and its local SHA256 are recorded in `../metadata/human/bigBedToBed.provenance.json`.

The two repeat annotation software/library versions differ. These inputs support annotation-fragment candidate comparisons; they do not establish biological insertion polymorphisms or population frequencies.

## Completed checks

[human_extracted_pair.json](../metadata/human_extracted_pair.json) is the corrected runnable pair manifest. Per-assembly selection records in `../metadata/human/` contain sequence maps, excluded chromosomes, row counts, file SHA256 values, and per-sequence SHA256 values. Independent decompression confirmed that all selected FASTA bases, case, lengths, and chromosome IDs exactly match the hashes recorded while streaming the original FASTAs.

| Input | CHM13 | HG002 maternal |
|---|---:|---:|
| Selected nuclear chromosomes | 23 | 23 |
| Selected bases | 3,054,815,472 | 3,051,512,984 |
| GFF gene features | 60,619 | 59,555 |
| All repeat source fragments before TE class filtering | 5,512,424 | 5,422,582 |
| Exact duplicate fragments | 0 | 0 |

The HG002 fragment total comes from 4,480,264 browser records. Full-record audits compare every original source field, including identifiers and coordinates. Repeated ID/location/name/strand identities with different fields were also absent. No overlapping records or distinct identifiers were merged. These are annotation-fragment counts, not TE insertion event counts or directly comparable gene discovery rates.

All six assets were downloaded over HTTPS and their expected byte sizes checked. The two FASTAs passed their published MD5 checksums. Four annotation assets lack a published full-object checksum in the reviewed metadata; their source URLs, sizes, and local SHA256 values are retained. Multipart S3 ETags are not treated as MD5 values. The six raw assets total 2,682,581,872 bytes (2.498 GiB).

## Complex browser joins: required standalone extraction

The original browser asset contains **12,454 joined records with mixed fragment orientations**, involving 13,870 fragments whose strand differs from the browser display strand. A further single fragment extends one base left of its joined browser aligned-summary interval. Neither display strand nor that summary interval overrides the original RepeatMasker fragment fields.

Use `extract_bigrmsk_fragments.py` before normalization. It preserves all 5,422,582 original fragments from all 4,480,264 browser records, including overlapping fragments and optional RepeatMasker `*` markers. Every original query end plus its parenthesized remaining length was required to equal the exact selected FASTA chromosome length. All fragments pass this check and chromosome bounds. The one inconsistent aligned summary is explicitly recorded; no original coordinate is changed.

The [extraction provenance](../metadata/human/hg002_mat_fragment_extraction.json) records the detailed counts and examples. The gzip source map links every output record to its selected-BED physical line and description-fragment index, with the original browser ID recorded separately. Independent rereading verifies output fields, count/order, per-chromosome counts, sidecar identities, and the canonical fragment SHA256 `9f2060df71887f5f42b5d23027b7e5d32faff886f6593935359569ce7e5fe08c` against the original descriptions. The raw bigBed and selected bigRmsk remain intact.

The frozen direct bigRmsk normalizer assumes a common orientation within a browser record and rejects these complex joins. The corrected manifest supplies the extracted `repeatmasker-out` file instead. Five functional tests cover real mixed orientations/overlap, reverse-only fields, bounds and length errors, safe failed-output handling, explicit summary override, and compatibility with the frozen RepeatMasker parser.
