#!/usr/bin/env python3
"""Retain author GFF3 rows on the five downloaded chromosomes; preserve originals.
No coordinate or attribute edits. TE feature selection occurs in normalization,
so parent-child structures in each chromosome-filtered source remain intact.
"""
import collections
import gzip
import hashlib
import io
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DISC = ROOT / 'discovery'
DOWNLOADS = json.loads((DISC / 'arabidopsis_2025_downloads.json').read_text())
FEATURES = [
    'CACTA_TIR_transposon', 'Copia_LTR_retrotransposon',
    'Gypsy_LTR_retrotransposon', 'LINE_element', 'LTR_retrotransposon',
    'Mutator_TIR_transposon', 'PIF_Harbinger_TIR_transposon',
    'Tc1_Mariner_TIR_transposon', 'hAT_TIR_transposon', 'helitron',
]

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

qc = {'scope': 'Only the five chromosome sequences actually present in each downloaded FASTA. Raw source annotations are preserved.',
      'coordinates': 'GFF3 1-based inclusive; retained rows are byte-for-byte unchanged.',
      'retained_te_features_for_normalizer': FEATURES,
      'samples': {}}
for sample in ['nyl7', 'sq1']:
    entries = {d['role']: d for d in DOWNLOADS if d['sample'] == sample}
    lengths = entries['genome']['sequence_lengths']
    report = {'sequence_lengths': lengths, 'files': {}}
    for role in ['genes', 'repeats']:
        source = Path(entries[role]['local_path'])
        assert digest(source) == entries[role]['sha256'], source
        dest = source.parent / ('primary.' + role + '.gff3.gz')
        counts = collections.Counter()
        retained_features = collections.Counter()
        excluded_seqids = collections.Counter()
        excluded_features = collections.Counter()
        selected_features = collections.Counter()
        selected_classes = collections.Counter()
        with gzip.open(source, 'rt') as inp, dest.open('wb') as raw:
            with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
                with io.TextIOWrapper(gz, encoding='utf-8', newline='') as out:
                    for lineno, line in enumerate(inp, 1):
                        if line.startswith('##FASTA'):
                            raise ValueError(f'{source}:{lineno}: unexpected embedded FASTA')
                        if line.startswith('#') or not line.strip():
                            if line.startswith('##sequence-region') and line.split()[1] not in lengths:
                                counts['excluded_sequence_region_headers'] += 1
                                continue
                            out.write(line)
                            continue
                        parts = line.rstrip('\n').split('\t')
                        if len(parts) != 9:
                            raise ValueError(f'{source}:{lineno}: expected nine columns')
                        counts['source_rows'] += 1
                        if parts[0] not in lengths:
                            counts['excluded_nonprimary_rows'] += 1
                            excluded_seqids[parts[0]] += 1
                            excluded_features[parts[2]] += 1
                            continue
                        start, end = int(parts[3]), int(parts[4])
                        if not 1 <= start <= end <= lengths[parts[0]]:
                            raise ValueError(f'{source}:{lineno}: primary-chromosome bounds error')
                        counts['retained_primary_rows'] += 1
                        retained_features[parts[2]] += 1
                        out.write(line)
                        if role == 'repeats' and parts[2] in FEATURES:
                            counts['normalizer_selected_te_rows'] += 1
                            selected_features[parts[2]] += 1
                            attrs = dict(item.split('=', 1) for item in parts[8].split(';') if '=' in item)
                            if 'classification' not in attrs:
                                raise ValueError(f'{source}:{lineno}: selected TE missing classification')
                            selected_classes[attrs['classification']] += 1
                            if 'Parent' in attrs:
                                counts['normalizer_selected_te_rows_with_parent'] += 1
        excluded_by_normalizer = {f: n for f, n in retained_features.items() if f not in FEATURES} if role == 'repeats' else {}
        report['files'][role] = {
            'source_path': str(source), 'source_sha256': entries[role]['sha256'],
            'filtered_path': str(dest), 'filtered_bytes': dest.stat().st_size,
            'filtered_sha256': digest(dest), 'counts': dict(counts),
            'retained_feature_counts': dict(retained_features),
            'excluded_nonprimary_seqid_counts': dict(excluded_seqids),
            'excluded_nonprimary_feature_counts': dict(excluded_features),
            'normalizer_excluded_primary_feature_counts': excluded_by_normalizer,
            'normalizer_selected_te_feature_counts': dict(selected_features),
            'normalizer_selected_te_classification_counts': dict(selected_classes),
            'primary_coordinate_bounds_errors': 0,
        }
    qc['samples'][sample] = report
(DISC / 'arabidopsis_2025_primary_filter_qc.json').write_text(json.dumps(qc, indent=2) + '\n')
for sample, report in qc['samples'].items():
    print(sample, {role: data['counts'] for role, data in report['files'].items()})
