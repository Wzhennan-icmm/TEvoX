# Rat source pair: Brown Norway vs stroke-prone spontaneously hypertensive rat

Verified 2026-10-03. Two distinct **published strains**, each with a matched FASTA, gene GFF3, and RepeatMasker annotation from NCBI RefSeq. Subsequent authorized download completed: all six inputs passed the exact upstream MD5 checks; local SHA256 and URL provenance are recorded in `../data/rat/download_manifest.json`.

| Strain | RefSeq assembly | Matched GenBank | BioSample | Publication |
|---|---|---|---|---|
| BN/NHsdMcwi | GCF_036323735.1 (GRCr8) | GCA_036323735.1 | SAMN38730095 | [DOI 10.1101/gr.279292.124](https://doi.org/10.1101/gr.279292.124), PMID 39516046 |
| SHRSP/BbbUtx | GCF_021556685.1 (SHRSP_T2T) | GCA_021556685.2 | SAMN24538170 | [DOI 10.1016/j.xgen.2026.101281](https://doi.org/10.1016/j.xgen.2026.101281), PMID 42561951 |

Both assemblies are male and haploid representations. GRCr8 paper verifies BN/NHsdMcwi identity; SHRSP T2T paper verifies SHRSP/BbbUtx identity (RGD_8142383), newborn male kidney material for Oxford Nanopore and an 18-week male for HiFi/Hi-C. Exact accessions, samples and correspondence are also confirmed by downloaded NCBI assembly reports.

## Download-ready files

Use pinned NCBI annotation-release directories below. Their `md5checksums.txt` files were downloaded and were byte-identical to checksums in the current assembly directories. All six large files returned HTTP 200 to HEAD; metadata and full-text evidence returned HTTP 200 to GET. Download-time verification has now completed successfully against those exact checksums.

### BN: GCF_036323735.1

Release: [GCF_036323735.1-RS_2026_08](https://ftp.ncbi.nlm.nih.gov/genomes/all/annotation_releases/10116/GCF_036323735.1-RS_2026_08/)

| Input | Size (bytes compressed) | NCBI MD5 |
|---|---:|---|
| [fasta](https://ftp.ncbi.nlm.nih.gov/genomes/all/annotation_releases/10116/GCF_036323735.1-RS_2026_08/GCF_036323735.1_GRCr8_genomic.fna.gz) | 875,872,536 | `f7f47214cb2b7987c2edc85b3d3a10c5` |
| [gene_gff3](https://ftp.ncbi.nlm.nih.gov/genomes/all/annotation_releases/10116/GCF_036323735.1-RS_2026_08/GCF_036323735.1_GRCr8_genomic.gff.gz) | 37,442,693 | `06f108ab9641f498f9734642166d926e` |
| [repeatmasker](https://ftp.ncbi.nlm.nih.gov/genomes/all/annotation_releases/10116/GCF_036323735.1-RS_2026_08/GCF_036323735.1_GRCr8_rm.out.gz) | 141,528,731 | `6b4bd557a65fc2333ef58304873375d2` |

Checksums: https://ftp.ncbi.nlm.nih.gov/genomes/all/annotation_releases/10116/GCF_036323735.1-RS_2026_08/md5checksums.txt

### SHRSP: GCF_021556685.1

Release: [GCF_021556685.1-RS_2026_08](https://ftp.ncbi.nlm.nih.gov/genomes/all/annotation_releases/10116/GCF_021556685.1-RS_2026_08/)

| Input | Size (bytes compressed) | NCBI MD5 |
|---|---:|---|
| [fasta](https://ftp.ncbi.nlm.nih.gov/genomes/all/annotation_releases/10116/GCF_021556685.1-RS_2026_08/GCF_021556685.1_SHRSP_T2T_genomic.fna.gz) | 874,852,829 | `c43259b81984db675c3a71166a7686f3` |
| [gene_gff3](https://ftp.ncbi.nlm.nih.gov/genomes/all/annotation_releases/10116/GCF_021556685.1-RS_2026_08/GCF_021556685.1_SHRSP_T2T_genomic.gff.gz) | 41,562,811 | `26688479d7493e686a7b06a674ec34bd` |
| [repeatmasker](https://ftp.ncbi.nlm.nih.gov/genomes/all/annotation_releases/10116/GCF_021556685.1-RS_2026_08/GCF_021556685.1_SHRSP_T2T_rm.out.gz) | 157,958,167 | `9d3df43b8cffc959663c8dfa69e7c0b1` |

Checksums: https://ftp.ncbi.nlm.nih.gov/genomes/all/annotation_releases/10116/GCF_021556685.1-RS_2026_08/md5checksums.txt

Total compressed download: **2,129,217,767 bytes (1.983 GiB)**. Combined uncompressed FASTA sequence length is 5,705,042,389 bp; alignment indexes, text overhead and outputs require additional space.

## Annotation comparability

Both NCBI `rm.run` files are byte-identical: RepeatMasker 4.1.5, RMBlast 2.14.1+, CONS-Dfam_3.7, sensitive mode, taxon Rattus norvegicus, `-no_is -cutoff 255`. Both gene annotations are pinned to August 2026 RefSeq releases. This avoids mixing repeat library versions between the two genomes.

## Interpretation and provenance cautions

- RefSeq and GenBank assembly sequences are marked non-identical for each genome; use all three inputs from the same GCF release directory.
- GCF_021556685.1 corresponds to GCA_021556685.2 (the 2026 T2T assembly), not GCA_021556685.1 (the prior 2023-paper HiFi assembly).
- SHRSP_T2T is the assembly name; the paper reports 16 of 22 chromosomes assembled without gaps, seven gaps total. It is not a fully gapless genome.
- The 2026 paper used RepeatMasker 4.1.8 with GIRI Rattus motifs, whereas the selected matched NCBI tracks use 4.1.5 plus Dfam 3.7 for both assemblies. Do not present NCBI-track statistics as reproducing the paper RepeatMasker counts.
- Male strain assemblies differ in technical completeness and ancestral background. Assembly-specific TE candidates need unique orthologous flank evidence before being called strain-specific insertions/deletions.

The 2023 SHRSP publication (DOI 10.1161/HYPERTENSIONAHA.122.20140, PMID 36330812) concerns the earlier HiFi assembly. The selected T2T assembly is supported by the 2026 Cell Genomics publication above. The distinct SHR/Utx assembly GCA_023515785.2 was also verified, but its GenBank directory lacks gene/repeat annotations; the selected SHRSP pair supplies a complete matched input trio.

Machine-readable manifest: `rat_sources.json`. Primary evidence: `rat/BN_assembly_report.txt`, `rat/SHRSP_assembly_report.txt`, `rat/*_release_md5checksums.txt`, `rat/*_rm.run`, `rat/*_annotation_report.xml`, `rat/grcr8_fulltext.xml`, `rat/rat_t2t_fulltext.xml`. Discovery fetch provenance is retained in `rat/*fetches.json` and `rat/artifact_probe.json`.

No scientific comparison or TE candidate count has been computed in this discovery task.

## Upstream annotation duplication and corrected analysis input

The published-checksum-verified SHRSP RepeatMasker source contains 9,119,000 record rows. A full audit found exactly two consecutive copies of every one of 4,559,500 distinct complete records, with no remaining nonconsecutive matches. Provider checksum verification therefore establishes file identity but does not establish annotation quality.

Use [rat_corrected_pair.json](../metadata/rat_corrected_pair.json), which replaces only the SHRSP repeat input with the derived `GCF_021556685.1_SHRSP_T2T_rm.deduplicated.out.gz`. The raw provider file is unchanged. The removal rule compares all original fields after whitespace normalization; no overlapping distinct fragments are merged. [rat_shrsp_repeat_dedup.json](../metadata/rat_shrsp_repeat_dedup.json) records counts, the complete multiplicity histogram, source/output SHA256 values, and a source-line group map.
