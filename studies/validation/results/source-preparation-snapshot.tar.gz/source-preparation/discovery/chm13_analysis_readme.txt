File descriptions:

 * chm13v2.0.fa.gz: CHM13 v2.0 assembly (AC:GCA_009914755.4) with sequences
   soft-masked by the T2T team and sequence names converted to chr*. chrY in
   this file was assembled from sample HG002/NA24385. The original sequence
   accession numbers are shown in the FASTA header.

 * chm13v2.0_noY.fa.gz: excluding the Y chromosome. This file only contains
   sequences derived from the CHM13 cell line.

 * chm13v2.0_PAR.bed: pseudoautosomal regions (PARs)

 * chm13v2.0_maskedY.fa.gz: PARs on chrY hard masked to "N"

 * chm13v2.0_maskedY.rCRS.fa.gz: PARs on chrY hard masked to "N" and mitochodrion
   replaced with rCRS (AC:NC_012920.1)

Sep. 28, 2022 Udate: re-compressed with bgzip

md5sum
06caded0055ec647a69acb708e13beff  chm13v2.0.fa.gz
bd90ddb80c86af7fcfeefe7a0909b175  chm13v2.0_maskedY.fa.gz
b17cd2bdd8eb5544e195d6a8882e417b  chm13v2.0_maskedY_rCRS.fa.gz
db44930f8db1d70f50c8eb130dbc0713  chm13v2.0_noY.fa.gz
