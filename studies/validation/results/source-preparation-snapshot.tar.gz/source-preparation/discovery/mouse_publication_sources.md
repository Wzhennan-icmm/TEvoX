# Modern mouse assembly publication evidence

Helmy et al., **High-quality mouse reference genomes reveal the structural complexity of the murine protein-coding landscape**, Cell Genomics. DOI [10.1016/j.xgen.2025.101074](https://doi.org/10.1016/j.xgen.2025.101074); PMID **41330379**; PMCID **PMC12903361**. First online **2025-12-01**, journal collection **2026-02-11**.

The paper describes 17 long-read strain assemblies and explicitly includes both CAST/EiJ and C57BL/6NJ. Its data-availability statement deposits the assemblies under **PRJEB47108**, with genome annotations available from the Ensembl Mouse Genomes project. ENA exact assembly XML provides the following binding:

| Strain | Exact assembly | Version label | BioSample | ENA study |
|---|---|---|---|---|
| CAST/EiJ | GCA_921999005.2 | CAST_EiJ_v3 | SAMEA9544174 | PRJEB47108 |
| C57BL/6NJ | GCA_921999865.2 | C57BL_6NJ_v3 | SAMEA9544183 | PRJEB47108 |

Both ENA records identify PacBio, falcon-kit 1.8.1, and 40-fold coverage. Both NCBI assembly reports date the assembly to 2022-07-01.

**Strength of the publication link:** publication → named strains and deposited project → exact ENA v3 accession records. The main article does not explicitly print these v3/accession-version strings. This supports describing them as published Mouse Genomes Project long-read assemblies associated with Helmy et al.; it does not prove that every exact release artifact reproduces the paper's calculation inputs.

**Version/statistics qualification:** paper Table 1 gives contig N50 22.55 Mb for CAST/EiJ and 5.31 Mb for C57BL/6NJ. Exact ENA v3 records give 32.955239 and 8.304515 Mb. Table 1 excludes sequences outside chromosomes 1–19 and X, but this alone is not established as the explanation. Do not claim direct reproduction of publication statistics until supplementary/version evidence resolves this difference.

**Assembly method qualification:** Falcon de novo CLR contigs were polished and scaffolded using long-range data; the methods then arrange scaffolds into chromosomes with RagTag using GRCm39 as guide, followed by Hi-C/manual curation. These are modern long-read assemblies, with reference-guided chromosome organization.

Use this modern Helmy paper rather than Lilue et al. 2018 (the earlier short-read project) to support modern long-read assembly provenance. The peer-reviewed paper reports RepeatMasker 4.1.2-p1 for its analysis; source-specific downloaded annotation metadata must still determine the actual RepeatMasker version used in a new comparison.

Evidence files are retained under `mouse_publication/`: `modern_mouse_fulltext.xml`, `crossref_modern.json`, `ena_project.xml`, `ena_cast_v3.xml`, `ena_c57bl6nj_v3.xml`, and both `*_v3_ncbi_report.txt` files. Machine-readable extracts: `mouse_publication_sources.json`.
