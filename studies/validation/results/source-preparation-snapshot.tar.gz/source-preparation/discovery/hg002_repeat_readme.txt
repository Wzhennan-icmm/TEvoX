Description

Repetitive genomic elements including Transposable Element (TE) families, Satellite, Short Tandem Repeats,
and low complexity DNA as annotated by RepeatMasker.  These tracks were constructed with the NCBI BLAST-derived search engine RMBlast and Dfam 3.6
database (plus T2T-CHM13-derived entries with updated taxonomic labels, originally
released in April 2022, and HG002 chrY-derived and XY T2T-primates entries not yet submitted).

Individual tracks are identified using the three main components of the analysis, the version of RepeatMasker,
the search engine used, and finally the repeat library version.

 * RepeatMasker version March 23 2023 open-4.1.5
 * Search Engine: RMBlast (-e ncbi) [ 2.13.0+ (November 2022) ]
 * RepeatMasker Database: Dfam_3.6 (plus T2T-CHM13-derived entries with updated taxonomic labels, originally
released in April 2022, and the HG002 chrY-derived and XY T2T-primates entries not yet submitted)

Methods

The RepeatMasker (<a href="www.repeatmasker.org">www.repeatmasker.org</a>) tool rmToTrackHub.pl was used to generate the datasets found on this track hub.  

References

Smit AFA, Hubley R, Green P. <em>RepeatMasker Open-3.0</em>.
<a href="http://www.repeatmasker.org" target="_blank">
http://www.repeatmasker.org</a>. 1996-2010.

For the methodology related to the discovery of the T2T-CHM13-, HG002-chrY- and XY ape-derived repeats in this track, including scripts, are available here: 

Hoyt SJ, et al.
<a href="https://www.science.org/doi/10.1126/science.abk3112" target="_blank">
From telomere to telomere: the transcriptional and epigenetic state of human repeat elements</a>.
<em>Science</em>. 2022 Apr 1.
 
Hoyt SJ, et al.
<a href="https://zenodo.org/record/5537106" target="_blank">
From telomere to telomere: the transcriptional and epigenetic state of human repeat elements analysis code: T2T-CHM13</a>.
<em>Science</em>. 2022 Apr 1.   

Rhie A, et al.
<a href="https://www.nature.com/articles/s41586-023-06457-y" target="_blank">
The complete sequence of a human Y chromosome</a>.
<em>Nature</em>. 2023 Aug 23.

Makova K, et al.
<a href="https://www.biorxiv.org/content/10.1101/2023.11.30.569198v2" target="_blank">
The Complete Sequence and Comparative Analysis of Ape Sex Chromosomes</a>.
<em>bioRxiv</em>. 2024 Feb 24.

Dfam is described in:

Wheeler TJ, Clements J, Eddy SR, Hubley R, Jones TA, Jurka J, Smit AF, Finn RD.
<a href="https://academic.oup.com/nar/article/41/D1/D70/1073076/Dfam-a-database-of-repetitive-DNA-
based-on-profile" target="_blank">
Dfam: a database of repetitive DNA based on profile hidden Markov models</a>.
<em>Nucleic Acids Res</em>. 2013 Jan;41(Database issue):D70-82.
PMID: <a href="https://www.ncbi.nlm.nih.gov/pubmed/23203985" target="_blank">23203985</a>; PMC: <a
href="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3531169/" target="_blank">PMC3531169</a>

Repbase Update is described in:

Jurka J.
<a href="https://www.sciencedirect.com/science/article/pii/S016895250002093X" target="_blank">
Repbase Update: a database and an electronic journal of repetitive elements</a>.
<em>Trends Genet</em>. 2000 Sep;16(9):418-420.
PMID: <a href="https://www.ncbi.nlm.nih.gov/pubmed/10973072" target="_blank">10973072</a>

For a discussion of repeats in mammalian genomes, see:

Smit AF.
<a href="https://www.sciencedirect.com/science/article/pii/S0959437X99000313" target="_blank">
Interspersed repeats and other mementos of transposable elements in mammalian genomes</a>.
<em>Curr Opin Genet Dev</em>. 1999 Dec;9(6):657-63.
PMID: <a href="https://www.ncbi.nlm.nih.gov/pubmed/10607616" target="_blank">10607616</a>

Smit AF.
<a href="https://www.sciencedirect.com/science/article/pii/S0959437X9680030X" target="_blank">
The origin of interspersed repeats in the human genome</a>.
<em>Curr Opin Genet Dev</em>. 1996 Dec;6(6):743-8.
PMID: <a href="https://www.ncbi.nlm.nih.gov/pubmed/8994846" target="_blank">8994846</a>
