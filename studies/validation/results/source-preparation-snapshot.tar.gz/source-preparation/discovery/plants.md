# 植物数据来源与选择

## 已就绪：拟南芥 Nyl-7 与 Sq-1

选择两个不同自然材料，使用同一作者发布平台的组装、基因和 EDTA 注释。执行清单为 `arabidopsis_pair.json`；原始下载记录及本地 SHA256 为 `arabidopsis_2025_downloads.json`。这不是同一材料不同组装版本之间的比较。

论文：Igolkina et al. (2025), *A comparison of 27 Arabidopsis thaliana genomes and the path toward an unbiased characterization of genetic polymorphism*, Nature Genetics 57:2289–2301. DOI：[10.1038/s41588-025-02293-0](https://doi.org/10.1038/s41588-025-02293-0)。作者项目页和 Crossref 元数据均已核对，原证据保存在 `new27_*` 文件。

| 本地 ID | 材料 | 作者 accession ID | 作者 assembly ID | CS 编号 | FASTA 总长度 |
| --- | --- | --- | --- | --- | --- |
| nyl7 | Nyl-7 | 6069 | 100267 | CS77137 | 119,736,059 bp |
| sq1 | Sq-1 | 6966 | 100271 | CS77266 | 120,282,246 bp |

材料映射来自作者公开 JSON：<https://1001genomes.org/json/phase1_assemblies_table.json>，本地保存 `new27_accession_manifest.json`。材料组装版本为 **v2.1**，基因注释为 **genes_v05**，TE 文件为作者 **EDTA.TEanno.gff3**，不是 UCSC 补算的 RepeatMasker 数据。

固定发布目录：<https://1001genomes.org/data/1001Gp/27genomes/releases/2026_03_14/>。作者 changelog 记载该次发布增加 SV 数据；现用组装/注释文件的服务器修改日期为 2024 年 2 月。发布日期不是组装版本。部分小文件最初通过 `current` 下载，其固定日期 URL 的长度和 ETag 已核对一致；FASTA 直接从固定日期目录下载。

全部八个原始输入已下载（约 81 MB 压缩）；完整解压读取的 gzip CRC 通过，FASTA 序列长度与作者 `.fai` 一致。在已查看的官方目录中没有发现提供方校验和清单，故不能宣称已核验作者 MD5；本地 SHA256 均记录在下载清单。

### 分析范围与坐标

每个 FASTA 含五条 `6069_Chr1`–`6069_Chr5` 或 `6966_Chr1`–`6966_Chr5` 序列。TE 注释还含未定位 scaffold；已依据 FASTA seqID 生成 `primary.genes.gff3.gz` 与 `primary.repeats.gff3.gz`，不改原文件、不改保留行的坐标/属性，且保留完整 chromosome 内 GFF 层级。复现脚本为 `filter_arabidopsis_primary.py`，详细 QC 为 `arabidopsis_2025_primary_filter_qc.json`。

| QC | Nyl-7 | Sq-1 |
| --- | --- | --- |
| 保留 gene/mRNA/exon 原行 | 192,444 | 194,179 |
| 其中 gene 行 | 29,648 | 29,843 |
| 排除未定位 TE 注释行 | 5,519 | 4,648 |
| 保留 chromosome TE 注释原行（含层级） | 31,843 | 30,332 |
| normalizer 明确选择的 TE 行 | 24,779 | 23,231 |
| normalizer 排除 repeat_region 行 | 6,030 | 6,061 |
| normalizer 排除 long_terminal_repeat 行 | 518 | 520 |
| normalizer 排除 target_site_duplication 行 | 516 | 520 |
| 保留行坐标越界 | 0 | 0 |

GFF3 坐标是 **1-based inclusive**；normalizer 仅将 start 减 1，产生 0-based half-open BED。明确保留的 feature 为 `CACTA_TIR_transposon`, `Copia_LTR_retrotransposon`, `Gypsy_LTR_retrotransposon`, `LINE_element`, `LTR_retrotransposon`, `Mutator_TIR_transposon`, `PIF_Harbinger_TIR_transposon`, `Tc1_Mariner_TIR_transposon`, `hAT_TIR_transposon`, `helitron`。不得仅凭 `Parent` 字段删行：有 Parent 的完整结构 LTR 元件仍须保留；wrapper、LTR 子片段和 TSD 子片段不重复计数。

`repeat_region` 同时包括 LTR wrapper 与 Unknown 重复。因此当前策略还排除了不能明确归入 TE feature 的 Unknown 区段；结果范围应表述为上述明确 TE 注释片段，不能宣称覆盖所有重复序列或证明全部 TE 插入事件。

分类属性键为小写 **`classification`**。EDTA 的 `Name=TE_...` 在两个样本间不可直接充当同源家族 ID：共有 520 个相同 Name 字符串，其中 339 个分类不同。跨样本汇总只用作者 classification 给出的类/超家族层级，保留原始 repeat_name 供追溯，不能据重复名称相同推断家族同源。

## 已就绪：玉米 B73 与 Oh43

Hufford et al. (2021), *De novo assembly, annotation, and comparative analysis of 26 diverse maize genomes*, Science 373(6555):655–662. DOI：[10.1126/science.abg5289](https://doi.org/10.1126/science.abg5289)，已通过 Crossref 核验，证据为 `plant_crossref_maize.metadata`。B73 与 Oh43 是同一 NAM 26 基因组研究的不同自交系，材料身份和组装号另由提供方 assembly report 交叉核对。

作者仓库：<https://github.com/HuffordLab/NAM-genomes>。原计划 B73/B97 的作者 Pan-EDTA 数据受 MaizeGDB 源站 Cloudflare403 和 Gramene/CyVerse 当前访问限制影响，未取得可验证下载。当前实际使用可完整获取的 **UCSC GenArk B73/Oh43**：基因组来自发表的 NAM 组装，重复与基因注释由 UCSC 补算，**不称为作者 Pan-EDTA 或 NAM 高置信基因集**。

| 输入 | B73 | Oh43 |
| --- | --- | --- |
| 组装号 | GCF_902167145.1 | GCA_902167015.1 |
| 组装名称 | Zm-B73-REFERENCE-NAM-5.0 | Zm-Oh43-REFERENCE-NAM-1.0 |
| 分布 FASTA 长度 | 2,182,786,008 bp | 2,176,495,488 bp |
| FASTA 序列数（含未定位） | 687 | 757 |
| 原始 RepeatMasker 行数 | 1,340,546 | 1,341,831 |
| Augustus gene_id 组数 | 141,726 | 141,456 |

官方源目录：

- B73：<https://hgdownload.soe.ucsc.edu/hubs/GCF/902/167/145/GCF_902167145.1/>
- Oh43：<https://hgdownload.soe.ucsc.edu/hubs/GCA/902/167/015/GCA_902167015.1/>

执行清单 `maize_pair.json` 使用 `asm20`，不降低分析的 95% alignment identity 门槛。六个原文件均已下载并核对提供方 `md5sum.txt`，同时保存本地 SHA256、完整 gzip CRC、FASTA 与提供方 chrom.sizes 的逐序列长度一致性。所有 RepeatMasker 和 GTF 坐标检查通过。输入清单 `maize_genark_downloads.json` 保存每个精确 URL、checksum URL、散列与文件头；所有源文件保留。

FASTA、RepeatMasker 和 GTF 原生 seqID 已匹配：B73 使用 NC_050096.1 等 RefSeq accession，Oh43 使用 LR616642.1 等 GenBank accession。没有推测式重命名；提供方 assembly report 和 chromAlias 另作来源留存。使用完整分布 FASTA，包括染色体及未定位 scaffold。

### 重复注释限制

两套提供方版本文件均记录 RepeatMasker **open-4.0.8**、wublast、`-species 'zea mays' -s -no_is -cutoff 255`，共同库为 **Dfam_Consensus-20181026 / RepBase-20181026**。Oh43 另明确列 `-frag 20000`，B73 版本说明未列这一参数。因此可以比较使用同一重复库的注释结果，但片段边界及差异仍可能受参数、库版本和组装质量影响。此注释不是作者使用共同泛基因组 TE 库的 Pan-EDTA 结果。

RepeatMasker `.out` query 坐标为 1-based inclusive，normalizer 执行唯一一次 start 减 1，按明确类别剔除 Satellite、Simple_repeat 等非 TE。结果是注释片段差异，不能直接等同于独立插入事件或确定祖先状态。

### 基因信息仅作预测区域的描述性上下文

两套源文件为 UCSC **AUGUSTUS ab initio predictions**。官方 track 描述写版本 3.1，但通用训练物种表未指定玉米模型，故该模型仍标记未核实。不得把这些预测称为 NAM 原文的约四万高置信基因。

`scripts/gtf_predicted_genes.py` 按精确 `gene_id` 聚合 exon，生成 `min(exon start)..max(exon end)` 的预测 gene-body GFF3。原始1-based坐标与链保持不变；同一 gene_id 如跨染色体、跨链或 source 不一致则失败，缺少 exon 或越界同样失败。输出 `ID` 加样本前缀，明确标记 `prediction_status=ab_initio`；不合并相邻基因，不以 transcript/CDS/codon 数目代替基因数。六项测试覆盖这些规则及属性转义，实际转换 QC 为 `maize_b73_gene_conversion.json` 和 `maize_oh43_gene_conversion.json`。

每个材料约14.1万个未筛选预测 gene_id，明显多于高置信玉米基因集；可能包含错误及 TE 相关预测。候选 TE 到这些区域的距离只能描述预测模型的邻近关系，不能证明表达改变、功能影响、调控作用或实验验证的基因关联。

另核对 Mo17 T2T 的 GCA_022117705.1：NCBI 实际目录没有基因 GFF 或 RepeatMasker `.out`，配对 RefSeq 为 na，未作为更强基因注释后备采用。

## 未选择的 AMPRIL 2020 方案

早期考察 Jiao & Schneeberger (2020), DOI 10.1038/s41467-020-14779-y 的 Ler/Cvi（组装 v2.0、基因 v2.5）。公开目录提供 FASTA 与基因，尚未找到同版本作者 TE 数据，因此未选择。作者 GitHub 中 `Col.syn.all.coords.txt2` 是七组比较的共有核心交集，不能当作 Ler/Cvi 完整两两共线性。该方案仅保留为溯源记录。
