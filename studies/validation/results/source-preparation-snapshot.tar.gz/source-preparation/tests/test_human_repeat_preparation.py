import copy
import importlib.util
from pathlib import Path
import unittest

SPEC = importlib.util.spec_from_file_location('prepare_human_repeat_inputs', Path(__file__).resolve().parents[1] / 'scripts' / 'prepare_human_repeat_inputs.py')
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class HumanRepeatManifestTests(unittest.TestCase):
    def setUp(self):
        self.manifest = {'genomes': [
            {'id': 'chm13', 'repeats': '/study/chm13.bed', 'repeat_format': 'te-bed'},
            {'id': 'hg002_mat', 'repeats': '/study/hg002.bed.gz', 'repeat_format': 'ucsc-bigrmsk-bed', 'normalize_args': []}]}
        self.provenance = {'status': 'passed', 'independent_output_reread_passed': True, 'independent_source_map_reread_passed': True, 'input': '/study/hg002.bed.gz', 'output': '/study/hg002.out.gz', 'source_map': '/study/source-map.tsv.gz', 'canonical_source_fragment_sha256': 'abc', 'canonical_output_fragment_sha256': 'abc', 'counts': {'output_fragment_records': 2, 'query_length_verified_fragments': 2, 'source_browser_records': 1, 'mixed_strand_source_records': 1, 'display_strand_mismatch_fragments': 1, 'aligned_summary_mismatch_source_records': 0, 'fragments_outside_aligned_summary': 0}}

    def test_only_hg002_repeat_input_changes(self):
        original = copy.deepcopy(self.manifest['genomes'][0])
        result = MODULE.update_manifest(self.manifest, self.provenance, Path('/study/provenance.json'))
        self.assertEqual(result['genomes'][0], original)
        self.assertEqual(result['genomes'][1]['repeat_format'], 'repeatmasker-out')
        self.assertEqual(result['genomes'][1]['repeat_source_original'], '/study/hg002.bed.gz')
        self.assertEqual(result['genomes'][1]['repeats'], '/study/hg002.out.gz')

    def test_wrong_source_or_unvalidated_extraction_refused(self):
        for changes in [{'input': '/study/another.bed'}, {'status': 'failed'}, {'independent_output_reread_passed': False}, {'independent_source_map_reread_passed': False}, {'canonical_output_fragment_sha256': 'different'}]:
            provenance = dict(self.provenance, **changes)
            with self.assertRaises(ValueError):
                MODULE.update_manifest(copy.deepcopy(self.manifest), provenance, Path('/study/provenance.json'))

    def test_query_length_coverage_required(self):
        self.provenance['counts']['query_length_verified_fragments'] = 1
        with self.assertRaisesRegex(ValueError, 'every output fragment'):
            MODULE.update_manifest(self.manifest, self.provenance, Path('/study/provenance.json'))

    def test_repeated_conversion_refused(self):
        self.manifest['genomes'][1]['repeat_format'] = 'repeatmasker-out'
        with self.assertRaisesRegex(ValueError, 'freshly prepared'):
            MODULE.update_manifest(self.manifest, self.provenance, Path('/study/provenance.json'))


if __name__ == '__main__':
    unittest.main()
