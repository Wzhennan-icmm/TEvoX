import argparse
import copy
import csv
import json
from pathlib import Path
import sys
import tempfile
import unittest

SCRIPTS=Path(__file__).resolve().parents[1]/'scripts'
sys.path.insert(0,str(SCRIPTS))
import prioritize_candidates as pc


class PriorityTests(unittest.TestCase):
    def setUp(self):
        self.manifest=dict(pair_id='pair',genomes=[dict(id='a',material='A',assembly='a.1'),dict(id='b',material='B',assembly='b.1')])
        self.locus=dict(genome='1',locus_id='locus1',alignment_id='aln1',source_chrom='chrA',source_gap_start0='1000',source_gap_end0='2000',opposite_chrom='chrB',opposite_empty_site0='1000',alignment_strand='+',status=pc.SUPPORTED,fragment_ids_json='["f1","f2"]')

    def fragment(self,fid,side='1',geneids=('g1',),distance=0,cls='DNA'):
        chrom='chrA' if side=='1' else 'chrB'
        other='chrB' if side=='1' else 'chrA'
        evidence=dict(fragment_id=fid,category='anchored_gap_candidate',selected_alignment_id='aln1',chrom=chrom,start1='1001',end1='1500',strand='+',repeat_name='TE_'+fid,canonical_class=cls,repeat_family='hAT',classification_note='explicit_source_class',gap_start0='1000',gap_end0='2000',opposite_chrom=other,opposite_empty_site0='1000',alignment_strand='+')
        gene={k:evidence[k] for k in ('fragment_id','chrom','start1','end1','strand','repeat_name','canonical_class','repeat_family')}
        for prefix in ('overlap','nearest'):
            ids=list(geneids) if prefix=='nearest' or distance==0 else []
            gene[prefix+'_gene_ids_json']=json.dumps(ids)
            gene[prefix+'_gene_names_json']=json.dumps(['Gene '+g for g in ids])
        gene.update(nearest_gene_body_distance_bp=str(distance),gene_annotation_status='overlap' if distance==0 else 'nearest')
        return (side,evidence),(side,gene)

    def build(self,loci,fragments):
        return pc.build_tables(self.manifest,loci,[p[0] for p in fragments],[p[1] for p in fragments])

    def test_many_fragments_one_gap_unions_gene_ids_preserves_context(self):
        candidates,loci,counts=self.build([self.locus],[self.fragment('f1',geneids=('g1','g2')),self.fragment('f2',geneids=('g2','g3'),distance=12)])
        self.assertEqual(counts['candidate_fragments'],2)
        self.assertEqual(counts['alignment_gap_loci'],1)
        self.assertEqual(loci[0]['fragment_count'],2)
        self.assertEqual(json.loads(loci[0]['nearest_gene_ids_json']),['g1','g2','g3'])
        self.assertEqual(json.loads(loci[0]['overlap_gene_ids_json']),['g1','g2'])
        context=json.loads(loci[0]['fragment_gene_context_json'])
        self.assertEqual(context['f2']['nearest_gene_body_distance_bp'],'12')
        self.assertEqual(len(candidates),2)

    def test_real_arabidopsis_manifest_dictionary_material_labels(self):
        # Exact identity/version fields from the author-derived study manifest.
        self.manifest.update(assembly_version='v2.1')
        self.manifest['genomes']=[
            dict(id='nyl7',material=dict(Accession_ID=6069,Accession_Name='Nyl-7',Assembly_ID=100267)),
            dict(id='sq1',material=dict(Accession_ID=6966,Accession_Name='Sq-1',Assembly_ID=100271))]
        candidates,loci,counts=self.build([self.locus],[self.fragment('f1'),self.fragment('f2')])
        self.assertEqual(candidates[0]['material'],'Nyl-7')
        self.assertEqual(candidates[0]['opposite_material'],'Sq-1')
        self.assertEqual(loci[0]['assembly'],'v2.1; author Assembly_ID=100267')
        self.assertEqual(pc.genome_labels(self.manifest['genomes'][1],self.manifest),('Sq-1','v2.1; author Assembly_ID=100271'))
        self.assertEqual(counts['candidate_fragments'],2)
        self.assertEqual(counts['alignment_gap_loci'],1)
        self.assertEqual(counts['genome1_candidate_fragments_overlapping_gene'],2)
        self.assertEqual(counts['genome1_distinct_overlap_gene_ids'],1)

    def test_same_gene_ids_on_opposite_genomes_remain_separate(self):
        one=dict(self.locus,fragment_ids_json='["same_id"]')
        two=dict(self.locus,genome='2',locus_id='locus2',source_chrom='chrB',opposite_chrom='chrA',fragment_ids_json='["same_id"]')
        candidates,loci,counts=self.build([one,two],[self.fragment('same_id','1'),self.fragment('same_id','2')])
        self.assertEqual(counts['candidate_fragments'],2)
        self.assertEqual(counts['alignment_gap_loci'],2)
        self.assertEqual({r['genome_id'] for r in candidates},{'a','b'})
        self.assertEqual({r['opposite_genome_id'] for r in candidates},{'a','b'})

    def test_duplicate_fragment_references_and_same_locus_rows_not_double_counted(self):
        locus=dict(self.locus,fragment_ids_json='["f1","f1","f2"]')
        candidates,loci,counts=self.build([locus,locus],[self.fragment('f1'),self.fragment('f2')])
        self.assertEqual(counts['candidate_fragments'],2)
        self.assertEqual(counts['alignment_gap_loci'],1)
        self.assertEqual(counts['duplicate_fragment_references_ignored'],4)

    def test_unknown_excluded_even_without_gene_context(self):
        e1,g1=self.fragment('f1');e2,_=self.fragment('f2',cls='Unknown')
        candidates,loci,counts=pc.build_tables(self.manifest,[self.locus],[e1,e2],[g1])
        self.assertEqual(len(candidates),1)
        self.assertEqual(loci[0]['fragment_count'],1)
        self.assertEqual(counts['excluded_unknown_class_fragments'],1)

    def test_failed_and_ambiguous_loci_are_not_prioritized(self):
        locus=dict(self.locus,status='ambiguous')
        candidates,loci,counts=self.build([locus],[])
        self.assertEqual(candidates,[])
        self.assertEqual(loci,[])
        self.assertEqual(counts['candidate_fragments'],0)

    def test_coordinate_mismatch_is_not_silently_joined(self):
        e1,g1=self.fragment('f1');e2,g2=self.fragment('f2')
        g2[1]['end1']='1600'
        with self.assertRaisesRegex(ValueError,'Evidence/gene context disagreement'):
            pc.build_tables(self.manifest,[self.locus],[e1,e2],[g1,g2])

    def test_missing_and_stale_validation_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            with self.assertRaisesRegex(ValueError,'markers are required'):
                pc.validated_inputs(root)
            source=root/'input';source.write_text('original')
            record=pc.fingerprint(source,True)
            source.write_text('modified')
            with self.assertRaisesRegex(ValueError,'Stale fingerprint/hash'):
                pc.checked_record(record,True)

    def test_export_requires_valid_markers_and_cannot_reuse_modified_output(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);(root/'evidence').mkdir();(root/'flank_validation').mkdir()
            for genome in self.manifest['genomes']:(root/genome['id']).mkdir()
            (root/'manifest.json').write_text(json.dumps(self.manifest))
            evidence_files=[];gene_files=[]
            fragments=[self.fragment('f1'),self.fragment('f2')]
            for side in (1,2):
                ep=root/'evidence'/('genome%d.candidate_evidence.tsv'%side);gp=root/self.manifest['genomes'][side-1]['id']/'candidate_genes.tsv'
                for path,fields,rows in [(ep,list(fragments[0][0][1]),[p[0][1] for p in fragments] if side==1 else []),(gp,list(fragments[0][1][1]),[p[1][1] for p in fragments] if side==1 else [])]:
                    with open(path,'w') as handle:
                        writer=csv.DictWriter(handle,fieldnames=fields,delimiter='\t');writer.writeheader();writer.writerows(rows)
                evidence_files.append(ep);gene_files.append(gp)
            locus_path=root/'flank_validation/loci.tsv'
            with open(locus_path,'w') as handle:
                writer=csv.DictWriter(handle,fieldnames=list(self.locus),delimiter='\t');writer.writeheader();writer.writerow(self.locus)
            finish_path=root/'finish.done.json'
            finish_path.write_text(json.dumps(dict(status='completed',outputs=[pc.fingerprint(p) for p in evidence_files+gene_files],signature=dict(manifest=self.manifest))))
            tool=root/'tool';tool.write_text('synthetic tool fingerprint fixture')
            source=root/'helper.py';source.write_text('# synthetic helper fingerprint fixture\n')
            signature=dict(inputs=[pc.fingerprint(p,True) for p in [root/'manifest.json',finish_path]+evidence_files],scripts=[pc.fingerprint(source,True)],tool=pc.fingerprint(tool,True))
            (root/'flank_validation/done.json').write_text(json.dumps(dict(status='completed',signature=signature,outputs=[pc.fingerprint(locus_path,True)])))
            args=argparse.Namespace(results=str(root))
            summary=pc.export(args)
            self.assertEqual(summary['counts']['candidate_fragments'],2)
            self.assertEqual(summary['counts']['alignment_gap_loci'],1)
            self.assertEqual(pc.export(args),summary)
            with open(root/'priority_candidates.tsv','a') as handle:handle.write('modified\n')
            with self.assertRaisesRegex(ValueError,'stale'):
                pc.export(args)


if __name__=='__main__':unittest.main()
