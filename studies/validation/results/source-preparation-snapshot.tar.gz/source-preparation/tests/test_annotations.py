import csv
import gzip
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import annotate_candidates as ann
import normalize_annotations as norm
import preflight_genes


class AnnotationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.lengths = self.root / "lengths.tsv"
        self.lengths.write_text("chr1\t1000\nchr2\t500\n")

    def tearDown(self):
        self.tmp.cleanup()

    def run_norm(self, content, fmt="repeat-gff3", extra=(), gz=False):
        source = self.root / ("input.txt.gz" if gz else "input.txt")
        if gz:
            with gzip.open(source, "wt") as handle:
                handle.write(content)
        else:
            source.write_text(content)
        argv = ["--input", str(source), "--format", fmt, "--lengths", str(self.lengths), "--output-prefix", str(self.root / "output"), "--id-prefix", "assembly1"]
        if fmt == "repeat-gff3":
            argv += ["--gff-feature", "repeat_region"]
        args = norm.parser().parse_args(argv + list(extra))
        qc = norm.normalize(args)
        with open(self.root / "output.metadata.tsv") as handle:
            metadata = list(csv.DictReader(handle, delimiter="\t"))
        bed = (self.root / "output.bed").read_text().splitlines()
        return qc, metadata, bed

    def test_gff_boundaries_reverse_and_percent_decoding(self):
        qc, rows, bed = self.run_norm("chr1\ts\trepeat_region\t1\t1000\t.\t-\t.\tID=a%3Bb;Name=TE%20one;Classification=LTR%2FGypsy\n", gz=True)
        self.assertEqual(bed[0].split("\t"), ["chr1", "0", "1000", "assembly1_F000000000001", "0", "-", "LTR"])
        self.assertEqual(rows[0]["source_id"], "a;b")
        self.assertEqual(rows[0]["repeat_name"], "TE one")
        self.assertEqual(rows[0]["family"], "Gypsy")
        self.assertEqual(qc["counts"]["retained_fragments"], 1)

    def test_no_inference_from_repeat_name_and_feature(self):
        qc, _, bed = self.run_norm("chr1\ts\trepeat_region\t1\t10\t.\t+\t.\tID=LTR_1;Name=LTR/Gypsy\n")
        self.assertEqual(bed, [])
        self.assertEqual(qc["counts"]["rejected_unresolved_class"], 1)

    def test_class_mapping_resolves_absence_and_preserves_original(self):
        mapping = self.root / "mapping.tsv"
        mapping.write_text("repeat_name\tclass\tfamily\nTE1\tRC\tHelitron\n")
        _, rows, _ = self.run_norm("chr1\ts\trepeat_region\t1\t10\t.\t+\t.\tID=x;Name=TE1\n", extra=["--class-map", str(mapping)])
        self.assertEqual(rows[0]["canonical_class"], "RC")
        self.assertEqual(rows[0]["family"], "Helitron")
        self.assertEqual(rows[0]["original_class"], ".")
        self.assertIn("explicit_class_map", rows[0]["classification_note"])

    def test_excludes_non_te_retains_unknown(self):
        content = "".join("chr1\ts\trepeat_region\t%d\t%d\t.\t+\t.\tID=x;Classification=%s\n" % (i * 10 + 1, i * 10 + 10, klass) for i, klass in enumerate(["Simple_repeat", "Low_complexity", "Satellite/centr", "rRNA", "tRNA", "snRNA", "scRNA", "RNA", "Unknown", "LINE/L1", "SINE/Alu", "LTR/Copia", "DNA/hAT", "RC/Helitron"]))
        qc, rows, _ = self.run_norm(content)
        self.assertEqual(qc["counts"]["rejected_excluded_non_te"], 8)
        self.assertEqual(len(rows), 6)
        self.assertEqual(rows[0]["classification_note"], "unknown_class_not_confirmed_te")

    def test_explicit_feature_selection_avoids_parent_child_duplicates(self):
        content = "chr1\ts\trepeat_region\t1\t10\t.\t+\t.\tID=x;Classification=LTR\nchr1\ts\tlong_terminal_repeat\t1\t3\t.\t+\t.\tID=x1;Parent=x;Classification=LTR\n"
        qc, rows, _ = self.run_norm(content)
        self.assertEqual(len(rows), 1)
        self.assertEqual(qc["counts"]["rejected_excluded_feature_type"], 1)

    def test_seqname_mismatch_not_guessed(self):
        qc, _, bed = self.run_norm("1\ts\trepeat_region\t1\t10\t.\t+\t.\tID=x;Classification=LTR\n")
        self.assertFalse(bed)
        self.assertEqual(qc["counts"]["rejected_sequence_not_in_fasta"], 1)

    def test_invalid_bounds_and_strand_rejected(self):
        rows = ["0\t5\t+", "100\t99\t+", "1\t1001\t+", "1\t9\tx"]
        content = ""
        for row in rows:
            start, end, strand = row.split("\t")
            content += "chr1\ts\trepeat_region\t%s\t%s\t.\t%s\t.\tClassification=DNA\n" % (start, end, strand)
        qc, _, bed = self.run_norm(content)
        self.assertEqual(qc["counts"]["rejected_interval_out_of_bounds"], 3)
        self.assertEqual(qc["counts"]["rejected_invalid_strand"], 1)
        self.assertFalse(bed)

    def test_repeatmasker_reverse_and_fragment_ids(self):
        content = "   SW perc perc perc query\n score div. del. ins. sequence\n 400 1.0 0.0 0.0 chr1 1 20 (980) C L1 LINE/L1 (0) 90 1 3\n 400 1.0 0.0 0.0 chr1 30 50 (950) + L1 LINE/L1 1 20 (0) 3 *\n"
        _, rows, _ = self.run_norm(content, "repeatmasker-out")
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["start0"], "0")
        self.assertEqual(rows[0]["strand"], "-")
        self.assertEqual(rows[0]["source_id"], rows[1]["source_id"])
        self.assertNotEqual(rows[0]["fragment_id"], rows[1]["fragment_id"])

    def test_ucsc_rmsk_bin_and_nobin_preserve_family(self):
        row = "100\t0\t0\t0\tchr1\t0\t20\t-980\t+\tAluY\tSINE\tAlu\t0\t20\t-300\t1\n"
        _, rows, _ = self.run_norm(row, "ucsc-rmsk")
        self.assertEqual(rows[0]["family"], "Alu")
        _, rows, _ = self.run_norm("585\t" + row, "ucsc-rmsk")
        self.assertEqual(rows[0]["start0"], "0")

    def test_bigrmsk_is_not_rmsk_table(self):
        # A bigRmsk record has 14 columns and must not enter the rmsk parser.
        qc, _, _ = self.run_norm("chr1\t0\t20\tL1\t0\t+\t0\t20\t0\t1\t20\t0\t100\t1\n", "ucsc-rmsk")
        self.assertEqual(qc["counts"]["rejected_rmsk_requires_16_or_17_columns_not_bigrmsk"], 1)

    def test_explicit_one_based_author_bed(self):
        _, rows, bed = self.run_norm("chr1\t1\t10\tTE1\tDNA/hAT\n", "te-bed", extra=["--bed-coordinates", "one-based-inclusive", "--bed-class-column", "5"])
        self.assertEqual(rows[0]["start0"], "0")
        self.assertEqual(bed[0].split("\t")[5], ".")

    def test_empty_or_duplicate_lengths_rejected(self):
        self.lengths.write_text("chr1\t100\nchr1\t100\n")
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            norm.read_lengths(self.lengths)

    def test_overlap_nested_gene_and_reverse_strand(self):
        genes = [ann.Gene(0, 900, "long", "long", "-"), ann.Gene(10, 20, "short", ".", "+"), ann.Gene(100, 110, "near", ".", "+")]
        overlap, nearest, distance = ann.GeneIndex(genes).query(500, 510)
        self.assertEqual([g.identifier for g in overlap], ["long"])
        self.assertEqual(distance, 0)

    def test_nearest_ties_and_adjacent_distance(self):
        index = ann.GeneIndex([ann.Gene(0, 10, "left", ".", "-"), ann.Gene(20, 30, "right", ".", "+")])
        overlap, nearest, distance = index.query(10, 20)
        self.assertEqual(overlap, [])
        self.assertEqual({g.identifier for g in nearest}, {"left", "right"})
        self.assertEqual(distance, 1)
        self.assertEqual(index.query(11, 19)[2], 2)

    def test_interval_overlap_one_base(self):
        overlap, _, distance = ann.GeneIndex([ann.Gene(10, 20, "g", ".", "+")]).query(19, 21)
        self.assertEqual(len(overlap), 1)
        self.assertEqual(distance, 0)

    def test_gene_feature_only_no_transcript_fallback(self):
        path = self.root / "genes.gff3"
        path.write_text("chr1\ts\tmRNA\t1\t10\t.\t+\t.\tID=t;Parent=g\n")
        indices, counts = ann.load_genes(path, norm.read_lengths(self.lengths), self.root / "rejected.tsv")
        self.assertEqual(indices, {})
        self.assertEqual(counts["retained_gene_feature_rows"], 0)

    def test_end_to_end_native_tevox_one_based_join(self):
        _, rows, _ = self.run_norm("chr1\ts\trepeat_region\t10\t20\t.\t-\t.\tID=te;Name=L1;Classification=LINE/L1\n")
        candidates = self.root / "unique.txt"
        candidates.write_text("# ID\tChr\tStart\tEnd\tStrand\tType\tFamily\tName\nTE_1\tchr1\t10\t20\t-\tLINE\tUnknown\t" + rows[0]["fragment_id"] + "\n")
        genes = self.root / "genes.gff3"
        genes.write_text("chr1\ts\tgene\t20\t30\t.\t+\t.\tID=gene%3B1;Name=Gene%201\n")
        output = self.root / "annotated.tsv"
        cmd = [sys.executable, str(SCRIPTS / "annotate_candidates.py"), "--candidates", str(candidates), "--genes", str(genes), "--metadata", str(self.root / "output.metadata.tsv"), "--lengths", str(self.lengths), "--output", str(output)]
        result = subprocess.run(cmd, text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        with open(output) as handle:
            row = next(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(row["nearest_gene_body_distance_bp"], "0")
        self.assertEqual(json.loads(row["overlap_gene_ids_json"]), ["gene;1"])
        self.assertEqual(row["repeat_family"], "L1")

    def test_bigrmsk_uses_fragment_descriptions_not_visualization_bounds(self):
        description = "1597 22.0 9.6 3.4 chr1 101 120 (880) C L1M4 LINE/L1 (10) 40 1 4 ,1597 22.0 9.6 3.4 chr1 151 160 (840) C L1M4 LINE/L1 (40) 10 1 4 "
        row = "chr1\t50\t200\tL1M4#LINE/L1\t220\t-\t100\t160\t0\t5\t50,20,0,10,40\t-1,50,-1,100,-1\t4\t" + description + "\n"
        qc, rows, _ = self.run_norm(row, "ucsc-bigrmsk-bed")
        self.assertEqual([(r["start0"], r["end0"]) for r in rows], [("100", "120"), ("150", "160")])
        self.assertNotEqual(rows[0]["fragment_id"], rows[1]["fragment_id"])
        self.assertEqual(qc["counts"]["parsed_fragments"], 2)
        self.assertEqual(rows[0]["source_id"], "4")
        bad = row.replace("chr1 151", "chr2 151")
        qc, rows, _ = self.run_norm(bad, "ucsc-bigrmsk-bed")
        self.assertFalse(rows)
        self.assertEqual(qc["counts"]["rejected_bigrmsk_description_chromosome_mismatch"], 1)

    def test_chm13_bed_family_and_original_id(self):
        _, rows, _ = self.run_norm("chr1\t10\t20\tMLT1K\t263\t+\tLTR\tERVL-MaLR\t27.9\t4556095\n", "te-bed", extra=["--bed-coordinates", "zero-based-half-open", "--bed-class-column", "7", "--bed-strand-column", "6", "--bed-family-column", "8", "--bed-id-column", "10"])
        self.assertEqual(rows[0]["family"], "ERVL-MaLR")
        self.assertEqual(rows[0]["source_id"], "4556095")

    def test_output_cannot_destroy_source_even_through_symlink(self):
        source = self.root / "source.tsv"
        source.write_text("original")
        destination = self.root / "out.tsv"
        destination.symlink_to(source)
        with self.assertRaisesRegex(ValueError, "overwrite an input"):
            norm.protect_inputs([source], [destination])
        self.assertEqual(source.read_text(), "original")

    def run_preflight(self, content):
        source = self.root / "preflight.gff3.gz"
        with gzip.open(source, "wt") as handle:
            handle.write(content)
        summary = self.root / "gene-qc.json"
        result = subprocess.run([sys.executable, str(SCRIPTS / "preflight_genes.py"), "--input", str(source), "--lengths", str(self.lengths), "--summary", str(summary)], capture_output=True, text=True)
        return result, json.loads(summary.read_text())

    def test_preflight_full_gene_bounds_and_feature_counts(self):
        result, qc = self.run_preflight("##gff-version 3\nchr1\ts\tgene\t1\t1000\t.\t-\t.\tID=g%3B1;Name=one\nchr1\ts\tmRNA\t1\t1000\t.\t-\t.\tID=t;Parent=g%3B1\n")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(qc["gene_count"], 1)
        self.assertEqual(qc["feature_counts"], {"gene": 1, "mRNA": 1})
        self.assertEqual(qc["counts"]["other_feature_rows"], 1)

    def test_preflight_rejects_unknown_sequence_and_out_of_bounds(self):
        result, qc = self.run_preflight("1\ts\tgene\t1\t10\t.\t+\t.\tID=g1\nchr1\ts\tgene\t0\t10\t.\t+\t.\tID=g2\nchr1\ts\tgene\t1\t10\t.\t+\t.\tID=g3\n")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(qc["gene_count"], 1)
        self.assertEqual(qc["counts"]["invalid_gene_rows"], 2)
        self.assertEqual(qc["unknown_sequence_examples_first_20"], ["1"])

    def test_preflight_requires_real_genes_not_only_transcripts(self):
        result, qc = self.run_preflight("chr1\ts\tmRNA\t1\t10\t.\t+\t.\tID=t\n")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(qc["gene_count"], 0)
        self.assertIn("No valid exact gene", qc["warnings"][0])

    def test_preflight_reports_malformed_row_and_missing_id(self):
        result, qc = self.run_preflight("chr1\tbroken\nchr1\ts\tgene\t1\t10\t.\t+\t.\tName=gene\n")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(qc["counts"]["malformed_feature_rows"], 1)
        self.assertEqual(qc["rejected_reasons"]["gene_missing_id"], 1)

    def test_cli_requires_explicit_bed_coordinates(self):
        result = subprocess.run([sys.executable, str(SCRIPTS / "normalize_annotations.py"), "--input", "unused", "--format", "te-bed", "--lengths", str(self.lengths), "--output-prefix", "unused", "--id-prefix", "a", "--bed-class-column", "7"], capture_output=True, text=True)
        self.assertEqual(result.returncode, 2)
        self.assertIn("--bed-coordinates", result.stderr)


if __name__ == "__main__":
    unittest.main()
