import argparse
import csv
import gzip
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))
import validate_flanks as vf


class FlankValidationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
        self.lengths=[{'chrA':10000},{'chrB':10000}]
        self.locus=dict(locus_id='locus1',genome=1,alignment_id='alignment1',source_chrom='chrA',source_gap_start0=3000,source_gap_end0=3500,opposite_chrom='chrB',opposite_empty_site0=4000,alignment_strand='+')

    def tearDown(self): self.tmp.cleanup()

    def hit(self,**changes):
        hit=dict(chrom='chrB',start=3000,end=4000,strand='+',mapq=60,coverage=1.0,identity=1.0,primary=True,projected_start=3000,projected_end=4000)
        hit.update(changes)
        return hit

    def source_left(self):
        return next(s for s in vf.flank_specs(self.locus,self.lengths) if s['role']=='source_left')

    def test_plus_strand_four_reciprocal_flanks(self):
        specs={s['role']:s for s in vf.flank_specs(self.locus,self.lengths)}
        self.assertEqual(len(specs),4)
        self.assertEqual((specs['source_left']['target_start'],specs['source_left']['target_end']),(3000,4000))
        self.assertEqual((specs['opposite_right']['target_start'],specs['opposite_right']['target_end']),(3500,4500))
        self.assertEqual(specs['opposite_left']['target_genome'],0)

    def test_minus_strand_swaps_left_right_both_directions(self):
        self.locus['alignment_strand']='-'
        specs={s['role']:s for s in vf.flank_specs(self.locus,self.lengths)}
        self.assertEqual((specs['source_left']['target_start'],specs['source_left']['target_end']),(4000,5000))
        self.assertEqual((specs['source_right']['target_start'],specs['source_right']['target_end']),(3000,4000))
        self.assertEqual((specs['opposite_left']['target_start'],specs['opposite_left']['target_end']),(3500,4500))
        self.assertEqual((specs['opposite_right']['target_start'],specs['opposite_right']['target_end']),(2000,3000))
        self.assertEqual({s['strand'] for s in specs.values()},{'-'})

    def test_edge_windows_are_not_clipped(self):
        self.locus['source_gap_start0']=999
        with self.assertRaisesRegex(ValueError,'out_of_bounds'):
            vf.flank_specs(self.locus,self.lengths)

    def test_supported_requires_primary_mapq_and_expected_position(self):
        spec=self.source_left()
        self.assertEqual(vf.assess_flank(spec,[self.hit()],1,'ready')['status'],'supported')
        for changes in [dict(mapq=29),dict(mapq=255),dict(primary=False),dict(coverage=.949),dict(identity=.949),dict(chrom='wrong'),dict(strand='-'),dict(start=3051)]:
            with self.subTest(changes=changes):
                self.assertEqual(vf.assess_flank(spec,[self.hit(**changes)],1,'ready')['status'],'failed')
        self.assertEqual(vf.assess_flank(spec,[self.hit(start=3050,coverage=.95)],1,'ready')['status'],'supported')

    def test_distinct_locus_secondary_causes_ambiguity(self):
        alt=self.hit(primary=False,start=6000,end=7000,projected_start=6000,projected_end=7000,mapq=0,coverage=.8)
        self.assertEqual(vf.assess_flank(self.source_left(),[self.hit(),alt],2,'ready')['status'],'ambiguous')
        self.assertEqual(vf.assess_flank(self.source_left(),[self.hit(mapq=0),alt],2,'ready')['status'],'ambiguous')
        alt['coverage']=.799
        self.assertEqual(vf.assess_flank(self.source_left(),[self.hit(),alt],2,'ready')['status'],'supported')

    def test_same_locus_clipped_secondary_is_not_distinct(self):
        secondary=self.hit(primary=False,start=3200,end=4000,coverage=.8,mapq=0)
        self.assertEqual(vf.assess_flank(self.source_left(),[self.hit(),secondary],2,'ready')['status'],'supported')
        self.assertEqual(vf.assess_flank(self.source_left(),[self.hit()],21,'ready')['status'],'ambiguous')

    def test_N_flank_not_validated(self):
        self.assertEqual(vf.assess_flank(self.source_left(),[self.hit()],1,'N_containing_flank')['status'],'not_validated')

    def test_extraction_crosses_chunks_preserves_forward_reference_bases(self):
        sequence='acgt'*700+'N'*5+'TGCA'*1300
        source=self.root/'genome.fa.gz'
        with gzip.open(source,'wt') as h:
            h.write('>chrA description\n'+'\n'.join(sequence[i:i+80] for i in range(0,len(sequence),80))+'\n')
        requests={'good':dict(query_id='good',chrom='chrA',start=3100,end=4100),'bad':dict(query_id='bad',chrom='chrA',start=2000,end=3000)}
        out=self.root/'query.fa.gz'
        with patch('fasta_qc.CHUNK',127):
            statuses=vf.extract_flanks(source,requests,out,{'chrA':len(sequence)})
        self.assertEqual(statuses,{'bad':'N_containing_flank','good':'ready'})
        with gzip.open(out,'rt') as h:self.assertEqual(h.read(),'>good\n'+sequence[3100:4100].upper()+'\n')

    def test_extraction_rejects_unknown_or_missing_seq_names(self):
        source=self.root/'genome.fa'
        source.write_text('>1\n'+'A'*2000+'\n')
        requests={'q':dict(query_id='q',chrom='chr1',start=0,end=1000)}
        with self.assertRaisesRegex(ValueError,'unexpected FASTA'):
            vf.extract_flanks(source,requests,self.root/'out.fa.gz',{'chr1':2000})

    def test_reverse_PAF_projection_and_identity(self):
        paf=self.root/'reads.paf.gz'
        with gzip.open(paf,'wt') as h:
            h.write('q\t1000\t100\t950\t-\tchrB\t10000\t3050\t3900\t833\t850\t40\ttp:A:P\tcg:Z:850M\n')
        hits,counts=vf.parse_paf(paf,{'q':{}},{'chrB':10000})
        self.assertEqual((hits['q'][0]['projected_start'],hits['q'][0]['projected_end']),(3000,4000))
        self.assertAlmostEqual(hits['q'][0]['identity'],.98)
        self.assertEqual(counts['q'],1)

    def test_unknown_excluded_and_gap_deduplicated(self):
        evidence=self.root/'evidence'; evidence.mkdir()
        fields=['fragment_id','canonical_class','category','selected_alignment_id','chrom','gap_start0','gap_end0','opposite_chrom','opposite_empty_site0','alignment_strand']
        for side in (1,2):
            with open(evidence/('genome%d.candidate_evidence.tsv'%side),'w') as h:
                w=csv.writer(h,delimiter='\t');w.writerow(fields)
                if side==1:
                    for fid,cls in [('f1','LINE'),('f2','LTR'),('f3','Unknown')]:
                        w.writerow([fid,cls,'anchored_gap_candidate','aln1','chrA',3000,3500,'chrB',4000,'+'])
        ffields=['genome','fragment_id','alignment_id','source_chrom','source_gap_start0','source_gap_end0','opposite_chrom','opposite_empty_site0','alignment_strand','category']
        with open(evidence/'candidate_flank_loci.tsv','w') as h:
            w=csv.writer(h,delimiter='\t');w.writerow(ffields)
            for fid in ('f1','f2','f3'):w.writerow([1,fid,'aln1','chrA',3000,3500,'chrB',4000,'+','anchored_gap_candidate'])
        loci,counts=vf.load_loci(self.root)
        self.assertEqual(len(loci),1)
        self.assertEqual(loci[0]['fragment_ids'],['f1','f2'])
        self.assertEqual(counts['excluded_unknown_class_fragments'],1)

    def test_full_synthetic_plus_minus_validation_and_integrity_reuse(self):
        binary=SCRIPTS.parent/'tools/minimap2-src/minimap2'
        if not binary.exists():self.skipTest('minimap2 not installed')
        rng=random.Random(23014)
        prefix=''.join(rng.choice('ACGT') for _ in range(3000))
        suffix=''.join(rng.choice('ACGT') for _ in range(6500))
        insertion=''.join(rng.choice('ACGT') for _ in range(500))
        for strand in ('+','-'):
            with self.subTest(strand=strand):
                work=self.root/('plus' if strand=='+' else 'minus');work.mkdir()
                results=work/'results';(results/'evidence').mkdir(parents=True)
                source_seq=prefix+insertion+suffix
                other_seq=prefix+suffix
                site=3000
                if strand=='-':
                    other_seq=other_seq.translate(str.maketrans('ACGT','TGCA'))[::-1]
                    site=len(other_seq)-site
                genomes=[]
                for gid,chrom,sequence in [('one','chrA',source_seq),('two','chrB',other_seq)]:
                    fasta=work/(gid+'.fa.gz')
                    with gzip.open(fasta,'wt') as h:h.write('>'+chrom+'\n'+sequence+'\n')
                    gene=work/(gid+'.gff3');gene.write_text('##gff-version 3\n')
                    repeat=work/(gid+'.out');repeat.write_text('synthetic stub; validator does not consume repeat annotations\n')
                    genomes.append(dict(id=gid,assembly='synthetic_'+gid,fasta=str(fasta),genes=str(gene),repeats=str(repeat),repeat_format='repeatmasker-out'))
                    (results/gid).mkdir()
                    (results/gid/'lengths.tsv').write_text(chrom+'\t'+str(len(sequence))+'\n')
                manifest_path=work/'manifest.json'
                manifest_path.write_text(json.dumps(dict(pair_id='synthetic_pair',genomes=genomes)))
                manifest=vf.load_manifest(manifest_path)
                (results/'manifest.json').write_text(json.dumps(manifest))
                fields=['fragment_id','canonical_class','category','selected_alignment_id','chrom','gap_start0','gap_end0','opposite_chrom','opposite_empty_site0','alignment_strand']
                for side in (1,2):
                    with open(results/'evidence'/('genome%d.candidate_evidence.tsv'%side),'w') as h:
                        w=csv.writer(h,delimiter='\t');w.writerow(fields)
                        if side==1:
                            for fid,cls in [('f1','LINE'),('f2','LTR'),('f3','Unknown')]:w.writerow([fid,cls,'anchored_gap_candidate','aln1','chrA',3000,3500,'chrB',site,strand])
                ffields=['genome','fragment_id','alignment_id','source_chrom','source_gap_start0','source_gap_end0','opposite_chrom','opposite_empty_site0','alignment_strand','category']
                with open(results/'evidence/candidate_flank_loci.tsv','w') as h:
                    w=csv.writer(h,delimiter='\t');w.writerow(ffields)
                    for fid in ('f1','f2','f3'):w.writerow([1,fid,'aln1','chrA',3000,3500,'chrB',site,strand,'anchored_gap_candidate'])
                prep=dict(status='completed',outputs=[vf.fingerprint(results/g['id']/'lengths.tsv') for g in genomes])
                (results/'prepare.done.json').write_text(json.dumps(prep))
                input_records=[vf.fingerprint(g[k]) for g in genomes for k in ('fasta','genes','repeats')]
                evidence_before={str(p):p.read_bytes() for p in (results/'evidence').iterdir()}
                finish=dict(status='completed',outputs=[vf.fingerprint(p) for p in (results/'evidence').iterdir()],signature=dict(inputs=input_records))
                (results/'finish.done.json').write_text(json.dumps(finish))
                args=argparse.Namespace(manifest=str(manifest_path),results=str(results),minimap2=str(binary),threads=1)
                summary=vf.validate(args)
                self.assertEqual(summary['counts'][vf.SUPPORTED+'_loci'],1)
                self.assertEqual(summary['counts'][vf.SUPPORTED+'_fragments'],2)
                self.assertEqual(summary['counts']['excluded_unknown_class_fragments'],1)
                self.assertEqual(evidence_before,{str(p):p.read_bytes() for p in (results/'evidence').iterdir()})
                with patch.object(vf.subprocess,'Popen',side_effect=AssertionError('Reuse must not remap')):
                    self.assertEqual(vf.validate(args),summary)
                with open(results/'flank_validation/loci.tsv','a') as h:h.write('tampered\n')
                with self.assertRaisesRegex(ValueError,'stale input/output'):
                    vf.validate(args)

    def test_real_minimap2_sr_reports_secondary_hits(self):
        binary=SCRIPTS.parent/'tools/minimap2-src/minimap2'
        if not binary.exists():self.skipTest('minimap2 not installed')
        rng=random.Random(20261003)
        flank=''.join(rng.choice('ACGT') for _ in range(1000))
        target=self.root/'target.fa';query=self.root/'query.fa'
        target.write_text('>one\n'+flank+'\n>two\n'+flank+'\n')
        query.write_text('>q\n'+flank+'\n')
        paf=self.root/'actual.paf.gz'
        vf.map_flanks(vf.mapping_command(binary,target,query,1),paf,self.root/'actual.log')
        hits,counts=vf.parse_paf(paf,{'q':{}},{'one':1000,'two':1000})
        self.assertEqual({h['chrom'] for h in hits['q']},{'one','two'})
        self.assertTrue(any(not h['primary'] for h in hits['q']))
        self.assertTrue(any(h['primary'] for h in hits['q']))
        self.assertTrue(all(h['mapq'] != 255 for h in hits['q']))


if __name__=='__main__':unittest.main()
