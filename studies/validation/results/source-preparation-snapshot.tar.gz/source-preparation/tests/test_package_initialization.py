import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

PACKAGE = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('initialize_study', PACKAGE / 'initialize_study.py')
# Initialized workspaces do not need to contain the one-time bootstrap program.
if SPEC is not None and (PACKAGE / 'initialize_study.py').exists():
    MODULE = importlib.util.module_from_spec(SPEC)
    SPEC.loader.exec_module(MODULE)
else:
    MODULE = None


@unittest.skipIf(MODULE is None, 'bootstrap tests run from the source package')
class StudyInitializationTests(unittest.TestCase):
    def test_nested_json_relocation_preserves_quotes_and_urls(self):
        root = Path('/tmp/a "quoted" study')
        result = MODULE.relocate({'paths': ['@STUDY_ROOT@/data/x'], 'url': 'https://example.org/x', 'n': 12}, root)
        self.assertEqual(json.loads(json.dumps(result))['paths'], [str(root) + '/data/x'])
        self.assertEqual(result['url'], 'https://example.org/x')
        self.assertEqual(result['n'], 12)

    def test_initialize_sources_only_and_reject_existing_workspace(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / 'study with spaces'
            record = MODULE.initialize(root)
            self.assertFalse(record['downloaded_inputs'])
            self.assertEqual(list((root / 'data').iterdir()), [])
            self.assertEqual((root / 'docs/maize-low-memory-v1.md').read_bytes(),
                             (PACKAGE / 'docs/maize-low-memory-v1.md').read_bytes())
            self.assertFalse((root / 'tools/minimap2-maize-low-memory-v1').exists())
            self.assertFalse(list(root.rglob('*.done.json')))
            pair = json.loads((root / 'discovery' / 'arabidopsis_pair.json').read_text())
            self.assertTrue(pair['genomes'][0]['fasta'].startswith(str(root) + '/'))
            self.assertNotIn('@STUDY_ROOT@', (root / 'discovery' / 'maize_pair.json').read_text())
            with self.assertRaisesRegex(ValueError, 'new or empty'):
                MODULE.initialize(root)


if __name__ == '__main__':
    unittest.main()
