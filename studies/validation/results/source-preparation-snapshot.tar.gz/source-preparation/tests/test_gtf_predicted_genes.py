import sys
from pathlib import Path
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from gtf_predicted_genes import derive_genes, parse_gtf_attributes, rows


def row(chrom='chr1', start=4, end=8, strand='+', gene='g1', feature='exon'):
    return f'{chrom}\tAUGUSTUS\t{feature}\t{start}\t{end}\t.\t{strand}\t.\tgene_id "{gene}"; transcript_id "t1";\n'


class GtfPredictedGeneTests(unittest.TestCase):
    def test_exon_span_coordinates_and_no_transcript_double_count(self):
        genes, qc = derive_genes([row(start=4, end=8), row(start=15, end=20), row(start=4, end=20, feature='transcript'), row(start=4, end=6, feature='CDS')], {'chr1': 100})
        self.assertEqual((genes['g1']['start'], genes['g1']['end']), (4, 20))
        self.assertEqual(qc['counts']['derived_predicted_gene_spans'], 1)
        self.assertEqual(list(rows(genes, 'b73'))[-1].split('\t')[3:7], ['4', '20', '.', '+'])

    def test_same_gene_on_different_chromosome_fails(self):
        with self.assertRaisesRegex(ValueError, 'discordant chromosome or strand'):
            derive_genes([row(), row(chrom='chr2')], {'chr1': 100, 'chr2': 100})

    def test_same_gene_on_different_strand_fails(self):
        with self.assertRaisesRegex(ValueError, 'discordant chromosome or strand'):
            derive_genes([row(), row(strand='-')], {'chr1': 100})

    def test_quoted_semicolon_and_gff_escaping(self):
        attrs = parse_gtf_attributes('gene_id "g;one"; transcript_id "t \\"one\\"";')
        self.assertEqual(attrs['gene_id'], 'g;one')
        self.assertEqual(attrs['transcript_id'], 't "one"')
        genes, _ = derive_genes([row(gene='g;one', strand='-')], {'chr1': 100})
        output = list(rows(genes, 'oh43'))[-1]
        self.assertIn('ID=oh43:Augustus:g%3Bone;', output)
        self.assertEqual(output.split('\t')[6], '-')

    def test_missing_exons_or_bad_coordinates_fail(self):
        with self.assertRaisesRegex(ValueError, 'no exon rows'):
            derive_genes([row(feature='CDS')], {'chr1': 100})
        with self.assertRaisesRegex(ValueError, 'coordinate outside'):
            derive_genes([row(start=0)], {'chr1': 100})
        with self.assertRaisesRegex(ValueError, 'coordinate outside'):
            derive_genes([row(end=101)], {'chr1': 100})

    def test_invalid_strand_and_unquoted_attribute_fail(self):
        with self.assertRaisesRegex(ValueError, 'invalid strand'):
            derive_genes([row(strand='?')], {'chr1': 100})
        with self.assertRaisesRegex(ValueError, 'Malformed quoted'):
            parse_gtf_attributes('gene_id g1;')


if __name__ == '__main__':
    unittest.main()
