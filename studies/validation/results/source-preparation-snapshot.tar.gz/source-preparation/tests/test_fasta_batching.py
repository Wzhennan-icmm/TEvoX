import argparse
import gzip
import io
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import fasta_qc


class FastaBatchTests(unittest.TestCase):
    def args(self, root, text, selection=False):
        source = root / 'input.fa.gz'
        with gzip.open(source, 'wt') as handle:
            handle.write(text)
        if selection:
            (root / 'select.txt').write_text('a\nb\n')
        return argparse.Namespace(input=str(source), lengths=str(root/'lengths.tsv'), n_runs=str(root/'gaps.bed'), summary=str(root/'qc.json'), select=str(root/'select.txt') if selection else None, selected_fasta=str(root/'selected.fa.gz') if selection else None, force=False)

    def test_headers_at_every_chunk_offset(self):
        for offset in range(32):
            text = '>a description\n' + 'A' * (offset + 1) + '\nNN\nn\n>b desc\nNnT\n'
            with self.subTest(offset=offset), patch.object(fasta_qc, 'CHUNK', 32):
                records = []
                for header, value, lineno in fasta_qc.fasta_batches(io.StringIO(text)):
                    if header:
                        records.append([value, ''])
                    else:
                        records[-1][1] += value.replace('\n', '')
                self.assertEqual(records, [['a description', 'A'*(offset+1)+'NNn'], ['b desc', 'NnT']])

    def test_batch_n_runs_and_selection_are_identical(self):
        text = '>a description\nACNN\nnn\nTAc\n>b\nNnTT' + 'A'*101 + '\n'
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            args = self.args(root, text, selection=True)
            with patch.object(fasta_qc, 'CHUNK', 16):
                small = fasta_qc.qc(args)
            contents = [Path(path).read_bytes() for path in [args.lengths,args.n_runs,args.selected_fasta]]
            args.force = True
            large = fasta_qc.qc(args)
            self.assertEqual(contents, [Path(path).read_bytes() for path in [args.lengths,args.n_runs,args.selected_fasta]])
            self.assertEqual(small['n_bases'], large['n_bases'])
            self.assertEqual(Path(args.n_runs).read_text(),'a\t2\t6\nb\t0\t2\n')

    def test_invalid_character_reports_actual_line_in_batch(self):
        with tempfile.TemporaryDirectory() as temp:
            args = self.args(Path(temp), '>a\nAAAA\nCCC\nAC-G\n')
            with self.assertRaisesRegex(ValueError, 'line 4'):
                fasta_qc.qc(args)
            self.assertFalse(Path(args.summary).exists())

    def test_angle_bracket_in_sequence_not_treated_as_header(self):
        with tempfile.TemporaryDirectory() as temp:
            args = self.args(Path(temp), '>a\nAAAA>G\n')
            with patch.object(fasta_qc, 'CHUNK', 8), self.assertRaisesRegex(ValueError, 'Invalid DNA'):
                fasta_qc.qc(args)

    def test_sequence_before_header_after_blank_lines_reports_line(self):
        with tempfile.TemporaryDirectory() as temp:
            args = self.args(Path(temp), '\n\nACGT\n')
            with self.assertRaisesRegex(ValueError, 'line 3'):
                fasta_qc.qc(args)

    def test_empty_final_header_and_oversized_header_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            args = self.args(root, '>a\nAC\n>b')
            with self.assertRaisesRegex(ValueError, 'Empty FASTA'):
                fasta_qc.qc(args)
            args = self.args(root, '>abcdefghijklmnop\nAC\n')
            with patch.object(fasta_qc, 'CHUNK', 16), self.assertRaisesRegex(ValueError, 'header exceeds'):
                fasta_qc.qc(args)


if __name__ == '__main__':
    unittest.main()
