import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

SPEC = importlib.util.spec_from_file_location('download_plant_inputs', Path(__file__).resolve().parents[1] / 'scripts' / 'download_plant_inputs.py')
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class PlantDownloadProvenanceTests(unittest.TestCase):
    def exercise(self, publisher_md5=None, expected_sha=None):
        with tempfile.TemporaryDirectory(prefix='plant-fetch-test-') as tmp:
            root = Path(tmp)
            target = root / 'data' / 'sample.txt'
            payload = b'public source data\n'
            entry = {'sample': 'a', 'role': 'genes', 'url': 'https://example.org/source', 'bytes': len(payload),
                     'local_path': str(target), 'sha256': expected_sha or hashlib.sha256(payload).hexdigest()}
            if publisher_md5:
                entry.update(provider_md5=publisher_md5, provider_checksum_url='https://example.org/checksums')
            commands = []
            def run(cmd, check):
                commands.append(cmd)
                target.write_bytes(payload)
                Path(str(target) + '.provenance.json').write_text(json.dumps({'verification': 'source_checksum_verified' if publisher_md5 else 'https_size_validated'}))
            with mock.patch.object(MODULE, 'ROOT', root), mock.patch.object(MODULE.subprocess, 'run', side_effect=run):
                result = MODULE.fetch(entry)
            record = json.loads(Path(result['provenance']).read_text())
            return commands[0], record

    def test_local_hash_is_not_passed_as_publisher_checksum(self):
        command, record = self.exercise()
        self.assertNotIn('--sha256', command)
        self.assertNotIn('--md5', command)
        self.assertFalse(record['historical_local_sha256_reproduction']['publisher_checksum'])
        self.assertTrue(record['historical_local_sha256_reproduction']['matched'])

    def test_publisher_md5_is_passed_separately(self):
        command, record = self.exercise(publisher_md5='1234567890abcdef1234567890abcdef')
        self.assertIn('--md5', command)
        self.assertIn('--checksum-source', command)
        self.assertNotIn('--sha256', command)
        self.assertEqual(record['verification'], 'source_checksum_verified')

    def test_changed_source_does_not_claim_historical_match(self):
        with self.assertRaisesRegex(ValueError, 'historical local SHA256'):
            self.exercise(expected_sha='0' * 64)


if __name__ == '__main__':
    unittest.main()
